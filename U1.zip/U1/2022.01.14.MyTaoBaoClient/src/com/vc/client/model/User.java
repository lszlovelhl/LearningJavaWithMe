package com.vc.client.model;

/**
 * author: VC
 * create: 2022/1/13 9:35
 * version: 1.0.0
 */
public class User {
    public static final int ROLE_BUYER = 1;
    public static final int ROLE_SELLER = 2;

    private int id;
    private String name;
    private String pwd;
    private int role;

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public User() {
    }

    public User(String name, String pwd, int role) {
        this.pwd = pwd;
        this.name = name;
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }
}
