package com.vc.client.model;

import java.io.DataInputStream;
import java.io.Serializable;

/**
 * 反序列化接口
 * author: VC
 * create: 2022/1/13 10:02
 * version: 1.0.0
 */
public interface Deserializable {
    void deserialize(DataInputStream in);
}
