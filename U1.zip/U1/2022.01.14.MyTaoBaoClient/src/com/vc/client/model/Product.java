package com.vc.client.model;

import java.io.DataInputStream;
import java.io.IOException;

/**
 * author: VC
 * create: 2022/1/13 9:59
 * version: 1.0.0
 */
public class Product implements Deserializable {
    /**
     * 下架
     */
    public static final int STATUS_OFF_SALE = 0;
    /**
     * 上架
     */
    public static final int STATUS_ON_SALE = 1;

    private int id;
    private String name;
    private double price;
    private int seller;
    private int stock;
    private String description;
    private int status;

    @Override
    public void deserialize(DataInputStream in) {
        try {
            id = in.readInt();
            name = in.readUTF();
            price = in.readDouble();
            seller = in.readInt();
            stock = in.readInt();
            description = in.readUTF();
            status = in.readInt();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
