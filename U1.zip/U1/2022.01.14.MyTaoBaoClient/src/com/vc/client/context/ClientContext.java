package com.vc.client.context;

/**
 * author: VC
 * create: 2022/1/13 9:50
 * version: 1.0.0
 */
public class ClientContext {

    public static final String IP = "127.0.0.1";
    public static final int PORT = 8888;
}
