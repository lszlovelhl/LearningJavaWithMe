package com.vc.client;

import com.vc.client.eums.RegResult;
import com.vc.client.view.MainMenu;

/**
 * author: VC
 * create: 2022/1/12 15:29
 * version: 1.0.0
 */
public class ClientMain {
    public static void main(String[] args) {
        new MainMenu().show();
    }
}
