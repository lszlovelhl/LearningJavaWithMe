package com.vc.client.eums;

public enum RegResult {
    OK("注册成功"),
    FAIL_NAME_DUPLICATED("用户名重复"),
    FAIL_DB("数据库异常");

    private String msg;

    /**
     * 通过枚举的ordinal值,将code解析为对应枚举对象
     */
    public static RegResult parse(int code) {
        //获取枚举类中所有的枚举值
        for (RegResult value : RegResult.values()) {
            //判断枚举值
            if (value.ordinal() == code) {
                return value;
            }
        }
        return null;
    }


    public String getMsg() {
        return msg;
    }

    RegResult(String msg) {
        this.msg = msg;
    }
}
