package com.vc.client.service;

import com.vc.client.eums.RegResult;

public interface UserService {
    /**
     * 用户登录
     *
     * @param name 用户名
     * @param pwd  密码
     * @return 角色编号, 或-1表示登录失败
     */
    int doLogin(String name, String pwd);

    /**
     * 用户注册
     * @param name 用户名
     * @param pwd 密码
     * @param role 角色编号
     * @return 注册结果枚举
     */
    RegResult doReg(String name, String pwd, int role);
}
