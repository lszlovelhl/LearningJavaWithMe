package com.vc.client.service.impl;

import com.vc.client.eums.RegResult;
import com.vc.client.service.UserService;
import com.vc.client.socket.MyClient;
import com.vc.taobao.MessageType;

public class UserServiceImpl implements UserService {
    @Override
    public int doLogin(String name, String pwd) {
        try {
            //发送消息
            MyClient.getInstance().send(MessageType.C2S_LOGIN, name, pwd);
            //接收结果
            return MyClient.getInstance().receiveByte();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    @Override
    public RegResult doReg(String name, String pwd, int role) {
        try {
            //发送消息
            MyClient.getInstance().send(MessageType.C2S_REG, name, pwd, role);
            //接收结果
            int result = MyClient.getInstance().receiveInt();
            //将int解析为枚举对象
            return RegResult.parse(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return RegResult.FAIL_DB;
    }
}
