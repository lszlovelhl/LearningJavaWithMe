package com.vc.client.socket;

import com.vc.client.context.ClientContext;
import com.vc.client.model.Deserializable;
import com.vc.client.model.Product;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * author: VC
 * create: 2022/1/13 9:42
 * version: 1.0.0
 */
public class MyClient {
    //进行代码复用,多用聚合组合,少用继承
    private Socket client;

    private static MyClient instance;

    public static MyClient getInstance() {
        if (instance == null) {
            instance = new MyClient();
        }
        return instance;
    }

    private MyClient() {
    }

    /**
     * 发送消息
     *
     * @param type 消息类型
     * @param args 消息参数
     * @throws Exception
     */
    public void send(int type, Object... args) throws Exception {
        //输出流
        DataOutputStream out = getOutput();
        //写出协议号
        out.writeByte(type);
        //遍历参数
        for (int i = 0; i < args.length; i++) {
            Object arg = args[i];
            if (arg == null) {
                throw new Exception("参数" + i + "为null!");
            }

            //判断参数的类型
            if (arg instanceof String) {
                out.writeUTF(arg.toString());
            } else if (arg instanceof Integer) {
                out.writeInt((Integer) arg);
            } else if (arg instanceof Short) {
                out.writeShort((Short) arg);
            } else if (arg instanceof Byte) {
                out.writeByte((Byte) arg);
            }else if (arg instanceof Float) {
                out.writeFloat((Float) arg);
            }else if (arg instanceof Long) {
                out.writeLong((Long) arg);
            } else if (arg instanceof Double) {
                out.writeDouble((Double) arg);
            }

//            //判断参数的类型
//            if (arg instanceof String) {
//                out.writeUTF(arg.toString());
//            } else if (arg instanceof Integer) {
//                out.writeInt((Integer) arg);
//            } else if (arg instanceof Short) {
//                out.writeShort((Short) arg);
//            } else if (arg instanceof Byte) {
//                out.writeByte((Byte) arg);
//            }
        }
    }

    public int receiveByte() throws Exception {
        DataInputStream in = getInput();
        return in.readByte();
    }

    public int receiveInt() throws Exception {
        DataInputStream in = getInput();
        return in.readInt();
    }

    public <T extends Deserializable> T receive(Class<T> clz) throws Exception {
        DataInputStream in = getInput();
        //反射创建对象
        T obj = clz.newInstance();
        obj.deserialize(in);
        return obj;
    }

    private DataInputStream getInput() throws IOException {
        if (client == null || client.isClosed()) {
            client = new Socket(ClientContext.IP, ClientContext.PORT);
        }
        return new DataInputStream(client.getInputStream());
    }

    private DataOutputStream getOutput() throws IOException {
        if (client == null || client.isClosed()) {
            client = new Socket(ClientContext.IP, ClientContext.PORT);
        }
        return new DataOutputStream(client.getOutputStream());
    }

}
