package com.vc.client.util;

import java.util.Scanner;

/**
 * Scanner工具类
 * author: VC
 * create: 2021/7/26 9:33
 * version: 1.0.0
 */
public class ScannerUtils {
    /**
     * 获取指定返回的输入数字
     *
     * @param min
     * @param max
     * @return
     */
    public static int getInt(int min, int max) {
        Scanner sc = new Scanner(System.in);
        if (!sc.hasNextInt()) {
            System.out.println("请输入" + min + " - " + max + "之间的数字!");
            return getInt(min, max);
        }
        int num = sc.nextInt();
        if (num < min || num > max) {
            System.out.println("请输入" + min + " - " + max + "之间的数字!");
            return getInt(min, max);
        }
        return num;
    }

    public static String next() {
        return new Scanner(System.in).next();
    }

    public static String nextLine() {
        return new Scanner(System.in).nextLine();
    }

    public static int getInt(int min) {
        Scanner sc = new Scanner(System.in);
        if (!sc.hasNextInt()) {
            System.out.println("请输入大于" + min + "的数字!");
            return getInt(min);
        }
        int num = sc.nextInt();
        if (num < min) {
            System.out.println("请输入大于" + min + "的数字!");
            return getInt(min);
        }
        return num;
    }
}
