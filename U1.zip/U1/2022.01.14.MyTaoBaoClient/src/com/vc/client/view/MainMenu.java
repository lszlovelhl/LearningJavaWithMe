package com.vc.client.view;


import com.vc.client.eums.RegResult;
import com.vc.client.model.User;
import com.vc.client.service.UserService;
import com.vc.client.service.impl.UserServiceImpl;
import com.vc.client.util.ScannerUtils;

public class MainMenu {
    private UserService userService = new UserServiceImpl();

    public void show() {
        System.out.println("1.登录");
        System.out.println("2.注册");
        System.out.println("0.退出");
        int choice = ScannerUtils.getInt(0, 2);
        switch (choice) {
            case 1:
                showLogin();
                break;
            case 2:
                showReg();
                break;
            case 0:
                System.exit(0);
                return;
        }
        show();
    }

    private void showLogin() {
        System.out.println("请输入用户名:");
        String name = ScannerUtils.nextLine();

        System.out.println("请输入密码:");
        String pwd = ScannerUtils.nextLine();

        int role = userService.doLogin(name, pwd);
        if (role == -1) {
            System.err.println("用户名或密码错误");
        } else {
           System.out.println("登录成功");
            //根据角色跳转对应的菜单
            if (role == User.ROLE_BUYER) {
                BuyerMenu.getInstance().show();
            } else if (role == User.ROLE_SELLER) {
                SellerMenu.getInstance().show();
            }
        }
    }

    private void showReg() {
        System.out.println("请输入用户名:");
        String name = ScannerUtils.nextLine();

        System.out.println("请输入密码:");
        String pwd = ScannerUtils.nextLine();

        System.out.println("请选择角色:1.买家\t2.卖家");
        int role = ScannerUtils.getInt(1, 2);

        RegResult result = userService.doReg(name, pwd, role);
        if (result == RegResult.OK) {
            System.out.println("注册成功!");
        } else {
            System.err.println(result.getMsg());
        }
    }
}
