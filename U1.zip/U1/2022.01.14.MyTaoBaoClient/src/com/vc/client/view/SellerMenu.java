package com.vc.client.view;

public class SellerMenu {
    private static volatile SellerMenu instance;

    private SellerMenu() {
    }

    public static SellerMenu getInstance() {
        if (instance == null) {
            synchronized (SellerMenu.class) {
                if (instance == null) {
                    instance = new SellerMenu();
                }
            }
        }
        return instance;
    }

    public void show() {
        System.out.println("这是卖家菜单...");
    }
}