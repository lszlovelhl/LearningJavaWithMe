package com.vc.client.view;

public class BuyerMenu {
    private static volatile BuyerMenu instance;

    private BuyerMenu() {
    }

    public static BuyerMenu getInstance() {
        if (instance == null) {
            synchronized (BuyerMenu.class) {
                if (instance == null) {
                    instance = new BuyerMenu();
                }
            }
        }
        return instance;
    }

    public void show() {
        System.out.println("这是买家菜单...");
    }
}