package com.vc.taobao;

/**
 * 消息协议
 */
public interface MessageType {
    /**
     * 客户端->服务器:注册
     * String:用户名
     * String:密码
     * int:角色
     */
    int C2S_REG = 1,
    /**
     * 客户端->服务器:登录
     * String:用户名
     * String:密码
     */
    C2S_LOGIN = 2;

    /**
     * 服务器发送给客户端的推送
     */
    int S2C_PUSH = 100;
}
