package com.vc.lsz.taobaoproject.dao.impl;

import com.vc.lsz.taobaoproject.dao.JDBCTemplate;
import com.vc.lsz.taobaoproject.dao.ShoppingCartDao;
import com.vc.lsz.taobaoproject.model.ShoppingCart;
import com.vc.lsz.taobaoproject.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * @ClassName ShoppingCartDaoImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:37 上午
 * @Version 1.0
 */
public class ShoppingCartDaoImpl extends JDBCTemplate implements ShoppingCartDao {
    @Override
    public int add(ShoppingCart bean) {
        String sql = "insert into ShoppingCart(product_id,product_name,purchase_quantity,add_time,sum_price) values(?,?,?,?,?);";
        return super.update(sql, bean.getProductID(), bean.getProductName(), bean.getPurchaseQuantity(), bean.getAddDate(), bean.getProductPrice()).identity;
    }

    @Override
    public int delete(int id) {
        String sql = "delete from ShoppingCart where sc_id=?;";
        return super.update(sql, id).count;
    }

    @Override
    public int update(ShoppingCart bean) {
        String sql = "update ShoppingCart set product_id=?,product_name=?,purchase_quantity=?,add_time=?,sum_price=? where sc_id=?;";
        return super.update(sql, bean.getProductID(), bean.getProductName(), bean.getPurchaseQuantity(), bean.getAddDate(), bean.getProductPrice(), bean.getShoppingCartID()).count;
    }

    @Override
    public ShoppingCart findById(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from ShoppingCart where sc_id=?");
            preparedStatement.setObject(1, id);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int scID = resultSet.getInt("sc_id");
                int pid = resultSet.getInt("product_id");
                String pName = resultSet.getString("product_name");
                int pq = resultSet.getInt("purchase_quantity");
                Date addDate = resultSet.getDate("add_time");
                double sumPrice = resultSet.getDouble("sum_price");
                return new ShoppingCart(scID, pid, pName, pq, addDate, sumPrice);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return null;
    }

    @Override
    public List<ShoppingCart> findAll() {
        List<ShoppingCart> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from ShoppingCart;");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int scID = resultSet.getInt("sc_id");
                int pid = resultSet.getInt("product_id");
                String pName = resultSet.getString("product_name");
                int pq = resultSet.getInt("purchase_quantity");
                Date addDate = resultSet.getDate("add_time");
                double sumPrice = resultSet.getDouble("sum_price");

                list.add(new ShoppingCart(scID, pid, pName, pq, addDate, sumPrice));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return list;
    }

    @Override
    public List<ShoppingCart> findByBuyerId(int buyer_id) {
        List<ShoppingCart> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
//        while (true){
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from ShoppingCart where buyer_id=?");
            preparedStatement.setObject(1, buyer_id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int scID = resultSet.getInt("sc_id");
                int pid = resultSet.getInt("product_id");
                String pName = resultSet.getString("product_name");
                int pq = resultSet.getInt("purchase_quantity");
                Date addDate = resultSet.getDate("add_time");
                double sumPrice = resultSet.getDouble("sum_price");

                list.add(new ShoppingCart(scID, pid, pName, pq, addDate, sumPrice));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return list;
    }

    private ShoppingCart parseShoppingCart(ResultSet resultSet) throws SQLException {
        int scID = resultSet.getInt("sc_id");
        int pid = resultSet.getInt("product_id");
        String pName = resultSet.getString("product_name");
        int pq = resultSet.getInt("purchase_quantity");
        Date addDate = resultSet.getDate("add_time");
        double sumPrice = resultSet.getDouble("sum_price");
        ShoppingCart shoppingCart = new ShoppingCart(scID, pid, pName, pq, addDate, sumPrice);
        return shoppingCart;
    }

    @Override
    public ShoppingCart findByName(String name) {
        return (ShoppingCart) super.query("select * from ShoppingCart where product_name=?;",
                resultSet -> {
                    try {
                        if (resultSet.next()) {
                            return parseShoppingCart(resultSet);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return null;
                },
                name);
    }
}
