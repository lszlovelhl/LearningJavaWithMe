package com.vc.lsz.taobaoproject.model;

import java.sql.Timestamp;
import java.util.Date;

/**
 * @ClassName Order
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 9:23 上午
 * @Version 1.0
 */
public class Order {
    private int orderID;
    private double orderPrice;
    private int buyersID;
    private int sellersID;
    private int orderState;
    private Date orderDate;
    private Timestamp lastUpdate;

    @Override
    public String toString() {
        return "Order{" +
                "orderID=" + orderID +
                ", orderPrice=" + orderPrice +
                ", buyersID=" + buyersID +
                ", sellersID=" + sellersID +
                ", orderState='" + orderState + '\'' +
                ", orderDate=" + orderDate +
                ", lastUpdate=" + lastUpdate +
                '}';
    }

    public Order(){}

    public Order(int orderID, double orderPrice, int buyersID, int sellersID, int orderState, Date orderDate, Timestamp lastUpdate) {
        this.orderID = orderID;
        this.orderPrice = orderPrice;
        this.buyersID = buyersID;
        this.sellersID = sellersID;
        this.orderState = orderState;
        this.orderDate = orderDate;
        this.lastUpdate = lastUpdate;
    }

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public double getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        this.orderPrice = orderPrice;
    }

    public int getBuyersID() {
        return buyersID;
    }

    public void setBuyersID(int buyersID) {
        this.buyersID = buyersID;
    }

    public int getSellersID() {
        return sellersID;
    }

    public void setSellersID(int sellersID) {
        this.sellersID = sellersID;
    }

    public int getOrderState() {
        return orderState;
    }

    public void setOrderState(int orderState) {
        this.orderState = orderState;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
}
