package com.vc.lsz.taobaoproject.service;

import com.vc.lsz.taobaoproject.enums.Enums;
import com.vc.lsz.taobaoproject.model.User;

import java.util.List;

/**
 * @ClassName UserService
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 12:59 下午
 * @Version 1.0
 */
public interface UserService {
    boolean addUser(String user_name,String pwd,int user_type);
    List<User> findAll();

    Enums userLogin(String name, String passwd, int type);

    int findByName(String user_name);
}
