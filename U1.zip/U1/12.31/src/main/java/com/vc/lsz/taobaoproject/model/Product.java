package com.vc.lsz.taobaoproject.model;

/**
 * @ClassName Product
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 9:22 上午
 * @Version 1.0
 */
public class Product {
    private int productID;
    private String productName;
    private String productDescription;
    private double productPrice;
    private int sellersID;
    private int stock;
    private int state;

    @Override
    public String toString() {
        return productID + "\t\t" + productName + "\t\t\t" + productDescription + "\t\t" + productPrice + "\t\t" + sellersID + "\t\t\t" + stock + "\t\t" + state;
    }

    public Product(){}

    public Product(int productID, String productName, String productDescription, double productPrice, int sellersID, int stock, int state) {
        this.productID = productID;
        this.productName = productName;
        this.productDescription = productDescription;
        this.productPrice = productPrice;
        this.sellersID = sellersID;
        this.stock = stock;
        this.state = state;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public int getSellersID() {
        return sellersID;
    }

    public void setSellersID(int sellersID) {
        this.sellersID = sellersID;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }
}
