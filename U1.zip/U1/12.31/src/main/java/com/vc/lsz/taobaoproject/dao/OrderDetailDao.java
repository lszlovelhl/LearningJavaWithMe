package com.vc.lsz.taobaoproject.dao;

import com.vc.lsz.taobaoproject.model.OrderDetail;

/**
 * @ClassName OrderDetailDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/5 3:45 下午
 * @Version 1.0
 */
public interface OrderDetailDao extends BaseDao<OrderDetail>{

}
