package com.vc.lsz.taobaoproject.service;

import com.vc.lsz.taobaoproject.model.Order;

import java.util.List;

/**
 * @ClassName OrderService
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:40 上午
 * @Version 1.0
 */
public interface OrderService {
    List<Order> findAll();

    List<Order> findByBuyerId(int buyer_id);

    List<Order> findBySellerId(int seller_id);
}
