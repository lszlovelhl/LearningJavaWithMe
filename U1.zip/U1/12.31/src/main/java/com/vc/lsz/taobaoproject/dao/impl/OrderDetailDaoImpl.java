package com.vc.lsz.taobaoproject.dao.impl;

import com.vc.lsz.taobaoproject.dao.JDBCTemplate;
import com.vc.lsz.taobaoproject.dao.OrderDetailDao;
import com.vc.lsz.taobaoproject.model.OrderDetail;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName OrderDetailDaoImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/5 3:46 下午
 * @Version 1.0
 */
public class OrderDetailDaoImpl extends JDBCTemplate implements OrderDetailDao {
    @Override
    public int add(OrderDetail bean) {
        String sql = "insert into `order`(product_id,product_snapshot_name,product_snapshot_price,purchase_quantity) values(?,?,?,?);";
        return super.update(sql, bean.getProductId(), bean.getProductSnapShotName(), bean.getProductSnapShotPrice(), bean.getPurchaseQuantity()).identity;
    }

    @Override
    public int delete(int id) {
        String sql = "delete from `order_detail` where order_id=?;";
        return super.update(sql, id).count;
    }

    @Override
    public int update(OrderDetail bean) {
        String sql = "update `order_detail` set product_id=?,product_snapshot_name=?,product_snapshot_price=?,purchase_quantity=? where order_id=?;";
        return super.update(sql, bean.getProductId(), bean.getProductSnapShotName(), bean.getProductSnapShotPrice(), bean.getPurchaseQuantity(), bean.getOrderId()).count;
    }

    @Override
    public OrderDetail findById(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from `order` where order_id=?;");
            preparedStatement.setObject(1, id);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int oid = resultSet.getInt("order_id");
                int pid = resultSet.getInt("product_id");
                String psName = resultSet.getString("product_snapshot_name");
                double psPrice = resultSet.getDouble("product_snapshot_price");
                int pq = resultSet.getInt("purchase_quantity");
                return new OrderDetail(oid, pid, psName, psPrice, pq);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return null;
    }

    @Override
    public List<OrderDetail> findAll() {
        List<OrderDetail> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from `order_detail`");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int oid = resultSet.getInt("order_id");
                int pid = resultSet.getInt("product_id");
                String psName = resultSet.getString("product_snapshot_name");
                double psPrice = resultSet.getDouble("product_snapshot_price");
                int pq = resultSet.getInt("purchase_quantity");
                list.add(new OrderDetail(oid, pid, psName, psPrice, pq));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return list;
    }
}
