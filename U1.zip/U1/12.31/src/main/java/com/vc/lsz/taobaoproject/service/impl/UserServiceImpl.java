package com.vc.lsz.taobaoproject.service.impl;

import com.vc.lsz.taobaoproject.dao.UserDao;
import com.vc.lsz.taobaoproject.dao.impl.UserDaoImpl;
import com.vc.lsz.taobaoproject.enums.Enums;
import com.vc.lsz.taobaoproject.model.Product;
import com.vc.lsz.taobaoproject.model.User;
import com.vc.lsz.taobaoproject.service.UserService;

import java.util.List;

/**
 * @ClassName UserServiceImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 12:59 下午
 * @Version 1.0
 */
public class UserServiceImpl implements UserService {

    private UserDao userDao = new UserDaoImpl();

    @Override
    public boolean addUser(String user_name,String pwd,int user_type) {
        /**
         * 判断用户是否存在
         */
        User user = userDao.findByName(user_name);
        int id = 0;
        if (user == null){
            /**
             * 添加用户
             */
            id = userDao.add(new User(0, user_name,pwd,user_type));
            return true;
        }else {
//            id = user.getUserID();
            return false;
        }
        /**
         * 封装用户
         */

//        user = new User(0,user_name,pwd,user_type);
//        return userDao.add(user) > 0;

    }

    @Override
    public List<User> findAll() {
        return userDao.findAll();
    }

    @Override
    public Enums userLogin(String name, String passwd, int type) {

        /**
         * 判断用户是否存在
         */
        User user = userDao.findByName(name);
        int id = 0;
        if (user == null){
            return Enums.USER_NOT;
        }else {
            id = user.getUserID();
            String pwd = userDao.findById(id).getUserPWD();
            int uType = userDao.findById(id).getUserType();
            /**
             * 登录判断
             */
            if (passwd.equals(pwd) && type == uType){
                return Enums.SUCCEED;

            }else {
                return Enums.NAME_PWD_ERRO;
            }
        }
    }

    @Override
    public int findByName(String user_name) {
        /**
         * 判断用户是否存在
         */
        User user = userDao.findByName(user_name);
        int id = 0;
        if (user == null){
            return -1;
        }else {
            id = user.getUserID();
            return id;
        }
    }
}
