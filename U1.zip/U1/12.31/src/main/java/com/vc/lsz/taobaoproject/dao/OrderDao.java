package com.vc.lsz.taobaoproject.dao;

import com.vc.lsz.taobaoproject.model.Order;

/**
 * @ClassName OrderDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:03 上午
 * @Version 1.0
 */
public interface OrderDao extends BaseDao<Order>{

}
