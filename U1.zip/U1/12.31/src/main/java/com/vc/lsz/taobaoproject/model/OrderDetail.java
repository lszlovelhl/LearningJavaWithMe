package com.vc.lsz.taobaoproject.model;

/**
 * @ClassName OrderDetail
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/5 3:41 下午
 * @Version 1.0
 */
public class OrderDetail {
    int orderId;
    int productId;
    String productSnapShotName;
    double productSnapShotPrice;
    int purchaseQuantity;

    @Override
    public String toString() {
        return "OrderDetail{" +
                "orderId=" + orderId +
                ", productId=" + productId +
                ", productSnapShotName='" + productSnapShotName + '\'' +
                ", productSnapShotPrice=" + productSnapShotPrice +
                ", purchaseQuantity=" + purchaseQuantity +
                '}';
    }

    public OrderDetail(){}

    public OrderDetail(int orderId, int productId, String productSnapShotName, double productSnapShotPrice, int purchaseQuantity) {
        this.orderId = orderId;
        this.productId = productId;
        this.productSnapShotName = productSnapShotName;
        this.productSnapShotPrice = productSnapShotPrice;
        this.purchaseQuantity = purchaseQuantity;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductSnapShotName() {
        return productSnapShotName;
    }

    public void setProductSnapShotName(String productSnapShotName) {
        this.productSnapShotName = productSnapShotName;
    }

    public double getProductSnapShotPrice() {
        return productSnapShotPrice;
    }

    public void setProductSnapShotPrice(double productSnapShotPrice) {
        this.productSnapShotPrice = productSnapShotPrice;
    }

    public int getPurchaseQuantity() {
        return purchaseQuantity;
    }

    public void setPurchaseQuantity(int purchaseQuantity) {
        this.purchaseQuantity = purchaseQuantity;
    }
}
