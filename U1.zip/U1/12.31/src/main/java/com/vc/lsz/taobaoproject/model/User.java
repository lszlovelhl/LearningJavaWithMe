package com.vc.lsz.taobaoproject.model;

/**
 * @ClassName User
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 9:24 上午
 * @Version 1.0
 */
public class User {
    private int userID;
    private String userName;
    private String userPWD;
    private int userType;

    @Override
    public String toString() {
        return "User{" +
                "userID=" + userID +
                ", userName='" + userName + '\'' +
                ", userPWD=" + userPWD +
                ", userType=" + userType +
                '}';
    }

    public User(){}

    public User(int userID, String userName, String userPWD, int userType) {
        this.userID = userID;
        this.userName = userName;
        this.userPWD = userPWD;
        this.userType = userType;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPWD() {
        return userPWD;
    }

    public void setUserPWD(String userPWD) {
        this.userPWD = userPWD;
    }

    public int getUserType() {
        return userType;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }
}
