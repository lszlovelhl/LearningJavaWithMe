package com.vc.lsz.taobaoproject.service;

import com.vc.lsz.taobaoproject.model.OrderDetail;

import java.util.List;

/**
 * @ClassName OrderDetailService
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/5 4:02 下午
 * @Version 1.0
 */
public interface OrderDetailService {
    List<OrderDetail> findAll();
}
