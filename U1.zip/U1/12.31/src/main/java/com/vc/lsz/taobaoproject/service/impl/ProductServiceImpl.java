package com.vc.lsz.taobaoproject.service.impl;

import com.vc.lsz.taobaoproject.dao.ProductDao;
import com.vc.lsz.taobaoproject.dao.UserDao;
import com.vc.lsz.taobaoproject.dao.impl.ProductDaoImpl;
import com.vc.lsz.taobaoproject.dao.impl.UserDaoImpl;
import com.vc.lsz.taobaoproject.model.Product;
import com.vc.lsz.taobaoproject.model.User;
import com.vc.lsz.taobaoproject.service.ProductService;

import java.util.List;

/**
 * @ClassName ProductServiceImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:50 上午
 * @Version 1.0
 */
public class ProductServiceImpl implements ProductService {

    private ProductDao productDao = new ProductDaoImpl();
    private UserDao userDao = new UserDaoImpl();

    @Override
    public boolean addProduct(String product_name, String product_description, double commodity_price, int sellers_id, int stock, int state) {
        /**
         * 判断商品是否存在
         */
        Product product = productDao.findByName(product_name);
        int id = 0;
        if (product == null) {
            /**
             * 添加商品
             */
            id = productDao.add(new Product(0, product_name, product_description, commodity_price, sellers_id, stock, state));
            return true;
        } else {
//            id = product.getProductID();
            return false;
        }

        /**
         * 封装商品
         */
//        Product product1 = new Product(0,product_name,product_description,commodity_price,sellers_id,stock,state);
//        return productDao.add(product1) > 0;

    }

    @Override
    public List<Product> findAll() {
        return productDao.findAll();
    }

    @Override
    public List<Product> findByProductName(String product_name) {
        return productDao.findByProductName(product_name);
    }

    @Override
    public boolean findByName(String product_name) {
        /**
         * 判断商品是否存在
         */
        Product product = productDao.findByName(product_name);
        int id = 0;
        if (product == null) {
            return false;
        } else {
            id = product.getProductID();
            return true;
        }
    }

    @Override
    public List<Integer> findProductIdBySellerId(int seller_id){
        return productDao.findProductIdBySellerId(seller_id);
    }

    @Override
    public int deleteById(int product_id) {
        return productDao.delete(product_id);
    }

    @Override
    public int findBySellerId(int seller_id) {
//        List<Product> list = new ArrayList<>();
        /**
         * 判断卖家ID是否存在
         */
        User user = userDao.findById(seller_id);
        int id = 0;
        if (user == null) {
            return -1;
        } else {
            id = user.getUserID();
            return id;
        }
//        return false;
    }

    @Override
    public List<Product> findByProductId(int product_id) {
        return productDao.findByProductId(product_id);
//        List<Product> list = new ArrayList<>();
//        /**
//         * 判断商品ID是否存在
//         */
//        Product product = productDao.findById(product_id);
//        int id = 0;
//        if (product == null) {
//            return null;
//        } else {
//            id = product.getProductID();
//            return list;
//        }
    }
}
