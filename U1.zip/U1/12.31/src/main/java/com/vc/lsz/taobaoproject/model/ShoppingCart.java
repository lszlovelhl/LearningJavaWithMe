package com.vc.lsz.taobaoproject.model;

import java.util.Date;

/**
 * @ClassName ShoppingCart
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 9:23 上午
 * @Version 1.0
 */
public class ShoppingCart {
    private int shoppingCartID;
    private int productID;
    private String productName;
    private int purchaseQuantity;
    private Date addDate;
    private double productPrice;

    @Override
    public String toString() {
        return "ShoppingCart{" +
                "shoppingCartID=" + shoppingCartID +
                ", productID=" + productID +
                ", productName='" + productName + '\'' +
                ", purchaseQuantity=" + purchaseQuantity +
                ", addDate=" + addDate +
                ", productPrice=" + productPrice +
                '}';
    }

    public ShoppingCart(){}

    public ShoppingCart(int shoppingCartID, int productID, String productName, int purchaseQuantity, Date addDate, double productPrice) {
        this.shoppingCartID = shoppingCartID;
        this.productID = productID;
        this.productName = productName;
        this.purchaseQuantity = purchaseQuantity;
        this.addDate = addDate;
        this.productPrice = productPrice;
    }

    public int getShoppingCartID() {
        return shoppingCartID;
    }

    public void setShoppingCartID(int shoppingCartID) {
        this.shoppingCartID = shoppingCartID;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getPurchaseQuantity() {
        return purchaseQuantity;
    }

    public void setPurchaseQuantity(int purchaseQuantity) {
        this.purchaseQuantity = purchaseQuantity;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }
}