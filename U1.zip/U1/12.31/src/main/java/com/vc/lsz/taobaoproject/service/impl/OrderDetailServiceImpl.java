package com.vc.lsz.taobaoproject.service.impl;

/**
 * @ClassName OrderDetailService
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/5 4:01 下午
 * @Version 1.0
 */
public class OrderDetailServiceImpl {
}
