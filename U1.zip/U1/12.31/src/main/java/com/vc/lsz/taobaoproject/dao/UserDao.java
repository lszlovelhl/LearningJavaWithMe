package com.vc.lsz.taobaoproject.dao;

import com.vc.lsz.taobaoproject.model.User;

/**
 * @ClassName UserDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 11:33 上午
 * @Version 1.0
 */
public interface UserDao extends BaseDao<User>{
    User findByName(String name);
}
