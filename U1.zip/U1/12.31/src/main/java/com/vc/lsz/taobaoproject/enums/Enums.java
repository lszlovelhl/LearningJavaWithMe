package com.vc.lsz.taobaoproject.enums;

/**
 * @ClassName Enums
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/5 9:39 上午
 * @Version 1.0
 */
public enum Enums {
    USER_NOT,
    NAME_PWD_ERRO,
    SUCCEED,
}
