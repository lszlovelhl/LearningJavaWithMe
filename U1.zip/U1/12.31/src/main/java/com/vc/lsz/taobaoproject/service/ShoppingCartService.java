package com.vc.lsz.taobaoproject.service;

import com.vc.lsz.taobaoproject.model.ShoppingCart;

import java.util.Date;
import java.util.List;

/**
 * @ClassName ShoppingCartService
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:40 上午
 * @Version 1.0
 */
public interface ShoppingCartService {
    boolean addToShoppingCart(int product_id, String product_name, int purchase_quantity, Date add_time, double sum_price);

    List<ShoppingCart> findAll();

//    ShoppingCart findById();

    ShoppingCart findById(int sc_id);

    List<ShoppingCart> findByBuyerId(int buyer_id);
}
