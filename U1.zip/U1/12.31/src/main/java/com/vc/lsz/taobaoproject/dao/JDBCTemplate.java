package com.vc.lsz.taobaoproject.dao;


import com.vc.lsz.taobaoproject.context.AppContext;

import java.sql.*;

/**
 * @ClassName JDBCTemplate
 * @auther lsz1310225074@iCloud.com
 * @Description TODO JDBC帮助类
 * @date 2021/12/30 2:39 下午
 * @Version 1.0
 */
public class JDBCTemplate {
    /**
     * 静态方法加载驱动
     */
    static {
        //加载驱动
        try {
            Class.forName(AppContext.DRIVER_NAME);
        } catch (ClassNotFoundException e) {
            System.out.println("驱动加载失败,程序结束");
            System.exit(0);
        }
    }

    public Object query (String sql, ResultSetCallBack callback, Object... args){
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pst = conn.prepareStatement(sql);
            for (int i = 0; i < args.length; i++) {
                pst.setObject(i + 1, args[i]);
            }
            rs = pst.executeQuery();
            //逻辑
            return callback.processResultSet(rs);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(conn, pst, rs);
        }
        return null;
    }

    /**
     * 通用增删改
     * @param sql
     * @param args
     * @return
     */
    public UpdateResult update(String sql, Object... args) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        UpdateResult result = new UpdateResult();
        try {
            conn = getConnection();
            pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            //填坑
            for (int i = 0; i < args.length; i++) {
                pst.setObject(i + 1, args[i]);
            }
            //执行
            result.count = pst.executeUpdate();
            //获取自增长编号
            rs = pst.getGeneratedKeys();
            if (rs.next()) {
                //获取编号值
                result.identity = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(conn, pst, rs);
        }
        return result;
    }

    /**
     * 获取连接对象
     *
     * @return
     * @throws SQLException
     */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                AppContext.URL,
                AppContext.USER,
                AppContext.PWD);
    }

    /**
     * 关闭连接
     *
     * @param conn
     * @param st
     * @param rs
     */
    public void close(Connection conn, Statement st, ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        if (st != null) {
            try {
                st.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
}
