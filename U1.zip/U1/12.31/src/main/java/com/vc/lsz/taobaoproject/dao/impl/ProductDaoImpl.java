package com.vc.lsz.taobaoproject.dao.impl;

import com.vc.lsz.taobaoproject.dao.JDBCTemplate;
import com.vc.lsz.taobaoproject.dao.ProductDao;
import com.vc.lsz.taobaoproject.model.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName ProductDaoImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:36 上午
 * @Version 1.0
 */
public class ProductDaoImpl extends JDBCTemplate implements ProductDao {
    @Override
    public int add(Product bean) {
        String sql = "insert into product(product_name,product_description,commodity_price,sellers_id,stock,state) values(?,?,?,?,?,?);";
        return super.update(sql, bean.getProductName(), bean.getProductDescription(), bean.getProductPrice(), bean.getSellersID(), bean.getStock(), bean.getState()).identity;
    }

    @Override
    public int delete(int id) {
        String sql = "delete from product where product_id=?;";
        return super.update(sql, id).count;
    }

    @Override
    public int update(Product bean) {
        String sql = "update product set product_name=?,product_description=?,commodity_price=?,sellers_id=?,stock=?,state=? where order_id=?;";
        return super.update(sql, bean.getProductName(), bean.getProductDescription(), bean.getProductPrice(), bean.getSellersID(), bean.getStock(), bean.getState(), bean.getProductID()).count;
    }

    @Override
    public Product findById(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from product where product_id=?;");
            preparedStatement.setObject(1, id);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int pid = resultSet.getInt("product_id");
                String pName = resultSet.getString("product_name");
                String pd = resultSet.getString("product_description");
                double pp = resultSet.getDouble("commodity_price");
                int sellId = resultSet.getInt("sellers_id");
                int stock = resultSet.getInt("stock");
                int state = resultSet.getInt("state");
                return new Product(pid, pName, pd, pp, sellId, stock, state);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return null;
    }

    @Override
    public List<Integer> findProductIdBySellerId(int seller_id) {
        List<Integer> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select product_id from product where sellers_id=?;");
            preparedStatement.setObject(1, seller_id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int pid = resultSet.getInt("product_id");
//                String pName = resultSet.getString("product_name");
//                String pd = resultSet.getString("product_description");
//                double pp = resultSet.getDouble("commodity_price");
//                int sellId = resultSet.getInt("sellers_id");
//                int stock = resultSet.getInt("stock");
//                int state = resultSet.getInt("state");
//                return new Product(pid, pName, pd, pp, sellId, stock, state);
                list.add(pid);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return list;
    }

    @Override
    public List<Product> findAll() {
        List<Product> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from product");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int pid = resultSet.getInt("product_id");
                String pName = resultSet.getString("product_name");
                String pd = resultSet.getString("product_description");
                double pp = resultSet.getDouble("commodity_price");
                int sellId = resultSet.getInt("sellers_id");
                int stock = resultSet.getInt("stock");
                int state = resultSet.getInt("state");
                list.add(new Product(pid, pName, pd, pp, sellId, stock, state));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return list;
    }

    private Product parseProduct(ResultSet resultSet) throws SQLException {
        int pid = resultSet.getInt("product_id");
        String pName = resultSet.getString("product_name");
        String pd = resultSet.getString("product_description");
        double pp = resultSet.getDouble("commodity_price");
        int sellId = resultSet.getInt("sellers_id");
        int stock = resultSet.getInt("stock");
        int state = resultSet.getInt("state");
        Product product = new Product(
                pid,
                pName, pd, pp, sellId, stock, state);
        return product;
    }

    @Override
    public Product findByName(String name) {
        return (Product) super.query("select * from Product where product_name = ?;",
                resultSet -> {
                    try {
                        if (resultSet.next()) {
                            return parseProduct(resultSet);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return null;
                },
                name);
    }

    @Override
    public List<Product> findByProductName(String name) {
        List<Product> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from product where product_name = ?;");
            preparedStatement.setObject(1, name);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int pid = resultSet.getInt("product_id");
                String pName = resultSet.getString("product_name");
                String pd = resultSet.getString("product_description");
                double pp = resultSet.getDouble("commodity_price");
                int sellId = resultSet.getInt("sellers_id");
                int stock = resultSet.getInt("stock");
                int state = resultSet.getInt("state");
                list.add(new Product(pid, pName, pd, pp, sellId, stock, state));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return list;
    }

    @Override
    public List<Product> findByProductId(int product_id) {
        List<Product> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
//        while (true) {
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from product where product_id=?");
            preparedStatement.setObject(1, product_id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int pid = resultSet.getInt("product_id");
                String pName = resultSet.getString("product_name");
                String pd = resultSet.getString("product_description");
                double pp = resultSet.getDouble("commodity_price");
                int sellId = resultSet.getInt("sellers_id");
                int stock = resultSet.getInt("stock");
                int state = resultSet.getInt("state");
                list.add(new Product(pid, pName, pd, pp, sellId, stock, state));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return list;
//        }
    }
}

