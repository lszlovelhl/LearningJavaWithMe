package com.vc.lsz.taobaoproject.dao;

import java.util.List;

/**
 * @ClassName BaseDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO 范型DAO,将其余DAO中的复用内容整合
 * @date 2022/1/4 11:36 上午
 * @Version 1.0
 */
public interface BaseDao<T> {
    /**
     * 添加
     * 返回自增长编号
     * @param bean
     */
    int add(T bean);

    /**
     * 根据ID删除
     * 返回受影响行数
     */
    int delete(int id);

    /**
     * 修改除主键外的其他信息
     * 返回受影响行数
     */
    int update(T bean);

    /**
     * 根据ID查找
     * 无返回
     */
    T findById(int id);

    /**
     * 查找所有
     * 无返回
     */
    List<T> findAll();
}
