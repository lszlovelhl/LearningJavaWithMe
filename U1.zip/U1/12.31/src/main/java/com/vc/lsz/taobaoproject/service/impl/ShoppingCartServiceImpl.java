package com.vc.lsz.taobaoproject.service.impl;

import com.vc.lsz.taobaoproject.dao.ProductDao;
import com.vc.lsz.taobaoproject.dao.ShoppingCartDao;
import com.vc.lsz.taobaoproject.dao.impl.ProductDaoImpl;
import com.vc.lsz.taobaoproject.dao.impl.ShoppingCartDaoImpl;
import com.vc.lsz.taobaoproject.model.Product;
import com.vc.lsz.taobaoproject.model.ShoppingCart;
import com.vc.lsz.taobaoproject.service.ShoppingCartService;
import com.vc.lsz.taobaoproject.util.DateUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @ClassName ShoppingCartServiceImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:50 上午
 * @Version 1.0
 */
public class ShoppingCartServiceImpl implements ShoppingCartService {

    private ShoppingCartDao shoppingCartDao = new ShoppingCartDaoImpl();
    private ProductDao productDao = new ProductDaoImpl();


    @Override
    public boolean addToShoppingCart(int product_id, String product_name, int purchase_quantity, Date add_time, double sum_price) {

        Date date = add_time;
        if (date == null) {
            return false;
        }

        /**
         * 判断商品是否存在
         */
        Product product = productDao.findByName(product_name);
        int id = 0;
        if (product == null) {
            return false;
        } else {
            id = product.getProductID();
            return true;
        }

        /**
         * 封装购物车
         */
//        ShoppingCart shoppingCart = new ShoppingCart(0, product_id, product_name, purchase_quantity, add_time, sum_price);
//        return shoppingCartDao.add(shoppingCart) > 0;
    }

    @Override
    public List<ShoppingCart> findAll() {
        return shoppingCartDao.findAll();
    }

    @Override
    public ShoppingCart findById(int sc_id) {
        return shoppingCartDao.findById(sc_id);
    }

    @Override
    public List<ShoppingCart> findByBuyerId(int buyer_id) {
        return shoppingCartDao.findByBuyerId(buyer_id);
    }


//    }
}
