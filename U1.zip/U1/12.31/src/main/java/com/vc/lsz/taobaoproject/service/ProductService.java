package com.vc.lsz.taobaoproject.service;

import com.vc.lsz.taobaoproject.model.Product;

import java.util.List;

/**
 * @ClassName ProductService
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:39 上午
 * @Version 1.0
 */
public interface ProductService {
    boolean addProduct(String product_name,String product_description,double commodity_price,int sellers_id,int stock,int state);
    List<Product> findAll();

    List<Product> findByProductName(String product_name);

    boolean findByName(String product_name);

    int deleteById(int product_id);

    int findBySellerId(int seller_id);

    List<Product> findByProductId(int product_id);

    List<Integer> findProductIdBySellerId(int seller_id);

}
