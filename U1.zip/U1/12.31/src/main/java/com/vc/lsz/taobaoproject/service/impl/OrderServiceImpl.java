package com.vc.lsz.taobaoproject.service.impl;

import com.vc.lsz.taobaoproject.dao.OrderDao;
import com.vc.lsz.taobaoproject.dao.OrderDetailDao;
import com.vc.lsz.taobaoproject.dao.UserDao;
import com.vc.lsz.taobaoproject.dao.impl.OrderDaoImpl;
import com.vc.lsz.taobaoproject.dao.impl.OrderDetailDaoImpl;
import com.vc.lsz.taobaoproject.dao.impl.UserDaoImpl;
import com.vc.lsz.taobaoproject.model.Order;
import com.vc.lsz.taobaoproject.model.Product;
import com.vc.lsz.taobaoproject.model.User;
import com.vc.lsz.taobaoproject.service.OrderDetailService;
import com.vc.lsz.taobaoproject.service.OrderService;
import com.vc.lsz.taobaoproject.util.DateUtils;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @ClassName OrderServiceImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:50 上午
 * @Version 1.0
 */
public class OrderServiceImpl implements OrderService {
    private OrderDao orderDao = new OrderDaoImpl();
    private UserDao userDao = new UserDaoImpl();
    private OrderDetailDao orderDetailDao = new OrderDetailDaoImpl();

    @Override
    public List<Order> findAll() {
        return orderDao.findAll();
    }

    @Override
    public List<Order> findByBuyerId(int buyer_id) {
        List<Order> list = new ArrayList<>();
        /**
         * 判断买家ID是否存在
         */
        User user = userDao.findById(buyer_id);
        int id = 0;
        if (user == null){
            return null;
        }else {
            id = user.getUserID();
            return list;
        }
    }

    @Override
    public List<Order> findBySellerId(int seller_id) {
        List<Order> list = new ArrayList<>();
        /**
         * 判断卖家ID是否存在
         */
        User user = userDao.findById(seller_id);
        int id = 0;
        if (user == null){
            return null;
        }else {
            id = user.getUserID();
            return list;
        }
    }
}
