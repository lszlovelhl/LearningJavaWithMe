package com.vc.lsz.taobaoproject;

import com.vc.lsz.taobaoproject.context.AppContext;
import com.vc.lsz.taobaoproject.view.Menu;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/3 9:55 下午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
        try {
            AppContext.init();
        }catch (Exception e){
            e.printStackTrace();
            return;
        }
        new Menu().show();
    }
}
