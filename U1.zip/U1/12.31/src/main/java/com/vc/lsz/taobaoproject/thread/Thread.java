package com.vc.lsz.taobaoproject.thread;

/**
 * @ClassName Thread
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/6 1:40 下午
 * @Version 1.0
 */
public class Thread {
}
