package com.vc.lsz.taobaoproject.view;

import com.vc.lsz.taobaoproject.dao.ProductDao;
import com.vc.lsz.taobaoproject.dao.UserDao;
import com.vc.lsz.taobaoproject.dao.impl.ProductDaoImpl;
import com.vc.lsz.taobaoproject.dao.impl.UserDaoImpl;
import com.vc.lsz.taobaoproject.enums.Enums;
import com.vc.lsz.taobaoproject.model.Product;
import com.vc.lsz.taobaoproject.model.User;
import com.vc.lsz.taobaoproject.service.*;
import com.vc.lsz.taobaoproject.service.impl.*;
import com.vc.lsz.taobaoproject.util.ScannerUtils;

import java.util.Date;
import java.util.List;

/**
 * @ClassName Menu
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 8:59 上午
 * @Version 1.0
 */
public class Menu {

    private UserService userService = new UserServiceImpl();
    private ProductService productService = new ProductServiceImpl();
    private OrderService orderService = new OrderServiceImpl();
    private ShoppingCartService shoppingCartService = new ShoppingCartServiceImpl();
    ProductDao productDao = new ProductDaoImpl();
    UserDao userDao = new UserDaoImpl();
    User user = new User();
    private Date Date;


    public void show() {
        System.out.println("-----淘宝主页-----");
        System.out.println("1.用户登录");
        System.out.println("2.用户注册");
        System.out.println("3.退出");
        System.out.println("请选择：");
        int choice = ScannerUtils.getInt(1, 3);
        switch (choice) {
            case 1:
                userLogin();
                break;
            case 2:
                userSignIn();
                break;
            case 3:
                System.out.println("谢谢惠顾，欢迎下次光临！");
                System.exit(0);
                break;
        }
    }

    private void userSignIn() {
        System.out.println("-----注册页-----");
        System.out.println("1.用户注册");
        System.out.println("2.返回主页");
        System.out.println("请选择：");
        int choice = ScannerUtils.getInt(1, 2);
        switch (choice) {
            case 1:
                System.out.println("请输入用户名");
                String SignInName = ScannerUtils.nextLine();
                System.out.println("请输入用户密码");
                String SignInPwd = ScannerUtils.next();
                System.out.println("请输入用户类型(1.买家,2.卖家)请输入数字");
                int type = ScannerUtils.nextInt();
                boolean add = userService.addUser(SignInName, SignInPwd, type);
                if (!add) {
                    System.out.println("用户已存在");
                } else {
                    System.out.println("添加成功");
                }
                show();
                break;
            case 2:
                show();
                break;
        }
    }

    private void userLogin() {
        System.out.println("-----登录页-----");
        System.out.println("1.用户登录");
        System.out.println("2.返回主页");
        System.out.println("请选择：");
        int choice = ScannerUtils.getInt(1, 2);
        switch (choice) {
            case 1:
                System.out.println("请输入用户名");
                String name = ScannerUtils.next();
                System.out.println("请输入用户密码");
                String passwd = ScannerUtils.next();
                System.out.println("请输入用户类型(1.买家,2.卖家)请输入数字");
                int type = ScannerUtils.getInt(1, 2);
                Enums enums = userService.userLogin(name, passwd, type);
                switch (enums) {
                    case USER_NOT:
                        System.out.println("用户不存在");
                        System.out.println("是否注册？");
                        System.out.println("1.注册");
                        System.out.println("2.返回主页");
                        int choose = ScannerUtils.getInt(1, 2);
                        switch (choose) {
                            case 1:
                                userSignIn();
                                break;
                            case 2:
                                show();
                                break;
                        }
                        break;
                    case NAME_PWD_ERRO:
                        System.out.println("用户名或密码错误");
                        System.out.println("再试一次？");
                        System.out.println("1.好");
                        System.out.println("2.返回主页");
                        int cs = ScannerUtils.getInt(1, 2);
                        switch (cs) {
                            case 1:
                                userLogin();
                                break;
                            case 2:
                                show();
                                break;
                        }
                        break;
                    case SUCCEED:
                        System.out.println("登录成功");
                        switch (type) {
                            case 1:
                                buyers();
                            case 2:
                                sellers();
                        }
                        break;
                }
//                userService.userLogin(name,passwd,type);


                break;
            case 2:
                show();
                break;
        }
    }

    private void buyers() {
        System.out.println("----------买家页----------");
        System.out.println("买家您好，欢迎光临！请选择您需要的操作：");
        System.out.println("1.浏览商品");
        System.out.println("2.搜索商品");
        System.out.println("3.查看购物车");
        System.out.println("4.查看订单");
        System.out.println("5.注销");
        System.out.println("请选择：");
        int choice = ScannerUtils.getInt(1, 5);
        switch (choice) {
            case 1:
//                productService.findAll();
//                int pagenum = new LimitMethod().getPagenum();
//                int pagesize = new LimitMethod().getPagesize();
                System.out.println(productService.findAll());
                buyers();
                break;
            case 2:
                System.out.println("请输入商品名");
                String name = ScannerUtils.nextLine();
                boolean findPd = productService.findByName(name);
                if (!findPd) {
                    System.out.println("商品不存在");
                    buyers();
                } else {
                    System.out.println(productService.findByProductName(name));
                    System.out.println("1.下单");
                    System.out.println("2.加入购物车");
                    System.out.println("3.返回");
                    System.out.println("请选择");
                    int chs = ScannerUtils.getInt(1, 3);
                    switch (chs) {
                        case 1:
                            System.out.println("请输入购买数量");
                            int buyNum = ScannerUtils.nextInt();
                            buyers();
                            break;
                        case 2:
                            int pId = new Product().getProductID();
                            String pName = new Product().getProductName();
                            System.out.println("请输入数量");
                            int addSC = ScannerUtils.nextInt();
                            double pPrice = new Product().getProductPrice();
                            boolean addToSC = shoppingCartService.addToShoppingCart(pId, pName, addSC, Date, pPrice * addSC);
                            buyers();
                            break;
                        case 3:
                            buyers();
                            break;
                    }
                }

                break;
            case 3:
//                shoppingCartService.findById();
//                System.out.println("请输入用户名");
//                String buyerName = ScannerUtils.nextLine();
                //根据用户名获取用户ID
//                int buyerId = userService.findByName(buyerName);
//                System.out.println(shoppingCartService.findByBuyerId(buyerId));
                buyers();
                break;
            case 4:
//                orderService.findById();
                int currentUserId = new User().getUserID();
                System.out.println(orderService.findByBuyerId(currentUserId));
                buyers();
                break;
            case 5:
                show();
                break;
        }
    }

    private void sellers() {
        System.out.println("----------卖家页----------");
        System.out.println("卖家您好，欢迎使用本平台，请选择您要进行的操作：");
        System.out.println("1.查看您的所有商品");
        System.out.println("2.添加商品");
        System.out.println("3.删除商品");
        System.out.println("4.查看订单");
        System.out.println("5.注销");
        System.out.println("请选择：");
        int choice = ScannerUtils.getInt(1, 5);
        switch (choice) {
            case 1:
                System.out.println("请输入您的用户名：");
                String name = ScannerUtils.next();
//                int id = ScannerUtils.nextInt();
//                productService.findBySellerId(id);

                int currentUserIdShow = userService.findByName(name);//根据用户名获取到用户ID

                List<Integer> allProductId = productService.findProductIdBySellerId(currentUserIdShow);//根据用户ID获取到所有商品ID
                System.out.println("商品ID\t商品名\t\t商品描述\t\t商品单价\t\t卖家ID\t\t库存\t\t状态(0:下架,1:正常)");
                for (int i = 0; i < allProductId.size(); i++) {
                    int pID = allProductId.get(i);
                    List<Product> productList = productService.findByProductId(pID);//根据商品ID获取商品信息
                    for (int j = 0; j < productList.size(); j++) {
                        Product product = productList.get(j);
                        System.out.println(product);
                    }
                }
                sellers();
                break;


//                for (Product product : productList) {
//                    System.out.println(product);
//                }
//                while (true) {

//                System.out.println(productList);

//                for (int i = 0; i < productList.size(); i++) {
//                    System.out.println(productList.get(i));
//                }


            case 2:
                System.out.println("请输入商品名");
                String pName = ScannerUtils.nextLine();
                System.out.println("请输入商品描述");
                String pDescription = ScannerUtils.nextLine();
                System.out.println("请输入商品价格");
                double pp = ScannerUtils.nextDouble();
                System.out.println("请输入卖家ID");
                int sId = ScannerUtils.nextInt();
                System.out.println("请输入库存量");
                int stock = ScannerUtils.nextInt();
                System.out.println("请输入商品状态(0.下架,1.正常)");
                int state = ScannerUtils.getInt(0, 1);
                boolean addPd = productService.addProduct(pName, pDescription, pp, sId, stock, state);
                if (!addPd) {
                    System.out.println("商品已存在");
                } else {
                    System.out.println("添加成功");
                }
                sellers();
                break;
            case 3:
                //显示此卖家的所有商品
//                String userName = user.getUserName();
                System.out.println("请输入用户名");
                String userName = ScannerUtils.next();
                int currentUser = userService.findByName(userName);//根据用户名获取到用户ID
                List<Integer> allProduct = productService.findProductIdBySellerId(currentUser);//根据用户ID获取到所有商品ID
                System.out.println("商品ID\t商品名\t\t商品描述\t\t商品单价\t\t卖家ID\t\t库存\t\t状态(0:下架,1:正常)");
                for (int i = 0; i < allProduct.size(); i++) {
                    int pID = allProduct.get(i);
                    List<Product> productList = productService.findByProductId(pID);//根据商品ID获取商品信息
                    for (int j = 0; j < productList.size(); j++) {
                        Product product = productList.get(j);
                        System.out.println(product);
                    }
                    //选择要删除的商品ID
                    System.out.println("请选择要删除商品的ID");
                    int dltId = ScannerUtils.nextInt();
                    if (dltId != pID){
                        System.out.println("商品ID输入错误");
                    }else {
                        //执行删除
                        productService.deleteById(dltId);

                    }
                }


//                productDao.delete();
                sellers();
                break;
            case 4:
                int currentUserId = new User().getUserID();
//                orderService.findById();
                System.out.println(orderService.findBySellerId(currentUserId));
                sellers();
                break;
            case 5:
                show();
                break;
        }
    }
}
