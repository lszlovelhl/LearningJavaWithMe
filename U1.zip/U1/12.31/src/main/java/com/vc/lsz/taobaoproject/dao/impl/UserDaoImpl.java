package com.vc.lsz.taobaoproject.dao.impl;

import com.vc.lsz.taobaoproject.dao.JDBCTemplate;
import com.vc.lsz.taobaoproject.dao.UserDao;
import com.vc.lsz.taobaoproject.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName UserDaoImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 11:34 上午
 * @Version 1.0
 */
public class UserDaoImpl extends JDBCTemplate implements UserDao {
    @Override
    public int add(User bean) {
        String sql = "insert into user (user_name,pwd,user_type) VALUES (?,?,?);";
        return super.update(sql, bean.getUserName(), bean.getUserPWD(), bean.getUserType()).identity;
    }

    @Override
    public int delete(int id) {
        String sql = "delete from user where user_id=?;";
        return super.update(sql, id).count;
    }

    @Override
    public int update(User bean) {
        String sql = "update user set user_name=?,pwd=?,user_type=? where user_id=?;";
        return super.update(sql, bean.getUserName(), bean.getUserPWD(), bean.getUserType(), bean.getUserID()).count;
    }

    @Override
    public User findById(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from user where user_id=?;");
            preparedStatement.setObject(1, id);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int uid = resultSet.getInt("user_id");
                String name = resultSet.getString("user_name");
                String psd = resultSet.getString("pwd");
                int type = resultSet.getInt("user_type");

                return new User(uid, name, psd, type);

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }

        return null;
    }

    @Override
    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select user_id 用户编号,user_name 用户名,pwd 用户密码,user_type 用户类型 from user");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int pid = resultSet.getInt("user_id");
                String name = resultSet.getString("user_name");
                String psd = resultSet.getString("pwd");
                int type = resultSet.getInt("user_type");
                list.add(new User(pid, name, psd, type));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return list;
    }

    private User parseUser(ResultSet resultSet) throws SQLException {
        int uid = resultSet.getInt("user_id");
        String name = resultSet.getString("user_name");
        String psd = resultSet.getString("pwd");
        int type = resultSet.getInt("user_type");
        User user = new User(
                uid,
                name,
                psd,
                type);
        return user;
    }

    @Override
    public User findByName(String name) {
        return (User) super.query("select * from user where user_name=?;",
                resultSet -> {
                    try {
                        if (resultSet.next()) {
                            return parseUser(resultSet);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return null;
                },
                name);
    }
}
