package com.vc.lsz.taobaoproject.dao;

import java.sql.ResultSet;

/**
 * @ClassName ResultSetCallBack
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:25 上午
 * @Version 1.0
 */
@FunctionalInterface
public interface ResultSetCallBack {
        /**
         * 处理结果集
         *
         * @param resultSet
         * @return 返回封装的对象
         */
        Object processResultSet(ResultSet resultSet);
}
