package com.vc.lsz.taobaoproject.dao;

import com.vc.lsz.taobaoproject.model.ShoppingCart;

import java.util.List;

/**
 * @ClassName ShoppingCartDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:04 上午
 * @Version 1.0
 */
public interface ShoppingCartDao extends BaseDao<ShoppingCart>{
    ShoppingCart findByName(String name);

    List<ShoppingCart> findByBuyerId(int buyer_id);

}
