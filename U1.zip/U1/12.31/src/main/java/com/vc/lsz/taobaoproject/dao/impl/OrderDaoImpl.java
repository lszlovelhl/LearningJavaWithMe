package com.vc.lsz.taobaoproject.dao.impl;

import com.vc.lsz.taobaoproject.dao.JDBCTemplate;
import com.vc.lsz.taobaoproject.dao.OrderDao;
import com.vc.lsz.taobaoproject.model.Order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @ClassName OrderDaoImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:36 上午
 * @Version 1.0
 */
public class OrderDaoImpl extends JDBCTemplate implements OrderDao {
    @Override
    public int add(Order bean) {
        String sql = "insert into `order`(order_price,buyers_id,sellers_id,state,purchase_time,last_update) values(?,?,?,?,?,?);";
        return super.update(sql, bean.getOrderPrice(), bean.getBuyersID(), bean.getSellersID(), bean.getOrderState(), bean.getOrderDate(), bean.getLastUpdate()).identity;
    }

    @Override
    public int delete(int id) {
        String sql = "delete from `order` where order_id=?;";
        return super.update(sql, id).count;
    }

    @Override
    public int update(Order bean) {
        String sql = "update `order` set order_price=?,buyers_id=?,sellers_id=?,state=?,purchase_time=?,last_update=? where order_id=?;";
        return super.update(sql, bean.getOrderPrice(), bean.getBuyersID(), bean.getSellersID(), bean.getOrderState(), bean.getOrderDate(), bean.getLastUpdate(), bean.getOrderID()).count;
    }

    @Override
    public Order findById(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from `order` where order_id=?;");
            preparedStatement.setObject(1, id);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int oid = resultSet.getInt("order_id");
                double price = resultSet.getDouble("order_price");
                int bid = resultSet.getInt("buyers_id");
                int sid = resultSet.getInt("sellers_id");
                int state = resultSet.getInt("state");
                Date date = resultSet.getDate("purchase_time");
                Timestamp lastUpdate = resultSet.getTimestamp("last_update");
                return new Order(oid, price, bid, sid, state, date, lastUpdate);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return null;
    }

    @Override
    public List<Order> findAll() {
        List<Order> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from `order`");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int odrid = resultSet.getInt("order_id");
                double odrprice = resultSet.getDouble("order_price");
                int buyid = resultSet.getInt("buyers_id");
                int sellid = resultSet.getInt("sellers_id");
                int ordstate = resultSet.getInt("state");
                Date orddate = resultSet.getDate("purchase_time");
                Timestamp ordlastUpdate = resultSet.getTimestamp("last_update");
                list.add(new Order(odrid, odrprice, buyid, sellid, ordstate, orddate, ordlastUpdate));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return list;
    }
}
