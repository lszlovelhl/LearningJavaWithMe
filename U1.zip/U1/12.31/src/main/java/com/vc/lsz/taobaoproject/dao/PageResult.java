package com.vc.lsz.taobaoproject.dao;

import java.util.List;

/**
 *@Author:lsz1310225074@iCloud.com
 *@Description: TODO
 *@DateTime: 2022/1/4 2:53 下午
 */
public class PageResult<T> {
    //查询出的数据
    public List<T> data;
    //总页数
    public int maxPageCount;
}
