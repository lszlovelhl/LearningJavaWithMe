package com.vc.lsz.taobaoproject.dao;

import com.vc.lsz.taobaoproject.model.Product;

import java.util.List;

/**
 * @ClassName ProductDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/4 10:17 上午
 * @Version 1.0
 */
public interface ProductDao extends BaseDao<Product>{

    Product findByName(String name);

    List<Integer> findProductIdBySellerId(int seller_id);

    List<Product> findByProductName(String name);

    List<Product> findByProductId(int product_id);
}
