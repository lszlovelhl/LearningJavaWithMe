package com.vc.game.model;

import com.vc.game.context.AppContext;
import com.vc.game.model.cells.*;
import com.vc.game.model.enums.CellType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * @ClassName Map
 * @auther lsz1310225074@iCloud.com
 * @Description TODO 创建地图类，放入地图元素
 * @date 2021/12/20 10:31 上午
 * @Version 1.0
 */
public class Map {
    private static final int WIDTH = 9, HEIGHT = 9;

    /**
     * 创建格子集合
     */
    private Cell[][] cells;

    /**
     * 创建玩家集合
     */
    private List<PlayerCell> playerCells = new ArrayList<>();

    public void setCell(int x, int y, Cell cell) {
        cells[y][x] = cell;
    }

    /**
     * 当前移动玩家的下标
     */
    private int currentPlayerIndex;

    public int getCurrentPlayerIndex() {
        return currentPlayerIndex;
    }

    public void setCurrentPlayerIndex(int currentPlayerIndex) {
        this.currentPlayerIndex = currentPlayerIndex;
    }

    public List<PlayerCell> getPlayerCells() {
        return playerCells;
    }

    /**
     * 初始化地图
     */
    public void initMap() {
        cells = new Cell[HEIGHT][WIDTH];
//        外层控行数
        for (int y = 0; y < cells.length; y++) {
//            内层控列数
            for (int x = 0; x < cells[y].length; x++) {

                /**
                 * 放入空白格子
                 */
                cells[y][x] = new EmptyCell(x, y);
            }
        }
    }

    /**
     * 放入豆子
     */
//    public void addBean(int num) {
////        获取地图上的空白格子，以集合形式保存
//        List<Cell> empty = getEmptyCell();
//        /**
//         * 在放入豆子时可能出现获取到的空白格子数小于要写入的豆子数的问题，解决此问题的思路为以获取到的空白格子数和要写入的豆子数中较小的为准
//         */
//        num = Math.min(empty.size(), num);
////        获取空白格子
//        for (int i = 0; i < num; i++) {
//            Cell cell = empty.get(i);
//            int x = cell.getX();
//            int y = cell.getY();
//            cell = new BeanCell(x, y);
////            将豆子放入数组中
//            cells[y][x] = cell;
//        }
//    }

    /**
     * @Author:lsz1310225074@iCloud.com
     * @Description: TODO 由于玩家元素和传送门元素与其余像豆子之类的元素不同，故单独添加
     * @DateTime: 2021/12/20 2:00 下午
     * @Params: player & tpdoor
     * @Return:
     */

    public void addPlayer(int playernum) {
        List<Cell> list = getEmptyCell();
        if (playernum > list.size()) {
            list = getCellsExcluedTP();
        }
//        以玩家图标长度为最大玩家个数
        if (playernum > AppContext.PLAYER_ICONS.length) {
            playernum = AppContext.PLAYER_ICONS.length;
        }
        for (int i = 0; i < playernum; i++) {
            Cell cell = list.get(i);
            int x = cell.getX();
            int y = cell.getY();
            cell = new PlayerCell(x, y, AppContext.PLAYER_ICONS[i], "玩家" + (i + 1));
            playerCells.add((PlayerCell) cell);
            cells[y][x] = cell;
        }
    }

    public void addTPDoor(int doornum) {
        List<Cell> list = getEmptyCell();
//        判断空白格子数量是否足够，计算传送门能够生成的几对
        doornum = Math.min(list.size(), doornum * 2) / 2;
        for (int i = 0; i < doornum; i++) {
            Cell cell1 = list.remove(0);
            Cell cell2 = list.remove(0);
            TPDoorCell tpDoorCell1 = new TPDoorCell(cell1.getX(), cell1.getY());
            TPDoorCell tpDoorCell2 = new TPDoorCell(cell2.getX(), cell2.getY());
//            关联传送门
            tpDoorCell1.setAnother(tpDoorCell2);
            tpDoorCell2.setAnother(tpDoorCell1);
//            将传送门写入地图
            cells[tpDoorCell1.getY()][tpDoorCell1.getX()] = tpDoorCell1;
            cells[tpDoorCell2.getY()][tpDoorCell2.getX()] = tpDoorCell2;
        }
    }

    /**
     * @Author:lsz1310225074@iCloud.com
     * @Description: TODO 由于地图中的元素如豆子、空白格子、炸弹、地雷、便便等有共同的属性和添加方法，故使用枚举方法简化代码量
     * @DateTime: 2021/12/20 1:35 下午
     * @Params: enum
     * @Return: CellType
     */

    public void addCell(int num, CellType type) {
        List<Cell> empty = getEmptyCell();
        num = Math.min(empty.size(), num);
        for (int i = 0; i < num; i++) {
            Cell cell = empty.get(i);
            int x = cell.getX();
            int y = cell.getY();
            /**
             * 此处使用枚举判断添加的格子类型
             */
            switch (type) {
                case EMPTY_CELL:
                    cell = new EmptyCell(x, y);
                    break;
                case BEAN_CELL:
                    cell = new BeanCell(x, y);
                    break;
                case BOMB_CELL:
                    cell = new BombCell(x, y);
                    break;
                case SHIT_CELL:
                    cell = new ShitCell(x, y);
                    break;
                case UNDERBOMB_CELL:
                    cell = new UnderBombCell(x, y);
                    break;
            }
            cells[y][x] = cell;
        }
    }

    /**
     * 获取地图中的空白格子
     */

    private List<Cell> getEmptyCell() {
        //    创建空集合
        List<Cell> list = new ArrayList<>();
        for (int y = 0; y < cells.length; y++) {
            for (int x = 0; x < cells[y].length; x++) {
//                判断获取到的格子是否为EmptyCell
                /**
                 * instanceof判断is a sth.
                 */
                if (cells[y][x] instanceof EmptyCell) {
//                    若为空白格子则加入集合
                    list.add(cells[y][x]);
                }
            }
        }
        /**
         * 打乱集合中获取的空白格子的顺序
         */
        Collections.shuffle(list);
        return list;
    }

    /**
     * 获取除了玩家和传送门以外的格子
     */

    private List<Cell> getCellsExcluedTP() {
        List<Cell> list = new ArrayList<>();
        for (int y = 0; y < cells.length; y++) {
            for (int x = 0; x < cells[y].length; x++) {
                if (cells[y][x] instanceof TPDoorCell || cells[y][x] instanceof PlayerCell) {
                    continue;
                }
                list.add(cells[y][x]);
            }
        }
        Collections.shuffle(list);
        return list;
    }


    /**
     * @Author:lsz1310225074@iCloud.com
     * @Description: TODO 添加玩家移动功能
     * @DateTime: 2021/12/20 6:29 下午
     * @Params: playerMove
     * @Return: move功能
     */

    public void playerMove() {
        PlayerCell playerCell = playerCells.get(currentPlayerIndex);
        System.out.println("轮到" + playerCell.getName() + "移动");
        Scanner scanner = new Scanner(System.in);
        String ctl = scanner.next();
        /**
         * 存在用户输入值为大写的情况，故一律将输入值转为小写
         */
        ctl = ctl.toLowerCase();
//        获取玩家下一步移动位置的坐标
        int nextX = playerCell.getX();
        int nextY = playerCell.getY();
        switch (ctl) {
            case "a":
                nextX--;
                break;
            case "d":
                nextX++;
                break;
            case "w":
                nextY--;
                break;
            case "s":
                nextY++;
                break;
        }
//        if ("a".equals(ctl)) {
//            nextX--;
//        } else if ("d".equals(ctl)) {
//            nextX++;
//        } else if ("w".equals(ctl)) {
//            nextY--;
//        } else if ("s".equals(ctl)) {
//            nextY++;
//        }
        /**
         * 判断边界位置，贯穿边界
         */
        if (nextX < 0) {
            nextX = WIDTH - 1;
        } else if (nextX > WIDTH - 1) {
            nextX = 0;
        }
        if (nextY < 0) {
            nextY = HEIGHT - 1;
        } else if (nextY > HEIGHT - 1) {
            nextY = 0;
        }
        Cell next = cells[nextY][nextX];

        boolean move = next.trigger(this);
        /**
         * 玩家移动逻辑
         */

//        boolean moved = next.trigger(this){
//            if (moved){
//                gameOver();
//            }
//        }

        if (move) {
//            当前位置变为空地
            cells[playerCell.getY()][playerCell.getX()] = new EmptyCell(playerCell);
//            将玩家位置变为要移动到的位置
            playerCell.setX(nextX);
            playerCell.setY(nextY);
            cells[nextY][nextX] = playerCell;
        }
//        轮到下一个玩家移动
        try {
            currentPlayerIndex++;
            currentPlayerIndex = currentPlayerIndex % playerCells.size();
        } catch (Exception e) {
            System.out.println("Game Over");
//            gameOver();
//            System.exit(0);
        }
    }
//        if (playerCells.size() < 0) {
//            System.out.println("所有玩家均已死亡，游戏结束");
//            System.exit(0);
//        }

    /**
     * 打印地图
     */
    public void printMap() {
        System.out.println("♦️：空地\t🤔：豆子\t💩：便便");
        System.out.println("💣：炸弹\t⚡️：地雷\t🌀：传送门");

        /**
         * 根据玩家数打印玩家位置及玩家分数
         */
        for (int i = 0; i < playerCells.size(); i++) {
            PlayerCell playerCell = playerCells.get(i);
            System.out.println(playerCell.getName() + ":" + playerCell.getIcon()
                    + ",分数：" + playerCell.getScore());
        }

        for (int y = 0; y < cells.length; y++) {
            for (int x = 0; x < cells[y].length; x++) {
                System.out.print(cells[y][x]);
            }
            System.out.println();
        }
    }

    /**
     * 游戏结束条件判断
     */
    public void gameOver() {
        PlayerCell playerCell = playerCells.get(currentPlayerIndex);
        if (playerCells.size() == 1) {
            for (int i = 0; i < playerCells.size(); i++) {
                System.out.println(playerCell.getName() + "获胜，得分为：" + playerCell.getScore());
            }
            System.exit(0);
        }
    }

//        playerMove();

    public PlayerCell getCurrentPlayer() {
        return playerCells.get(currentPlayerIndex);
    }
}
