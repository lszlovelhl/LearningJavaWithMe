package com.vc.game.context;

/**
 * @ClassName AppContext
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 3:28 下午
 * @Version 1.0
 */
public class AppContext {
    public static final String[] PLAYER_ICONS = {"🐯","🐰","🐮"};
}
