package com.vc.game.model.cells;


import com.vc.game.model.Map;

/**
 * @ClassName Cell
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 10:21 上午
 * @Version 1.0
 */
public abstract class Cell {
    /**
     * 坐标
     */
    private int x;
    private int y;
    /**
     * 格子样式
     */
    private String icon;

    public abstract boolean trigger(Map map);

    @Override
    public String toString() {
        return icon + " ";
    }

    public Cell(int x, int y, String icon) {
        this.x = x;
        this.y = y;
        this.icon = icon;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

//    protected void addScore(int i) {
    }
//}
