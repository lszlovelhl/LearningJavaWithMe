package com.vc.game.model.enums;

/**
 * @ClassName CellType
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 1:38 下午
 * @Version 1.0
 */
public enum CellType {
    /**
     * 空白格子
     */
    EMPTY_CELL,

    /**
     * 豆子
     */
    BEAN_CELL,

    /**
     * 炸弹
     */
    BOMB_CELL,

    /**
     * 便便
     */
    SHIT_CELL,

    /**
     * 地雷
     */
    UNDERBOMB_CELL,

    /**
     * 玩家
     */
    PLAYER_CELL;
}
