package com.vc.game.model.cells;

import com.vc.game.model.Map;

/**
 * @ClassName ShitCell
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 1:39 下午
 * @Version 1.0
 */
public class ShitCell extends Cell{

    @Override
    public boolean trigger(Map map) {
        map.getCurrentPlayer().addScore(-1);
        return true;
    }

    public ShitCell(int x, int y) {
        super(x, y, "💩");
    }
}
