package com.vc.game.controler;

import com.vc.game.model.Map;
import com.vc.game.model.enums.CellType;

/**
 * @ClassName GameControler
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 10:25 下午
 * @Version 1.0
 */
public class GameControler {
    public void start() {
        /**
         * 创建地图
         */
        Map map = new Map();

        /**
         * 地图初始化
         */
        map.initMap();

        /**
         * 添加豆子
         */
        map.addCell(30, CellType.BEAN_CELL);
        /**
         * 添加炸弹
         */
        map.addCell(20, CellType.BOMB_CELL);
        /**
         * 添加便便
         */
        map.addCell(10, CellType.SHIT_CELL);
        /**
         * 添加地雷
         */
        map.addCell(5, CellType.UNDERBOMB_CELL);

        /**
         * 添加传送门
         */
        map.addTPDoor(2);

        /**
         * 添加玩家
         */
        map.addPlayer(3);

        while (true) {
            /**
             * 打印地图
             */
            map.printMap();
            /**
             * 玩家移动
             */
            map.playerMove();
        }
    }
}
