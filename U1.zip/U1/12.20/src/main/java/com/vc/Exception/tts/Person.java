package com.vc.Exception.tts;

/**
 * @ClassName Person
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 4:40 下午
 * @Version 1.0
 */
public class Person {
    private int age;

    public Person(int age) {

    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) throws AgeOutException {
        if (age >= 0 && age <= 100){
            this.age = age;
        }else {
            throw new AgeOutException();
        }
    }
}
