package com.vc.Exception.tts;

import java.util.Scanner;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 4:42 下午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("请输入年龄：(0-100之间)");
        Scanner scanner = new Scanner(System.in);
        int age = scanner.nextInt();
        Person person = new Person(age);
        try {
            if (age >= 0 && age <= 100){
                person.setAge(age);
            }else {
                System.out.println("年龄输入错误");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
