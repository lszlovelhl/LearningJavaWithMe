package com.vc.game.model.cells;

import com.vc.game.model.Map;

/**
 * @ClassName UnderBombCell
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 1:40 下午
 * @Version 1.0
 */
public class UnderBombCell extends Cell{

    public UnderBombCell(int x, int y) {
        super(x, y, "⚡️");
    }

    @Override
    public boolean trigger(Map map) {
        //获取当前移动的玩家
        PlayerCell player = map.getCurrentPlayer();
        //将玩家从集合中移除
        map.getPlayerCells().remove(player);
        //将原本炸弹和玩家的位置改为空地
        map.setCell(player.getX(), player.getY(), new EmptyCell(player));
        map.setCell(getX(), getY(), new EmptyCell(this));
        //让当前移动玩家的下标回退一次
        map.setCurrentPlayerIndex(map.getCurrentPlayerIndex() - 1);
        System.out.println(player.getName() + " 死亡");
//        if (map.getCurrentPlayerIndex() < 0){
//            System.out.println("玩家全部死亡，游戏结束");
//            System.exit(0);
//        }
        return false;
    }
}
