package com.vc.game.model.cells;

import com.vc.game.model.Map;

/**
 * @ClassName PlayerCell
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 2:07 下午
 * @Version 1.0
 */
public class PlayerCell extends Cell{
    private String name;
    private int score;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void addScore(int score){
        this.score += score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    @Override
    public boolean trigger(Map map){
        return false;
    }

    public PlayerCell(int x, int y, String icon,String name) {
        super(x, y, icon);
        this.name = name;
    }
}
