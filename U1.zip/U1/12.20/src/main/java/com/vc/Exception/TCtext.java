package com.vc.Exception;

import javax.crypto.spec.PSource;
import java.util.Scanner;

/**
 * @ClassName TCtext
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 4:07 下午
 * @Version 1.0
 */
public class TCtext {
    public static void main(String[] args) {
        String[] lession = new String[]{
                "Java","Python","C++"
        };
        Scanner scanner = new Scanner(System.in);
        int input = scanner.nextInt();

        try {
            boolean flag = false;
            switch (input){
                case 1:
                    System.out.println(lession[0]);
                    flag = true;
                    break;
                case 2:
                    System.out.println(lession[1]);
                    flag = true;
                    break;
                case 3:
                    System.out.println(lession[2]);
                    flag = true;
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }

        System.out.println("请输入一个数字：(1~3)");

    }
}
