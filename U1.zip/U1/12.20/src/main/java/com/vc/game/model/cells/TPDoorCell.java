package com.vc.game.model.cells;

import com.vc.game.model.Map;

/**
 * @ClassName TPDoorCell
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 2:08 下午
 * @Version 1.0
 */
public class TPDoorCell extends Cell{
    private TPDoorCell another;

    public TPDoorCell getAnother() {
        return another;
    }

    public void setAnother(TPDoorCell another) {
        this.another = another;
    }

    public TPDoorCell(int x, int y) {
        super(x, y, "🌀");
    }

    @Override
    public boolean trigger(Map map) {
        PlayerCell player = map.getCurrentPlayer();
        //获取关联的传送门
        TPDoorCell another = getAnother();
        map.setCell(player.getX(), player.getY(), new EmptyCell(player));
        //将当前坐标设置为空地
        map.setCell(getX(), getY(), new EmptyCell(this));
        //将玩家坐标给到另一扇传送门
        map.setCell(another.getX(), another.getY(), new PlayerCell(another.getX(), another.getY(), player.getIcon(), player.getName()));
        player.setX(another.getX());
        player.setY(another.getY());
        return false;
    }
}
