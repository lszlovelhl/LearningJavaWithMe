package com.vc.game.model.cells;

import com.vc.game.model.Map;

/**
 * @ClassName BeanCell
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 10:21 上午
 * @Version 1.0
 */
public class BeanCell extends Cell{

    public BeanCell(int x, int y) {
        super(x, y, "🤔");
    }

    @Override
    public boolean trigger(Map map) {
        map.getCurrentPlayer().addScore(1);
        return true;
    }
}
