package com.vc.game.model.cells;

import com.vc.game.model.Map;

/**
 * @ClassName EmptyCell
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/20 10:22 上午
 * @Version 1.0
 */
public class EmptyCell extends Cell{
    public EmptyCell(int x, int y) {
        super(x, y, "♦️");
    }

    public EmptyCell(Cell cell){
        this(cell.getX(),cell.getY());
    }

    public boolean trigger(Map map) {
        return true;
    }

}
