package com.vc.server;

import com.vc.server.socket.MyServer;

import java.io.IOException;

/**
 * author: VC
 * create: 2022/1/13 10:37
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {
        try {
            new MyServer().start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
