package com.vc.server.dao;


import com.vc.server.model.User;

public interface UserDao {
    int add(User user);

    User findById(int id);

    User findByName(String name);
}
