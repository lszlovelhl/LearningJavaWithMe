package com.vc.server.handler.impl;

import com.vc.server.context.ServerContext;
import com.vc.server.handler.MessageHandler;
import com.vc.server.model.User;

import java.io.DataInputStream;
import java.io.DataOutputStream;

/**
 * author: VC
 * create: 2022/1/11 13:43
 * version: 1.0.0
 */
public class LoginHandler implements MessageHandler {
    @Override
    public void processMessage(DataInputStream inputStream, DataOutputStream outputStream) throws Exception {
        String name = inputStream.readUTF();
        String pwd = inputStream.readUTF();
        //判断是否能登录
        User user = ServerContext.users.get(name);
        int result;
        if (user == null) {
            //用户名不存在
            result = 0;
        } else {
            //用户存在,验证密码
            if (user.getPwd().equals(pwd)) {
                //密码正确,可以登录
                result = 2;
                //绑定名字

//                client.setName(name);
            } else {
                //密码错误
                result = 1;
            }
        }
        //向客户端写出结果
//        client.getOut().writeByte(result);
        outputStream.writeByte(result);
    }
}
