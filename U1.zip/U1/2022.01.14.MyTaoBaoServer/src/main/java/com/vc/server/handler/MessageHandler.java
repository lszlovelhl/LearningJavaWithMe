package com.vc.server.handler;

import java.io.DataInputStream;
import java.io.DataOutputStream;

public interface MessageHandler {
    void processMessage(DataInputStream in, DataOutputStream out) throws Exception;
}
