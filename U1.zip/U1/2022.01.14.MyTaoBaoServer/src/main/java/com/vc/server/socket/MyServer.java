package com.vc.server.socket;

import com.vc.server.context.ServerContext;
import com.vc.server.thread.ProcessClientThread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * author: VC
 * create: 2022/1/13 10:27
 * version: 1.0.0
 */
public class MyServer {
    private ServerSocket server;

    public void start() throws IOException {
        server = new ServerSocket(ServerContext.PORT);
        System.out.println("服务器已启动");
        //接收客户端套接字
        while (ServerContext.isRunning) {
            Socket client = server.accept();
            //交给处理线程
            new ProcessClientThread(client).start();
        }
    }
}
