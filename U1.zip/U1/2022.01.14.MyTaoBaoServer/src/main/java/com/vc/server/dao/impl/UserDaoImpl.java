package com.vc.server.dao.impl;

//import com.vc.orm.JDBCTemplate;

import com.vc.orm.JDBCTemplate;
import com.vc.server.dao.UserDao;
import com.vc.server.model.User;

import java.util.List;

public class UserDaoImpl extends JDBCTemplate implements UserDao {
    @Override
    public int add(User user) {
        return super.add(user).identity;
    }

    @Override
    public User findById(int id) {
        return super.findById(User.class, id);
    }

    @Override
    public User findByName(String name) {
        List<User> list = super.findByProperty(User.class, "name", name);
        return list.size() == 0 ? null : list.get(0);
    }
}
