package com.vc.server.dao;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.vc.orm.DataSourceCreator;

import javax.sql.DataSource;
import java.util.Properties;

/**
 * author: VC
 * create: 2022/1/12 17:08
 * version: 1.0.0
 */
public class DruidDataSourceCreator implements DataSourceCreator {
    @Override
    public DataSource createDataSource() throws Exception {
        Properties prop = new Properties();
        prop.load(DruidDataSourceCreator.class.getClassLoader().getResourceAsStream("druid.properties"));
        return DruidDataSourceFactory.createDataSource(prop);
    }
}
