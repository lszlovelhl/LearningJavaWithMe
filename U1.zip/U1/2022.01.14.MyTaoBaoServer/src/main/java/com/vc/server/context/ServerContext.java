package com.vc.server.context;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.vc.server.handler.MessageHandler;
import com.vc.server.model.User;
import com.vc.taobao.MessageType;

import javax.sql.DataSource;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URL;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * author: VC
 * create: 2022/1/13 10:28
 * version: 1.0.0
 */
public class ServerContext {
    public static final int PORT = 8888;
    public static boolean isRunning = true;

    /**
     * 已注册用户集合
     */
    public static Map<String, User> users = new HashMap<>();


    static {
        URL url = ServerContext.class.getResource("/druid.properties");
        if (url == null) {
            System.out.println("类根路径下缺少druid.properties配置文件");
            System.exit(0);
        }
        //通过Map作为参数获取连接
        Map<String,String> map=new HashMap<String,String>();
//向map中传递参数
        map.put("url", "jdbc:mysql://127.0.0.1:3306/taobaoproject");//数据库地址
        map.put("username", "root");//用户名
        map.put("password", "19980624");//密码
//创建数据源
        DataSource dataSource = null;
        try {
            dataSource = DruidDataSourceFactory.createDataSource(map);
            Connection connection = dataSource.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
//获取连接
    }


    public static Map<Integer, MessageHandler> handlerMap = new HashMap<>();
    static {
        //加载配置文件
        URL url = ServerContext.class.getResource("/handler.properties");
        if (url == null) {
            System.out.println("类根路径下缺少handler.properties配置文件");
            System.exit(0);
        }
        Properties prop = new Properties();
        try {
            prop.load(new FileInputStream(url.getFile()));
            //获取消息处理器的映射关系
            //反射获取MessageType接口中的所有字段
            Field[] fields = MessageType.class.getFields();
            for (Field field : fields) {
                //调用静态属性,obj传null
                try {
                    //获取消息类型中的值
                    Object obj = field.get(null);
                    String value = prop.getProperty(obj.toString());
                    //判断是否配置了映射
                    if (value == null) {
                        continue;
                    }
                    //使用反射创建对象
                    Object handler = Class.forName(value).newInstance();
                    //验证是否是MessageHandler的子类
                    if (!(handler instanceof MessageHandler)) {
                        System.err.println(value + " 不是 " + MessageHandler.class.getName() + " 的子类!");
                        continue;
                    }
                    //放入集合
                    handlerMap.put((Integer) obj, (MessageHandler) handler);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
