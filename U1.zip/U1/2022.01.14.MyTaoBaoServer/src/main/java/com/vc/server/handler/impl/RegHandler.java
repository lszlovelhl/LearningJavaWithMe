package com.vc.server.handler.impl;



import com.vc.server.context.ServerContext;
import com.vc.server.handler.MessageHandler;
import com.vc.server.model.User;

import java.io.DataInputStream;
import java.io.DataOutputStream;

/**
 * author: VC
 * create: 2022/1/11 13:44
 * version: 1.0.0
 */
public class RegHandler implements MessageHandler {
    @Override
    public void processMessage(DataInputStream in, DataOutputStream out) throws Exception {
        //读取用户名
        String name = in.readUTF();
        //读取密码
        String pwd = in.readUTF();
        //读取角色
        int role = in.readInt();
        int result;
        //验证是否存在
        if (ServerContext.users.containsKey(name)) {
            //失败
            result = 0;
        } else {
            //db
            ServerContext.users.put(name, new User());
            //成功
            result = 2;
        }
        //向客户端写出结果
        out.writeByte(result);
    }
}
