package com.vc.server.thread;

import com.vc.server.context.ServerContext;
import com.vc.server.handler.MessageHandler;
import com.vc.taobao.MessageType;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

/**
 * author: VC
 * create: 2022/1/13 10:30
 * version: 1.0.0
 */
public class ProcessClientThread extends Thread {
    private Socket client;

    public ProcessClientThread(Socket client) {
        this.client = client;
        setDaemon(true);
    }

    @Override
    public void run() {

        try {
            DataInputStream in = new DataInputStream(
                    client.getInputStream()
            );
            DataOutputStream out = new DataOutputStream(
                    client.getOutputStream()
            );


            //读取协议号
            while (ServerContext.isRunning) {
                int type = in.readByte();

                if (type == MessageType.C2S_REG) {
                    String name = in.readUTF();
                    String pwd = in.readUTF();
                    System.out.println(name + ":" + pwd);
                }
                MessageHandler handler = ServerContext.handlerMap.get(type);
                if (handler == null) {
                    System.err.println("协议" + type + "没有配置对应的实现.client=" + client.getRemoteSocketAddress());
                    continue;
                }
                handler.processMessage(in, out);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
