//package com.vc.lsz.homework;
//
//import java.util.Scanner;
//
///**
// * @auther XXX@abc.com
// * @date 2021/12/14 8:31 上午
// */
//public class Game {
//    private static int playerg;
//    private static int compg;
//    String[] comp = new String[]{"刘备", "关羽", "张飞"};
////    int playerg;
////    int compg;
//
//    public Game() {
//
//    }
//
//    public static void main(String[] args) {
//        show();
//
//    }
//
//    private static void show() {
//        System.out.println("**********欢迎您参加猜拳游戏**********");
//        System.out.println("\t\t*****游戏规则*****");
//        System.out.println("\t\t1.石头,2.剪刀,3.布");
//        Scanner ingame = new Scanner(System.in);
//        System.out.println("请输入玩家名称：");
//        String pname = ingame.next();
//
//        System.out.println("请选择对战角色：1.刘备,2.关羽,3.张飞：");
//        if (!ingame.hasNextInt()) {
//            System.out.println("请输入数字");
//            ingame.nextInt();
//        } else {
//            int fight;
//
//            if ((fight = ingame.nextInt()) > 0 && fight <= 3) {
//                if (playerg == compg){
//                    System.out.println("平局");
//                }else if (playerg % 3 + 1 == compg){
//                    System.out.println("你赢了，当前积分为：" + User);
//                }
//            }
//        }
//    }
//}
