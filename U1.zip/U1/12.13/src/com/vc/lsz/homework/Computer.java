//package com.vc.lsz.homework;
//
///**
// * @auther XXX@abc.com
// * @date 2021/12/13 11:13 下午
// */
//public class Computer {
//    String[] cguess = new String[]{"石头","剪刀","布"};
//
//    Computer(){
//
//    }
//
//    public static int Computer(){
//        int comguess = (int)(Math.random() * 3.00 + 1.00);
//        System.out.println("\n电脑猜拳:" + cguess[comguess - 1]);
//        return comguess;
//    }
//}
