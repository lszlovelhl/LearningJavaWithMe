//package com.vc.lsz.homework;
//
//import java.util.Scanner;
//
///**
// * @auther XXX@abc.com
// * @date 2021/12/13 11:13 下午
// */
//public class User {
//    String[] guess = new String[]{"石头", "剪刀", "布"};
////    int playerscore;
//
//    User() {
//
//    }
//
//    public static int guessed() {
//        while (true) {
//            Scanner inguess = new Scanner(System.in);
//            System.out.println("请猜拳：1.石头,2.剪刀,3.布:");
//            if (!inguess.hasNextInt()) {
//                System.out.println("请输入数字");
//            } else {
//                int youguess;
//                if ((youguess = inguess.nextInt()) > 0 && youguess <= 3) {
//                    System.out.println("\n请你猜拳：" + guess[youguess - 1]);
//                    return youguess;
//                }
//                System.out.println("输入错误");
//            }
//        }
//    }
//}