package com.vc.lsz.demo1;

/**
 * @auther XXX@abc.com
 * @date 2021/12/13 10:52 上午
 */
public class Main {
    public static void main(String[] args) {
        Student stu = new Student();
        stu.num = 123;
        stu.name = "张三";
        stu.Cscore = 89;
        stu.Mscore = 91;

        stu.output();
    }
}
