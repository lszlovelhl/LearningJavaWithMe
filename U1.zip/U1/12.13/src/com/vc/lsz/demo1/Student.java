package com.vc.lsz.demo1;

/**
 * @auther XXX@abc.com
 * @date 2021/12/13 10:45 上午
 */
public class Student {
    int num;
    String name;
    double Cscore;
    double Mscore;

    public void output(){
        System.out.println(num + "\t" + name + "\t" + Cscore + "\t" + Mscore);
    }
}

