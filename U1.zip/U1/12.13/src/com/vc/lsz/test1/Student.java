package com.vc.lsz.test1;

/**
 * @auther XXX@abc.com
 * @date 2021/12/13 1:48 下午
 */
public class Student {
    int num;
    String name;
    double Chscore;
    double Mascore;

    public void output(){
        System.out.println("学号\t姓名\t语文成绩\t数学成绩");
        System.out.println(num + "\t" + name + " \t" + Chscore + "\t" + Mascore);
    }
}
