package com.vc.lsz.test1;

/**
 * @auther XXX@abc.com
 * @date 2021/12/13 1:48 下午
 */
public class Main {
    public static void main(String[] args) {
        Student student = new Student();
        student.output();
    }
}
