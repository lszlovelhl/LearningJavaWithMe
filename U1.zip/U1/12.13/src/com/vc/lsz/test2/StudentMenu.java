package com.vc.lsz.test2;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/13 4:28 下午
 */
public class StudentMenu {
    Student[] student = new Student[3];
    Scanner scanner = new Scanner(System.in);

    int getInt(int min, int max) {
        Scanner innum = new Scanner(System.in);
        if (!innum.hasNextInt()) {
            System.out.println("请输入数字");
            return getInt(min, max);
        }
        int choice = innum.nextInt();
        if (choice < min || choice > max) {
            System.out.println("请输入" + min + "~" + max + "的数字");
            return getInt(min, max);
        }
        return choice;
    }

    public void show() {
        do {
            System.out.println("1.查看所有学生信息");
            System.out.println("2.增加学生信息");
            System.out.println("3.删除学生信息");
            System.out.println("4.修改学生信息");
            System.out.println("0.退出");

            int input = getInt(0, 4);
            switch (input) {
                case 1:
                    for (int i = 0; i < student.length; i++) {
                        if (student[i] == null) {
                            continue;
                        }System.out.println(student[i].name);
                        break;
                    }
                    break;

                case 2:
                    do {
                        AddStudent();
                    }while (true);

                case 3:
                    DelStudent();

                case 4:
                    ChangeStudent();
                    break;

                case 0:
                    System.exit(0);
                    break;
            }
            show();
        } while (true);
    }

    private void ChangeStudent() {
        System.out.println("请输入要修改学生的学号");
        int changenum = scanner.nextInt();
        for (int i = 0; i < student.length; i++) {
            if (student[i].num == 0){
                System.out.println("暂无学生信息");
                continue;
            }
            else if (!(student[i].num == changenum)) {
                System.out.println("学号不存在");
            } else {
                System.out.println("请输入修改后的学生姓名：");
                String changename = scanner.next();
                System.out.println("请输入修改后的语文成绩：");
                double changeCScore = scanner.nextInt();
                System.out.println("请输入修改后的数学成绩：");
                double changeMScore = scanner.nextInt();
                System.out.println("您确定要修改学号为" + student[i].num + "的学生信息吗？(y/n)");
                String choose = scanner.next();
                if (choose.equalsIgnoreCase("y")) {
                    changename.equals(student[i].name);
                    changeCScore =  student[i].chineseScore;
                    changeMScore =  student[i].mathScore;
                }
            }
        }
    }

    private void DelStudent() {
        do {
            System.out.println("请输入要删除的学生学号：");
            int delnum = scanner.nextInt();
            for (int i = 0; i < student.length; i++) {
                if (!(student[i].num == delnum)) {
                    System.out.println("学号不存在");
                } else {
                    System.out.println("您确定要删除学号为" + student[i].num + "，学生信息为" + student[i].name + student[i].chineseScore +student[i].mathScore + "的学生吗？(y/n)");
//                                Scanner inchoose = new Scanner(System.in);
                    String inchoose = scanner.next();
                    if (inchoose.equalsIgnoreCase("y")) {
                        Student[] delStudent = new Student[student.length - 1];
                        System.arraycopy(student, 0, delStudent, 0, student.length - 1);
                        student = delStudent;
                        System.out.println("删除成功");
                        if (student.length == 0) {
                            System.out.println("已无学生数据");
                            System.exit(0);
                            break;
                        }
                        continue;
                    }
                }
                System.out.println("输入有误");
            }
        } while (true);
    }

    private void AddStudent() {
        System.out.println("请输入学号");
        int newnum = scanner.nextInt();
        System.out.println("请输入姓名");
        String newname = scanner.next();
        System.out.println("请输入语文成绩");
        double newCScore = scanner.nextDouble();
        System.out.println("请输入数学成绩");
        double newMScore = scanner.nextDouble();
        for (int i = 0; i < student.length; i++) {
            if (student[i] == null) {
                student[i] = new Student(newnum, newname, newCScore, newMScore);
            }
        }
        Student[] newStudent = new Student[student.length + 1];
        System.arraycopy(student, 0, newStudent, 0, student.length);
        student = newStudent;
        System.out.println("学生信息添加成功");
        show();
    }
}
