package com.vc.lsz.test2;

/**
 * @auther XXX@abc.com
 * @date 2021/12/13 1:59 下午
 */
public class Main {
    public static void main(String[] args) {
        Menu showMenu = new Menu();
        StudentMenu swMenu = new StudentMenu();
        showMenu.show();
        swMenu.show();
    }
}
