package com.vc.lsz.test2;

/**
 * @auther XXX@abc.com
 * @date 2021/12/13 1:47 下午
 */
public class User {
    String username;
    String passwd;

    public User(String username, String passwd) {
        this.username = username;
        this.passwd = passwd;
    }
}
