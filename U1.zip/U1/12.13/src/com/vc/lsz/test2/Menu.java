package com.vc.lsz.test2;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/13 1:47 下午
 */
public class Menu {
    User[] users = new User[3];
    Scanner scanner = new Scanner(System.in);
    StudentMenu studentMenu = new StudentMenu();

    public void show() {
        do {
            System.out.println("1.登录");
            System.out.println("2.注册");
            System.out.println("0.退出");
            System.out.println("请输入：");
            String input = scanner.next();

            switch (input) {
                case "1":
                    showLoginMenu();
                    break;
                case "2":
                    showRegMenu();
                    break;
                case "0":
                    System.out.println("谢谢使用，再见");
                    System.exit(0);
//                    return;
                default:
                    System.out.println("输入错误");
            }
        } while (true);
    }

    public void showLoginMenu() {
        System.out.println("请输入用户名：");
        String usernm = scanner.next();
        System.out.println("请输入密码：");
        String pswd = scanner.next();
        boolean flag = canLogin(usernm, pswd);
        if (flag) {
            System.out.println("登录成功");
            studentMenu.show();
        } else {
            System.out.println("登录失败");
        }
        show();


//        if (usernm.equals(user.username)) {
//            System.out.println("请输入密码：");
//
//            if (pswd.equals(user.passwd)) {
//                System.out.println("登录成功");
//            } else {
//                System.out.println("密码错误");
//            }
//        } else {
//            System.out.println("用户不存在");
//        }
    }

    private boolean canLogin(String usernm, String pswd) {
        for (int i = 0; i < users.length; i++) {
            if (users[i] == null){
                continue;
            }
            if (usernm.equals(users[i].username) && pswd.equals(users[i].passwd)){
                return true;
            }
        }
        return false;
    }

    public void showRegMenu() {
        System.out.println("请输入用户名：");
        String newuser = scanner.next();
        System.out.println("请输入密码：");
        String newpswd = scanner.next();
        boolean flag = addUser(newuser, newpswd);

        if (flag) {
            System.out.println("注册成功");
        }else {
            System.out.println("注册失败");
        }
        show();
    }

    private boolean addUser(String newuser, String newpswd) {
        boolean flag = false;
        for (int i = 0; i < users.length; i++) {
            if (users[i] == null) {
                users[i] = new User(newuser, newpswd);
                flag = true;
                break;
            }
        }
        if (flag == false) {
            User[] newUsers = new User[users.length + 1];
            System.arraycopy(users,0,newUsers,0,users.length);
            users = newUsers;
        }
        return flag;
    }

}
