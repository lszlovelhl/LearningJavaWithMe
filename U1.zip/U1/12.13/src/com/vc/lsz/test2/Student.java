package com.vc.lsz.test2;

/**
 * @auther XXX@abc.com
 * @date 2021/12/13 4:31 下午
 */
public class Student {
    int num;
    String name;
    double chineseScore;
    double mathScore;

    public Student(int num,String name,double chineseScore,double mathScore){
        this.num = num;
        this.name = name;
        this.chineseScore = chineseScore;
        this.mathScore = mathScore;
    }
}
