package com.vc.lsz.homework.homework2;

import com.vc.lsz.homework.homework2.view.Menu;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/22 5:02 下午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
        Class<Menu> menuClass = Menu.class;
        try {
            Constructor<Menu> constructor = menuClass.getConstructor();
            Menu menu = constructor.newInstance();
            Method aStatic = menuClass.getMethod("show");
            Object invoke = aStatic.invoke(menu);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
