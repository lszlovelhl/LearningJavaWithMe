package com.vc.lsz.homework.homework2.controller;

import com.vc.lsz.homework.homework1.context.AppContext;
import com.vc.lsz.homework.homework1.model.User;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName UserController
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 12:26 上午
 * @Version 1.0
 */
public class UserController {
    private List<User> users = new ArrayList<>();
    private static UserController userrController;

    public static UserController getInstance() {
        if (userrController == null) {
            userrController = new UserController();
        }
        return userrController;
    }

    // TODO 读取配置文件
    ObjectInputStream objectInputStream = null;

    private UserController() {
        try {
            File file = new File(AppContext.DB_PATH);
            if (!file.exists()) {
                return;
            }
            objectInputStream = new ObjectInputStream(new FileInputStream(AppContext.DB_PATH));
            List<User> newusers = (List<User>) objectInputStream.readObject();
            users = newusers;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (!(objectInputStream == null)) {
                try {
                    objectInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // TODO 登录验证
    public int login(String name, String passWord) {
        boolean flag = false;
        for (User user : users) {
            if (name.equals(user.getName())) {
                flag = true;
            }
        }
        if (!flag) {
            return 1;
        }
        for (User user : users) {
            if (name.equals(user.getName()) && passWord.equals(user.getPwd())) {
                return 2;
            }
        }
        return 3;
    }

    // TODO 注册选项
    ObjectOutputStream objectOutputStream = null;

    public int reg(String newname, String newpassWord) {
        for (User user : users) {
            if (newname.equals(user.getName())) {
                return 1;
            }
        }
        User user = new User(newname, newpassWord);
        users.add(user);
        try {
            objectOutputStream = new ObjectOutputStream(new FileOutputStream(AppContext.DB_PATH));
            objectOutputStream.writeObject(users);
            return 2;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (!(objectOutputStream == null)) {
                try {
                    objectOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return 3;
    }
}
