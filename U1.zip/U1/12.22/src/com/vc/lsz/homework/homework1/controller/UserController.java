package com.vc.lsz.homework.homework1.controller;

import com.vc.lsz.homework.homework1.context.AppContext;
import com.vc.lsz.homework.homework1.model.User;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName UserControler
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/22 5:04 下午
 * @Version 1.0
 */
public class UserController {
    private List<User> users01 = new ArrayList<>();

    // TODO 单例化类
    private static UserController Controller;
    public static UserController getInstance(){
        if (Controller==null){
            Controller = new UserController();
        }
        return Controller;
    }

    // TODO 读取配置文件
    private UserController() {
        try {
            File file = new File(AppContext.DB_PATH);
            if (!(file.exists())){
                return;
            }
            FileReader fileReader = new FileReader(AppContext.DB_PATH);
            char[] chars = new char[1024];
            int i;
            String s=null;
            while ((i=fileReader.read(chars))!=-1){
                s = new String(chars, 0, i);
            }
            splits(s);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void splits(String s) {
        String[] split = s.split("\r\n");
        String[] split1=null;
        for (String s1 : split) {
            split1 = s1.split(",");
        }
        for (int i = 0; i < split1.length; i++) {
            if (i<split1.length-1){
                User user = new User(split1[i], split1[i+1]);
                users01.add(user);
            }
        }
        for (User user01 : users01) {
            System.out.println(user01);
        }
    }

    // TODO 登录验证
    public int login(String name, String passWord) {
        boolean flag =false;
        for (User user : users01) {
            if (name.equals(user.getName())){
                flag=true;
            }
        }
        if (!flag){
            return 1;
        }
        for (User user : users01) {
            if (name.equals(user.getName())&&passWord.equals(user.getPwd())){
                return 2;
            }
        }
        return 3;
    }

    // TODO 注册选项
    public int reg(String newname, String newpassWord) {
        for (User user : users01) {
            if (newname.equals(user.getName())) {
                return 1;
            }
        }
        User user = new User(newname, newpassWord);
        users01.add(user);
        try {
            FileWriter fileWriter = new FileWriter(AppContext.DB_PATH,true);
            fileWriter.write(user.toString());
            fileWriter.flush();
            return 2;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return 3;
    }
}


