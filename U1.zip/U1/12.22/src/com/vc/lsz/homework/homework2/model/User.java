package com.vc.lsz.homework.homework2.model;

import java.io.Serializable;

/**
 * @ClassName User
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 12:32 上午
 * @Version 1.0
 */
public class User implements Serializable {
    static final long serialVersionUID = 42L;
    private String name;
    private String pwd;

    public User() {
    }

    public User(String name, String pwd) {
        this.name = name;
        this.pwd = pwd;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", pwd='" + pwd + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
}
