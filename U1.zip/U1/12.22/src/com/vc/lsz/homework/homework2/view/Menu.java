package com.vc.lsz.homework.homework2.view;

import com.vc.lsz.homework.homework2.controller.UserController;
import com.vc.lsz.homework.homework2.utile.ScannerUtil;

/**
 * @ClassName Menu
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 12:30 上午
 * @Version 1.0
 */
public class Menu {
    UserController instance = UserController.getInstance();

    public void show() {
        do {
            System.out.println("请选择");
            System.out.println("1.登录");
            System.out.println("2.注册");
            int choice = ScannerUtil.getInt(1, 2);
            showMeun(choice);
        } while (true);

    }

    // TODO 首页判断
    private void showMeun(int choice) {
        switch (choice) {
            case 1:
                showLogin();
                break;
            case 2:
                showReg();
                break;
            default:
                System.out.println("输入错误请重新选择");
                show();
                break;
        }
    }

    // TODO 注册子菜单
    private void showReg() {
        System.out.println("请输入用户名");
        String newname = ScannerUtil.getString();
        System.out.println("请输入用户密码");
        String newpassWord = ScannerUtil.getString();
        int reg = instance.reg(newname, newpassWord);
        switch (reg){
            case 1:
                System.out.println("用户存在,请重新选择");
                show();
                break;
            case 2:
                System.out.println("注册成功");
                break;
            case 3:
                System.out.println("注册异常");
                show();
                break;
            default:
                System.out.println("系统异常请重新选择");
                show();
                break;
        }
    }

    // TODO 登录输入菜单
    private void showLogin() {
        System.out.println("请输入用户名");
        String name = ScannerUtil.getString();
        System.out.println("请输入用户密码");
        String passWord = ScannerUtil.getString();
        int lg = instance.login(name,passWord);
        switch (lg){
            case 1:
                System.out.println("用户不存在,请重新选择");
                show();
                break;
            case 2:
                System.out.println("登录成功");
                break;
            case 3:
                System.out.println("账户或密码错误");
                show();
                break;
            default:
                System.out.println("系统异常请重新选择");
                show();
                break;
        }
    }
}
