package com.vc.lsz.demo2;


import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 * @ClassName IOStream2
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/22 11:09 上午
 * @Version 1.0
 */
public class IOStream2 {
    public static void main(String[] args) {
        FileOutputStream file = null;
        try {
            file = new FileOutputStream("readme.txt",true);

//            byte[] readme = new byte[3];
            System.out.println("请输入要追加的英文：");
            Scanner scanner = new Scanner(System.in);
            String input = scanner.next();
//            System.out.println();
            file.write(("\r\n" + input).getBytes(StandardCharsets.UTF_8));

//            int length = file.write(readme);



        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if (file != null){
                try {
                    file.close();
                } catch (Exception e) {
//                    e.printStackTrace();
                }
            }
        }
    }
}
