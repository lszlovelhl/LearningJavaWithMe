package com.vc.lsz.demo3;

import java.io.*;
import java.util.Scanner;

/**
 * @ClassName IOStream3
 * @auther lsz1310225074@iCloud.com
 * @Description TODO 批量读写文件，边读边写
 * @date 2021/12/22 11:38 上午
 * @Version 1.0
 */
public class IOStream3 {
    public static void main(String[] args) {
        System.out.println("请输入源文件夹：");
        Scanner scanner = new Scanner(System.in);
        //        源文件夹
        String oldDir = scanner.next();
        System.out.println("请输入目标文件夹：");
        //        目标文件夹
        String newDir = scanner.next();

//        根据输入的文件名获取文件的绝对路径
        String oldPath = new File(oldDir).getAbsolutePath();
        String newPath = new File(newDir).getAbsolutePath();


//        验证源文件夹和目标文件夹是否存在
        File oldFolder = new File(oldPath);
//        判断是否为文件夹
        if (!oldFolder.isDirectory()){
            System.out.println("请输入文件夹：");
            return;
        }

        if (!oldFolder.exists()) {
            System.out.println("源文件夹不存在");
            return;
        }
        File newFolder = new File(newPath);

        if (!newFolder.exists()) {
            System.out.println("目标不存在，创建中...");
            newFolder.mkdirs();
        }

        //文件复制
        InputStream in = null;
        OutputStream out = null;
        //字节缓冲
        byte[] buffer = new byte[1024];
        //创建目标文件
        File destFile = new File(newFolder, oldFolder.getName());
        try {
            in = new FileInputStream(oldFolder);
            out = new FileOutputStream(destFile);
            while (true) {
                int len = in.read(buffer);
                if (len == -1) {
                    break;
                }
                //写入数据
                out.write(buffer, 0, len);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //后开先关
            if (out != null) {
                try {
                    out.close();
                } catch (Exception e) {
                }
            }
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                }
            }
        }


    }

//    public static void copyFile(File file) {
//        复制文件
//        InputStream input = null;
//        OutputStream output = null;
////        设置缓冲区
//        byte[] buffer = new byte[1024];
////        创建目标文件
//        File newFile = new File()
//    }

    public static boolean fileType(File file) {
        if (file.isDirectory()) {
            File[] son = file.listFiles();
            if (son.length == 0) {
//                复制文件夹
//                copyFile(file);
            }
            for (File sonFile : son) {
//                递归判断子文件中是否包含文件夹
                fileType(sonFile);
            }
        }
//        复制文件夹
//        copyFile(file);

        return false;
    }

}
