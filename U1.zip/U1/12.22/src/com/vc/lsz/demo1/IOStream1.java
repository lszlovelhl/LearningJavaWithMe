package com.vc.lsz.demo1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * @ClassName IOStream1
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/22 10:47 上午
 * @Version 1.0
 */
public class IOStream1 {
    public static void main(String[] args) {
        FileInputStream file = null;
        try {
            file = new FileInputStream("readme.txt");

            byte[] readme = new byte[7];
            while (true) {
                int length = file.read(readme);
                if (length == -1) {
                    break;
                }
                System.out.print(new String(readme,0,length));
            }

//            file.read();



        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            if (file == null) {
                return;
            }

            try {
                file.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
