Hello Java!
This is IO test...你好
asd

123
qwe