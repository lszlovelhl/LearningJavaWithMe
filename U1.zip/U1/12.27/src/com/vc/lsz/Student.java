package com.vc.lsz;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName Student
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/27 10:37 上午
 * @Version 1.0
 */
public class Student {
    private int id;
    private String name;
    private int chineseScore;
    private int mathScore;
    private String sex;
    private int age;

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", chineseScore=" + chineseScore +
                ", mathScore=" + mathScore +
                ", sex='" + sex + '\'' +
                ", age=" + age +
                '}';
    }

    public Student(int id, String name, int chineseScore, int mathScore, String sex, int age) {
        this.id = id;
        this.name = name;
        this.chineseScore = chineseScore;
        this.mathScore = mathScore;
        this.sex = sex;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getChineseScore() {
        return chineseScore;
    }

    public void setChineseScore(int chineseScore) {
        this.chineseScore = chineseScore;
    }

    public int getMathScore() {
        return mathScore;
    }

    public void setMathScore(int mathScore) {
        this.mathScore = mathScore;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }



}

