package com.vc.lsz;

import java.util.ArrayList;
import java.util.List;
import java.util.function.ToIntFunction;
import java.util.stream.Stream;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/27 10:36 上午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {

        List<Student> stuList = new ArrayList() {
            {
                add(new Student(1, "张三", 98, 56, "男", 22));
                add(new Student(2, "张三疯", 55, 88, "男", 35));
                add(new Student(3, "张大大", 98, 75, "女", 45));
                add(new Student(4, "刘一手", 45, 88, "男", 24));
                add(new Student(5, "王春花", 79, 66, "女", 55));
                add(new Student(6, "李明亮", 34, 58, "男", 32));
                add(new Student(7, "赵老六", 75, 26, "男", 24));
                add(new Student(8, "李小多", 37, 76, "女", 56));
            }
        };

        /**
         * 打印所有男生信息
         */
        stuList.stream().filter(student -> student.getSex().equals("男")).forEach(student -> System.out.println(student));

        System.out.println("分割线————————————————————————————————————————————————");

        /**
         * 年龄升序排列
         */
        stuList.stream().filter(student -> student.getSex().equals("男"))
                .sorted((s1,s2) -> s1.getAge() - s2.getAge()).forEach(student -> System.out.println(student));

        System.out.println("分割线————————————————————————————————————————————————");

        /**
         * 两科都及格的学生数量
         */
        long count = stuList.stream().filter(student -> student.getChineseScore() >= 60 && student.getMathScore() >= 60)
                .count();
        System.out.println("两科都及格的学生数为" + count);

        System.out.println("分割线————————————————————————————————————————————————");

        /**
         * 总分最低的三人
         */
        stuList.stream().sorted((sc1,sc2) -> sc1.getChineseScore() - sc2.getChineseScore())
                .sorted((sc1,sc2) -> sc1.getMathScore() - sc2.getMathScore())
                .limit(3).forEach(student -> System.out.println(student));

        System.out.println("分割线————————————————————————————————————————————————");

        /**
         * 语文成绩不及格的男生中年龄最大的一个
         */
        stuList.stream().filter(student -> student.getChineseScore() < 60 && student.getSex().equals("男"))
                .sorted((stu1,stu2) -> stu1.getAge() - stu2.getAge()).limit(1)
                .forEach(student -> System.out.println(student));

        System.out.println("分割线————————————————————————————————————————————————");

        /**
         * 所有男生语文成绩总分
         */
        long score = stuList.stream().filter(student -> student.getSex().equals("男"))
                .mapToInt(Student::getChineseScore)
                .sum();
        System.out.println(score);
        System.out.println("分割线————————————————————————————————————————————————");

        /**
         * 所有学生的姓氏不重复
         */
        stuList.stream().map(student -> student.getName().substring(0,1))
                .distinct()
                .forEach(stu-> System.out.println(stu));

        System.out.println("分割线————————————————————————————————————————————————");
    }
}
