package com.vc.lsz.client.thread;

import com.vc.lsz.client.socket.Client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @ClassName ProcessServerThread
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/11 10:01 上午
 * @Version 1.0
 */

public class ProcessServerThread extends Thread {
    public ProcessServerThread() {
        setDaemon(true);
    }

    @Override
    public void run() {
        //接收服务器消息
        try {
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            Client.getInstance().getInputStream()
                    )
            );
            while (true) {
                String str = in.readLine();
                System.out.println(str);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


//public class ProcessServerThread extends Thread{
//    private Client client;
//    public ProcessServerThread(Client client) {
//        this.client = client;
//        setDaemon(true);
//    }
//
//    @Override
//    public void run() {
//        BufferedReader bufferedReader = null;
//        try {
//            bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
//            while (true) {
//                String reade = bufferedReader.readLine();
//                System.out.println(reade);
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}
