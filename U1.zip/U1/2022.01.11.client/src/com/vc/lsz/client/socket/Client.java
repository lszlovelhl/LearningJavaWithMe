package com.vc.lsz.client.socket;

import com.vc.lsz.common.MessageType;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * @ClassName com.vc.lsz.Client
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:38 下午
 * @Version 1.0
 */

public class Client extends Socket {
    private static Client instance;

    public static Client getInstance() {
        if (instance == null || instance.isClosed()) {
            try {
                instance = new Client();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return instance;
    }

    private Client() throws IOException {
        super("127.0.0.1", 9527);
    }

    /**
     * 发送登录请求(同步)
     *
     * @param name 用户名
     * @param pwd  密码
     * @return 登录结果:-1 通讯失败 ,0 用户名不存在, 1 密码错误, 2 登录成功
     */
    public int sendLogin(String name, String pwd) {
        try {
            DataOutputStream outputStream = new DataOutputStream(
                    this.getOutputStream()
            );
            DataInputStream inputStream = new DataInputStream(
                    this.getInputStream()
            );
            //写出消息头
            outputStream.writeByte(MessageType.LOGIN);
            //写消息正文
            outputStream.writeUTF(name);
            outputStream.writeUTF(pwd);
            //读取服务器响应
            return inputStream.readByte();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public void sendChat(String message) {
        try {
            DataOutputStream outputStream = new DataOutputStream(
                    this.getOutputStream()
            );
            //写出消息头
            outputStream.writeByte(MessageType.CHAT);
            //写消息正文
            outputStream.writeUTF(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 发送注册请求
     * @param name
     * @param pwd
     * @return 结果:-1 通讯失败 ,0 用户名存在, 2 注册成功
     */
    public int sendSignIn(String name, String pwd) {
        try {
            DataOutputStream outputStream = new DataOutputStream(this.getOutputStream());
            DataInputStream inputStream = new DataInputStream(this.getInputStream());
            outputStream.writeByte(MessageType.SIGN_IN);
            outputStream.writeUTF(name);
            outputStream.writeUTF(pwd);
            return inputStream.readByte();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }
}


//public class Client extends Socket {
//    private static Client instance;
//
//    public static Client getInstance() {
//        if (instance == null) {
//            try {
//                instance = new Client();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        return instance;
//    }
//
//    private Client() throws IOException {
//        super(ServerContext.HOST, ServerContext.PORT);
//    }
//
//
//    public int sendLogin(String name, String pwd) {
//        try {
//            DataOutputStream outputStream = new DataOutputStream(this.getOutputStream());
//            DataInputStream inputStream = new DataInputStream(this.getInputStream());
//            //消息头
//            outputStream.writeByte(MessageType.LOGIN);
//            //消息正文
//            outputStream.writeUTF(name);
//            outputStream.writeUTF(pwd);
//            //读取服务器响应
//            return inputStream.readByte();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return -1;
//    }
//
//    public int sendSignIn(String name, String pwd) {
//        try {
//            DataOutputStream outputStream = new DataOutputStream(this.getOutputStream());
//            DataInputStream inputStream = new DataInputStream(this.getInputStream());
//            //写消息头
//            outputStream.writeByte(MessageType.SIGN_IN);
//            //写消息正文
//            outputStream.writeUTF(name);
//            outputStream.writeUTF(pwd);
//            //读取响应
//            return inputStream.readByte();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return -1;
//    }
//
//    public void sendChat(String message) {
//        new ProcessServerThread(this).start();
//        try {
////            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(this.getOutputStream()));
//            DataOutputStream outputStream = new DataOutputStream(this.getOutputStream());
////            DataInputStream inputStream = new DataInputStream(this.getInputStream());
//            while (true) {
//                outputStream.writeByte(MessageType.CHAT);
//                outputStream.writeUTF(message);
////                bufferedWriter.write(message);
////                bufferedWriter.newLine();
////                bufferedWriter.flush();
//                if (message.equalsIgnoreCase("exit")) {
//                    this.close();
//                    ServerContext.onlineUsers.remove(this);
//                    return;
//                }
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
////    public void begin() {
////        new ProcessServerThread(this).start();
////        sendMessage();
////    }
//
////    public void begin(){
////        new ProcessServerThread(this).start();
////        sendMessage();
////    }
////
////    private void sendMessage() {
////        try {
////            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(this.getOutputStream()));
////            while (true) {
////                Scanner scanner = new Scanner(System.in);
////                System.out.println("请输入发送给服务器的信息(输入exit退出)");
////                String data = scanner.nextLine();
////                bufferedWriter.write(data);
////                bufferedWriter.newLine();
////                bufferedWriter.flush();
////                if (data.equalsIgnoreCase("exit")) {
////                    close();
////                    return;
////                }
////            }
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////    }
//}
