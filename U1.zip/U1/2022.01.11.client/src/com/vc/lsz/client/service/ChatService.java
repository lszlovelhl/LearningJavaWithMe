package com.vc.lsz.client.service;

public interface ChatService {
    void sendChat(String word);

    void close();
}
