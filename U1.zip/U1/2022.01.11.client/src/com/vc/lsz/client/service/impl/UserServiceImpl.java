package com.vc.lsz.client.service.impl;


import com.vc.lsz.client.service.UserService;
import com.vc.lsz.client.socket.Client;

/**
 * @ClassName UserServiceImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:55 下午
 * @Version 1.0
 */

public class UserServiceImpl implements UserService {

    @Override
    public int login(String name, String pwd) {
        //发送消息
        return Client.getInstance().sendLogin(name, pwd);
    }

    @Override
    public int signIn(String name, String pwd) {
        return Client.getInstance().sendSignIn(name,pwd);
    }
}

//public class UserServiceImpl implements UserService {
//    @Override
//    public int login(String name, String pwd) {
//        return Client.getInstance().sendLogin(name, pwd);
//    }
//
//    @Override
//    public int signIn(String name, String pwd) {
//        return Client.getInstance().sendSignIn(name,pwd);
//    }
//
//    @Override
//    public void chat(String message) {
//        Client.getInstance().sendChat(message);
//    }
//}
