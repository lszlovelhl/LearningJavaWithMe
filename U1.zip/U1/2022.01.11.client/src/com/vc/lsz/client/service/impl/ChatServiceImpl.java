package com.vc.lsz.client.service.impl;


import com.vc.lsz.client.service.ChatService;
import com.vc.lsz.client.socket.Client;

import java.io.IOException;

/**
 * author: VC
 * create: 2022/1/11 14:13
 * version: 1.0.0
 */
public class ChatServiceImpl implements ChatService {
    @Override
    public void sendChat(String word) {
        Client.getInstance().sendChat(word);
    }

    @Override
    public void close() {
        try {
            Client.getInstance().close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
