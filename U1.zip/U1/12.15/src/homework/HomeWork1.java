package homework;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/15 5:31 下午
 */
public class HomeWork1 {
    public static void main(String[] args) {

        String[] badguy = new String[]{"法克鱿", "卧槽", "你大爷"};
        System.out.println("请输入聊天内容：");
        Scanner scanner = new Scanner(System.in);
        String chat = scanner.next();

//        do {
        for (int i = 0; i < badguy.length; i++) {
            /**
             * 根据数组元素长度打印对应数量的*
             */
            int b1 = badguy[0].length();
            int b2 = badguy[1].length();
            int b3 = badguy[2].length();
            System.out.println(b1);
//            for (int j = 0; j < badguy[i].length(); j++) {
//                String replace = "*";
//            }

//            int bad;
//            bad = badguy[i].length();
//            String badlength;
//            badlength = String.valueOf("*" * bad);
//            for (int j = 0; j < chat.length(); j++) {
            /**
             * 判断是否包含指定字符串
             */
            boolean flag = chat.contains(badguy[i]);
            if (flag) {
                String sum = String.join("",chat.replaceAll(badguy[i], "*"));
//                newchat = sum;
                chat = sum;

            }else {
                System.out.println("不包含脏话");
                break;
            }

//                String chatcontent = String.valueOf(chat.charAt(i));
//                String[] newchat = new String[chat.length()];
//                if (chatcontent == badguy[i]) {
//                    chatcontent.replaceAll(badguy[i], "*");
//
//                    System.arraycopy(chat, 0, newchat, 0, chat.length());
//
//                }
//                System.out.print(newchat);
//            }
        }System.out.println(chat);

//        } while (true);
    }
}
