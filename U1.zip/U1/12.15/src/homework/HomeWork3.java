package homework;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/15 5:31 下午
 */
public class HomeWork3 {
    public static void main(String[] args) {
        String mail;
        System.out.println("请输入一个邮箱：");
        Scanner scanner = new Scanner(System.in);
        mail = scanner.next();

        int headfirstindex = mail.indexOf("@");
        int lastfirstindex = mail.lastIndexOf(".");
        System.out.println(headfirstindex);
        System.out.println(lastfirstindex);
        String mail1 = mail.substring(0, headfirstindex);
        String mail2 = mail.substring(headfirstindex + 1,lastfirstindex);
        System.out.println("用户名为" + mail1 + "域名为" + mail2);
//        System.out.println();

//        System.out.println(mail.indexOf("@"));
//        System.out.println(mail.lastIndexOf("."));
//        mail = mail.substring(mail.indexOf("@") + 1,mail.lastIndexOf("."));
//        System.out.println("域名为" + mail);

//        int lastfirstindex = mail.lastIndexOf("@");
//        mail = mail.lastIndexOf("@");
//        System.out.println("域名为" + mail);

    }
}
