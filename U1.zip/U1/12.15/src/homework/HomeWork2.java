package homework;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/15 5:31 下午
 */
public class HomeWork2 {
    public static void main(String[] args) {
        System.out.println("请输入一段文本：");
        String text;
        Scanner scanner = new Scanner(System.in);
        text = scanner.next();
        for (int i = text.length() - 1; i >= 0; i--) {
            System.out.print(text.charAt(i));
        }
        System.out.println();
    }
}
