package homework;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/15 5:32 下午
 */
public class HomeWork6 {
    public static void main(String[] args) {
        System.out.println("请输入一段话，左右带空格:");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.next();
        String delnull = input.trim();
        System.out.println(delnull + " ");
    }

//    String rtrim(String str) {
//
//        return null;
//    }
}
