package homework;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/15 5:32 下午
 */
public class HomeWork4 {
    public static void main(String[] args) {
        do {
        System.out.println("请输入身份证号码(15~18位)：");
        String peoplesnum;
        Scanner scanner = new Scanner(System.in);
        peoplesnum = scanner.next();

            if (peoplesnum.length() != 15 && peoplesnum.length() != 18) {
                System.out.println("号码输入错误，请重新输入");
                break;
            }
            if (peoplesnum.length() == 15 || peoplesnum.length() == 18) {
                int thelastnum = Integer.parseInt(peoplesnum.substring(peoplesnum.length() - 2, peoplesnum.length() - 1));
                int thesecondlastnum = Integer.parseInt(peoplesnum.substring(peoplesnum.length() - 3,peoplesnum.length() - 2));
                if (thelastnum % 2 == 0) {
                    System.out.println("此身份证号码对应性别为女");
                    continue;
                }
                if(thelastnum % 2 != 0) {
                    System.out.println("此身份证号码对应性别为男");
                    continue;
                }
                if (thesecondlastnum % 2 == 0) {
                    System.out.println("此身份证号码对应性别为女");
                    continue;
                }
                if (thesecondlastnum % 2 != 0){
                    System.out.println("此身份证号码对应性别为男");
                    continue;
                }
            }
            break;

//            if (peoplesnum.length() == 18) {
//
//                if (thesecondlastnum % 2 == 0) {
//                    System.out.println("此身份证号码对应性别为女");
//                } else {
//                    System.out.println("此身份证号码对应性别为男");
//                }
//                break;
//            }
        }while (true) ;
    }
}
