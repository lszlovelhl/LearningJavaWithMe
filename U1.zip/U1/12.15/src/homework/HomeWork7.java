package homework;

import java.util.Arrays;

/**
 * @auther XXX@abc.com
 * @date 2021/12/15 5:32 下午
 */
public class HomeWork7 {
    public static void main(String[] args) {
        String content = "1000,jack,76,18\n" +
                "1001,rose,98,19\n" +
                "1002,mike,26,20\n" +
                "1003,allen,31,21";
        for (int i = 0; i < content.length(); i++) {
            String[] cut = content.split("\n");
            for (int j = 0; j < cut.length; j++) {
                String[] cutagn = cut[j].split(",");
                for (int k = 0; k < cutagn.length; k++) {
                    String[] score = new String[4];
//                    System.out.println(Arrays.toString(cutagn));
//                    int[] score = new int[4];
                    for (int l = 0; l < score.length; l++) {
                        cutagn[2] = score[l];
                        System.out.println(Arrays.toString(score));

                        break;
//                    }
//                    break;
                    }
                    break;
                }
            }break;
        }
    }
}
