package homework;

/**
 * @auther XXX@abc.com
 * @date 2021/12/15 6:14 下午
 */
public class test {
    public static void main(String[] args) {
        String word = "abc@qq.edu.cn";
        //      012345678910
        System.out.println(word.indexOf("."));
        System.out.println(word.lastIndexOf("."));
        word = word.substring(word.indexOf(".") + 1, word.lastIndexOf("."));
        System.out.println(word);
    }
}
