package homework;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/15 5:32 下午
 */
public class HomeWork5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入:");
        String str = sc.nextLine();
        char[] words = new char[str.length()];
        int[] counts = new int[str.length()];
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            for (int j = 0; j < words.length; j++) {
                if (words[j] == ch) {
                    counts[j]++;
                    break;
                }
                if (words[j] == 0) {
                    words[j] = ch;
                    counts[j]++;
                    break;
                }
            }
        }
        System.out.println("共有字符:");
        for (int i = 0; i < words.length; i++) {
            if (words[i] == 0) {
                break;
            }
            System.out.println(words[i] + ":" + counts[i]);
        }
    }
}