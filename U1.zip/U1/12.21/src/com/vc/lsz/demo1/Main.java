package com.vc.lsz.demo1;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/21 10:28 上午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
        Class student = Student.class;

//        try {
//            Constructor constructor = student.getConstructor();
//            constructor.setAccessible(true);
//            Object obj = constructor.newInstance();
//
//
//
//            System.out.println(obj);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

//        try {
//            Constructor constructor = student.getDeclaredConstructor(String.class, int.class);
//
//            Object obj = constructor.newInstance("林青霞",30);
//
//            System.out.println(obj);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        try {
            Constructor constructor = student.getDeclaredConstructor();
            Object object = constructor.newInstance();
            constructor.setAccessible(true);
            Field stuAge = student.getDeclaredField("age");
            Field stuName = student.getDeclaredField("name");
            stuAge.setAccessible(true);
            stuName.setAccessible(true);
            Object v = stuName.get(object);
            System.out.println("原值：" + v);
            Object value = stuAge.get(object);
            System.out.println("原值:" + value);

            stuAge.set(value, 30);
            stuName.set(v, "林青霞");
            System.out.println(value);
            System.out.println(v);

//            Constructor constructor = student.getDeclaredConstructor();
//            Object object = constructor.newInstance();
//            constructor.setAccessible(true);






        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
