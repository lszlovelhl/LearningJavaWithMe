package com.vc.lsz.demo1;

/**
 * @ClassName Test1
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/21 10:20 上午
 * @Version 1.0
 */
public class Student {
        private String name;
        private int age;

        public void show(){
            System.out.println("大家好，我叫" + name);
        }

        public String show(String slogin, int salary){
            return "我叫" + name + ",我的座右铭是" + slogin + ",我期待的月薪是" + salary;
        }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    public Student(String name, int age){
            super();
            this.name = name;
            this.age = age;
        }



        public Student(){
            super();
        }
    }