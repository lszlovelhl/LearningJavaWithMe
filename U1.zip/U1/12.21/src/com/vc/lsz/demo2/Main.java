package com.vc.lsz.demo2;

import java.io.File;
import java.io.FileFilter;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO 打印.java文件
 * @date 2021/12/21 2:37 下午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
//        文件位置
        File folder = new File("/Users/longshizhuo/IdeaProjects/U1/12.21/src/com/vc/lsz/demo");
        /**
         * 获取文件夹中的.java文件
         */
//        匿名内部类
        File[] javaarr = folder.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
//                判断是否是文件
                if (!file.isFile()) {
                    return false;
                }
//                判断是否是.java文件
                String filename = file.getName();
//                将文件名全部转小写
                filename = filename.toLowerCase();
                return filename.endsWith(".java");
            }
        });

//        遍历获取的Java文件
        for (File file : javaarr) {
            System.out.println("demo内所有.java文件为：" + file);
        }
    }


/**
 * 打印.java文件
 * 如果是文件，直接打印
 * 如果是文件夹，查看文件夹内部子元素，判断是否为文件，是文件直接打印。。。（递归）
 */
private void shpw(File file){
    if (file.isFile()){
        System.out.println(file);
        return;
    }
    if (file.isDirectory()){
        File[] sonFile = file.listFiles();
        if (sonFile.length == 0){
            System.out.println(file);
            return;
        }
        for (File sonFiles : sonFile){
            System.out.println(sonFiles);
        }


    }
}
}
/**
 * 删除.java文件
 */

//    private static boolean delete(File file) {
//        //        判断是否是文件
//        if (file.isFile()) {
//            file.delete();
//            return true;
//        }
//        if (file.isDirectory()) {
//            File[] sunFile = file.listFiles();
////            没有子元素即可删除
//            if (sunFile.length == 0) {
//                file.delete();
//                return true;
//            }
//            /**
//             * 文件夹存在子元素，将其遍历并用递归方法删除
//             */
//            for (File sunFiles : sunFile) {
//                delete(sunFiles);
//            }
//            return file.delete();
//        }
//        return file.delete();
//    }
//
//    private static boolean delete(String path) {
//        File file = new File(path);
//        return delete(file);
//    }
//}
