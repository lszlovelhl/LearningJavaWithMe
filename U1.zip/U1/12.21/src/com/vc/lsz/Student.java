package com.vc.lsz;

public class Student {
	private String name;
	private String sex;
	
	public String toString(){
		return "大家好,我叫" + name + ", 性别 " + sex;
	}
}


