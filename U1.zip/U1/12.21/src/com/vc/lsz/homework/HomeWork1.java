package com.vc.lsz.homework;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/**
 * @ClassName HomeWork1
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/21 10:04 下午
 * @Version 1.0
 */
public class HomeWork1 {
    public static void main(String[] args) {
        System.out.println("请输入文件夹路径：");
        Scanner scanner = new Scanner(System.in);
        String path = scanner.next();
        File folder = new File(path);

//        如果文件夹不存在
        if (!folder.exists()){
//            创建文件夹(包括不存在的父路径)
            folder.mkdirs();
            return;
        }else {
            System.out.println("请输入文件名路径：");
            String filepath = scanner.next();
            File file = new File(filepath);

            if (file.exists()){
                System.out.println("文件已存在");
            }else {
                try {
                    file.createNewFile();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            System.out.println("此文件的文件名为：" + file.getName() + "路径为：" + file.getAbsolutePath());

        }

        System.out.println("此文件夹的绝对路径为：" + folder.getAbsolutePath());








    }
}
