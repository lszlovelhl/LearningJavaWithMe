package com.vc.lsz.homework;

import com.vc.lsz.Student;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;

/**
 * @ClassName HomeWork3
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/21 11:23 下午
 * @Version 1.0
 */
public class HomeWork3 {
    public static void main(String[] args) {

        Properties properties = new Properties();

        try {
            properties.load(HomeWork3.class.getResourceAsStream("reflect.properties"));
            String className = properties.getProperty("className");
            String fieldNames = properties.getProperty("fieldNames");
            String fieldValues = properties.getProperty("fieldValues");

            Class student = Student.class;
            Object obj = student.newInstance();


        } catch (Exception e) {
            e.printStackTrace();
        }

//        File prop = new File("12.21/src/com/vc/lsz/reflect.properties");

//        try {
//            Constructor constructor = student.getDeclaredConstructor();
//            Object obj = constructor.newInstance();
//            Field stuname = student.getDeclaredField("name");
//            Field stusex = student.getDeclaredField("sex");
//            stuname.setAccessible(true);
//            stusex.setAccessible(true);
//            Object namevalue = stuname.get(obj);
//            Object sexvalue = stusex.get(obj);
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }
}
