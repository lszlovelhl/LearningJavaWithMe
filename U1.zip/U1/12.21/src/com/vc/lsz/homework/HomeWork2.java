package com.vc.lsz.homework;

import java.io.File;
import java.io.FileFilter;
import java.util.Arrays;
import java.util.Scanner;

/**
 * @ClassName HomeWork2
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/21 10:39 下午
 * @Version 1.0
 */
public class HomeWork2 {
    public static void main(String[] args) {
        System.out.println("请输入文件夹路径：");
        Scanner scanner = new Scanner(System.in);
        String folderpath = scanner.next();
        File file = new File(folderpath);
        if (!file.isDirectory()) {
            System.out.println("输入错误");
            return;
        }
        File[] sonfile = file.listFiles(new FileFilter() {
            @Override
            public boolean accept(File pathname) {
                if (file.isFile()) {
                    sum(file);
//                    count++;
                    return false;
                }
                sum(file);
                return true;

            }
        });

    }

    private static int sum(File file) {
        int count = 0;
        if (file.isFile()) {
//                return count++;
//                if () {
            File[] sonfile = file.listFiles();
            if (sonfile.length == 0) {
//                count++;
                return count++;
            }
            for (File sonfiles : sonfile) {
                sum(sonfiles);
            }
//                return count;
//                }
        }
        System.out.println("文件夹中共有" + count + "个文件");
        return count++;
//            return count;
    }
}
