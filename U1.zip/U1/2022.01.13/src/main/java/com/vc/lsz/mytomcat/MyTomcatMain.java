package com.vc.lsz.mytomcat;

import com.sun.tools.javac.Main;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * @ClassName MyTomcatMain
 * @auther lsz1310225074@iCloud.com
 * @Description TODO BS架构项目主程序入口
 * @date 2022/1/12 2:40 下午
 * @Version 1.0
 */
public class MyTomcatMain {
    public static void main(String[] args) throws IOException {

//        URL url = Main.class.getClassLoader().getResource("/webapps/MySchool/index.html");
//        try {
//            File file = new File(url.toURI());
//        } catch (URISyntaxException e) {
//            e.printStackTrace();
//        }

        //开启服务器
        ServerSocket server = new ServerSocket(8080);
        while (true) {
            Socket socket = server.accept();
            new ProcessClientThread(socket).start();
        }
    }
}
