package com.vc.lsz.mytomcat;

import com.sun.tools.javac.Main;

import java.io.*;
import java.net.Socket;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName ProcessClientThread
 * @auther lsz1310225074@iCloud.com
 * @Description TODO BS架构项目
 * @date 2022/1/12 2:42 下午
 * @Version 1.0
 */
public class ProcessClientThread extends Thread {
    private Socket socket;

    public ProcessClientThread(Socket socket) {
        this.socket = socket;
        //守护线程
        setDaemon(true);
    }

    /**
     * HTTP协议BS架构短连接，获取请求行请求头及请求数据(根据请求方式POST/GET),写入状态行响应头及响应正文
     */
    @Override
    public void run() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            //读取请求行
            //请求行有三部分内容：请求方法、URL、协议版本，三者之间用空格分隔，结尾有\r\n
            String requestLine = reader.readLine();
            if (requestLine == null) {
                return;
            }
            String[] rLine = requestLine.split(" ");

            //请求方法
            String requestMethod = rLine[0];
//            System.out.println(requestMethod);
            //URL
            String url = rLine[1];
//            System.out.println(url);
            //协议版本
            String protocol = rLine[2];
//            System.out.println(protocol);

            //读取请求头
            //请求头内容为多条，格式为：头部字段名:值，结尾有\r\n，内容结束标志为：空内容\r\n，此处空内容为空文本而非空地址
            //由于请求头内容的存储方式为键值对，所以可用Map集合来存储
            Map<String, String> requestHead = new HashMap<String, String>();

            //判断是否读完，由于读完标识中的空内容为空文本，故当读到的内容长度为0即表示已读完，或者当读到的内容为null时表示读完，避免出现死循环,readLine本身包含\r\n，故不影响读取的内容
            while (true) {
                String head = reader.readLine();
                if (head.length() == 0 || head == null) {
                    break;
                }
                String[] rHead = head.split(":");
                //兼容大小写，将获取内容转为小写，值之前(:之后)有一个空格，故左右去空格
                requestHead.put(rHead[0].toLowerCase(), rHead[1].trim());
//                System.out.println(requestHead);
            }

            //读取请求数据
            //本项目中请求数据为用户名和密码，类似于键值对，故使用Map集合存储和显示
            Map<String, String> requestData = new HashMap<String, String>();
            //请求数据的位置根据请求方法的不同而不同
            //当请求方法为POST时，请求数据在请求头部字段中，可以通过content_length字段获取
            if (requestMethod.equalsIgnoreCase("post")) {
                int postLength = Integer.parseInt(requestHead.get("content-length"));
                //content-length字段存储的长度为字符数而非字节数
                char[] rData = new char[postLength];
                postLength = reader.read(rData);
                String line = new String(rData, 0, postLength);
                requestData = getRequestData(line);
            } else if (requestMethod.equalsIgnoreCase("get")) {
                //获取?的下标
                int index = url.indexOf("?");
                if (index >= 0) {
                    //从URL里截取参数
                    //line = userName=111&userPwd=222
                    String line = url.substring(index + 1);
                    requestData = getRequestData(line);
                    //处理url
                    url = url.substring(0, index);
                }
            }
            System.out.println("url=" + url);
            for (Map.Entry<String, String> entry : requestData.entrySet()) {
                System.out.println(entry.getKey() + ":" + entry.getValue());
            }

            //写出响应
            writeResponse(writer, url, protocol, requestData);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void writeResponse(BufferedWriter writer,
                               String url,
                               String protocol,
                               Map<String, String> requestData) throws Exception {

        URL resource = this.getClass().getClassLoader().getResource("webapps" + url);
        File file = new File(resource.toURI());
        String resourceUrl = file.getAbsolutePath();
        if (file.isDirectory()){
            resourceUrl = resourceUrl + "/index.html";
        }
        BufferedReader bufferedReader = new BufferedReader(new FileReader(resourceUrl));
        String html;
        StringBuffer stringBuffer = new StringBuffer();
        while ((html = bufferedReader.readLine()) != null) {
            stringBuffer.append(html.trim());
        }
        html = stringBuffer.toString();
//            System.out.println(html);
            //状态行
            writer.write(protocol + " " + " 200 OK");
            writer.newLine();
            //写出响应头
            writer.write("content-type: text/html");
            writer.newLine();
            writer.write("content-length: " + html.length());
            writer.newLine();
            //响应头结束
            writer.newLine();
            //响应正文
            writer.write(html);
        }


//        /Users/longshizhuo/IdeaProjects/U1/2022.01.13/src/main/resources/webapps/MySchool

//        File file = new File("src/main/resources/webapps/MySchool/index.html");
//        FileInputStream inputStream = new FileInputStream(file);
//        InputStreamReader reader = new InputStreamReader(inputStream);
//        BufferedReader bufferedReader = new BufferedReader(reader);


//        FileInputStream inputStream = new FileInputStream(file);
//        InputStreamReader reader = new InputStreamReader(inputStream);
//        BufferedReader bufferedReader = new BufferedReader(reader);


//        InputStream path = this.getClass().getResourceAsStream("src/main/resources/webapps/MySchool/index.html");
//        BufferedReader reader = new BufferedReader(new InputStreamReader(path));
//        String html = null;
//        while ((html = reader.readLine()) != null){
//            System.out.println(html);
//        }
//            //状态行
//            writer.write(protocol + " " + " 200 OK");
//            writer.newLine();
//            //写出响应头
//            writer.write("content-type: text/html");
//            writer.newLine();
//            writer.write("content-length: " + html.length());
//            writer.newLine();
//            //响应头结束
//            writer.newLine();
//            //响应正文
//            writer.write(html);
//        }

//        inputStream.close();
//        reader.close();
//        bufferedReader.close();

//        File html = new File("/webapps/MySchool/index.html");
//        String html = "<html>\n" +
//                "\t<head>\n" +
//                "\t\t<meta charset=\"utf-8\"/>\n" +
//                "\t</head>\n" +
//                "\t<body>\n" +
//                "\t\t<h1>这是学生管理系统</h1>\n" +
//                "\t</body>\n" +
//                "</html>";

    private Map<String, String> getRequestData(String line) {
        Map<String, String> map = new HashMap<>();
        //拆分字符串
        String[] arr = line.split("&");
        //遍历
        for (String item : arr) {
            String[] items = item.split("=");
            map.put(items[0], items[1]);
        }
        return map;
    }
}
