package com.vc.lsz.test2;

/**
 * @auther XXX@abc.com
 * @date 2021/12/14 2:54 下午
 */
public class Laptop extends Computer{


    public Laptop(String brand) {
        super(brand);
    }

    @Override
    public void compute() {
        System.out.println("使用笔记本电脑计算");
    }

    public void facetime(){
        System.out.println("使用笔记本电脑视频聊天");
    }
}

