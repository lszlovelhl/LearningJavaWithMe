package com.vc.lsz.test2;

/**
 * @auther XXX@abc.com
 * @date 2021/12/14 2:54 下午
 */
public abstract class Computer {
    protected String brand;
    public Computer(String brand){

    }
    public abstract void compute();

}
