package com.vc.lsz.test2;

/**
 * @auther XXX@abc.com
 * @date 2021/12/14 2:55 下午
 */
public class Programmer{
    void coding(Computer comp){
        comp.compute();
    }
    public void amuse(Computer comp){
        if (comp instanceof Laptop){
            ((Laptop) comp).facetime();
        }else if (comp instanceof Desktop){
            ((Desktop) comp).playgame();
        }
    }
}
