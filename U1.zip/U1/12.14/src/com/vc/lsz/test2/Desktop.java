package com.vc.lsz.test2;

/**
 * @auther XXX@abc.com
 * @date 2021/12/14 2:54 下午
 */
public class Desktop extends Computer{


    public Desktop(String brand) {
        super(brand);
    }

    @Override
    public void compute() {
        System.out.println("使用台式电脑计算");
    }

    public void playgame(){
        System.out.println("使用台式电脑玩游戏");
    }
}
