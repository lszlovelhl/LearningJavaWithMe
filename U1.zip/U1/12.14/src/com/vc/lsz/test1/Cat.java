package com.vc.lsz.test1;

/**
 * @auther XXX@abc.com
 * @date 2021/12/14 11:45 上午
 */
//public class Cat extends Pat{
//
//
//    public Cat(String name) {
//        super(name);
//    }
//
//
//    @Override
//    public void eat(){
//        System.out.println();
//    }
//}
