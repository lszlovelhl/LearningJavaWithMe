package com.vc.lsz.test1;

/**
 * @auther XXX@abc.com
 * @date 2021/12/14 11:44 上午
 */
//public class Dog extends Pat{
//    public Dog(String name) {
////        super();
//    }
//
//    public Dog(String name, int healthy) {
//        super(name, healthy);
//    }
//
//    public void eat(){
//
//    }
//}
