package com.vc.lsz.test1;

/**
 * @auther XXX@abc.com
 * @date 2021/12/14 11:43 上午
 */
//public class Pat {
//    protected String name;
//    protected int healthy;
//    public Pat(String eat){
//
//    }
//    public Pat(String name,int healthy){
//        this.name = name;
//        this.healthy = healthy;
//    }
//
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public void setHealthy(int healthy) {
//        this.healthy = healthy;
//    }
//
//    public void eat(){
//
//    }
//}
