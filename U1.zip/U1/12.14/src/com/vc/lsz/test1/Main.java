package com.vc.lsz.test1;

/**
 * @auther XXX@abc.com
 * @date 2021/12/14 11:45 上午
 */
//public class Main {
//    Cat cat = new Cat("Tom");
//    Dog dog = new Dog("Jerry");
//

