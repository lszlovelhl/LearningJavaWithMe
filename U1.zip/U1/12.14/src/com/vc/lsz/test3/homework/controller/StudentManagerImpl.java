package com.vc.lsz.test3.homework.controller;

import com.vc.lsz.test3.homework.model.Grade;
import com.vc.lsz.test3.homework.model.Student;

/**
 * author: VC
 * create: 2021/12/14 15:57
 * version: 1.0.0
 */
public class StudentManagerImpl implements StudentDao,GradeDao{

    private Student[] students = new Student[10];
    private Grade[] grades = new Grade[10];

    /**
     * 添加学生
     * @param name 学生姓名
     * @param sex   学生性别
     * @param gradeName 年级编号
     */
    public void addStudent(String name, String sex, String gradeName) {
        //先检测是否有对应的年级
        boolean exists = checkGrade(gradeName);
        if (!exists) {
            //如果年级不存在,则创建年级
            createGrade(gradeName);
        }
        //创建学生
        Student stu = new Student(name, sex, 1);
        //放入数组
        for (int i = 0; i < students.length; i++) {
            if (students[i]==null){
                students[i]=stu;
                break;
            }
        }
    }

    /**
     * 根据id删除学生
     * @param id 学生id
     */
    @Override
    public void deleteStudent(int id) {

    }

    /**
     * 根据学生编号修改学生的其他信息
     *
     * @param id
     * @param name
     * @param sex
     * @param gradeName
     */
    @Override
    public void modifyStudent(int id, String name, String sex, String gradeName) {

    }

    /**
     * 查询所有年级
     * @return
     */
    @Override
    public Grade[] findAllGrade() {
        return new Grade[0];
    }

    /**
     * 查询所有学生
     * @return
     */
    @Override
    public Student[] findAllStudent() {
        return students;
    }

    /**
     * 创建年级
     * @param gradeName
     */
    private void createGrade(String gradeName) {
        Grade grade = new Grade(gradeName);
        //放入数组
        for (int i = 0; i < grades.length; i++) {
            if (!(grades[i]==null)) {
                continue;
            }
            grades[i]=grade;
            break;
        }
    }

    /**
     * 根据年级编号修改年级名
     *
     * @param id
     * @param name
     */
    @Override
    public void modifyGrade(int id, String name) {

    }

    /**
     * 删除年级
     * @param id
     */
    @Override
    public void deleteGrade(int id) {

    }

    /**
     * 检查年级名是否存在
     *
     * @param gradeName
     * @return
     */
    public boolean checkGrade(String gradeName) {
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] == null) {
                continue;
            }
            if (gradeName.equals(grades[i].getName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 添加年级
     * @param gradeName
     */
    @Override
    public void addGrade(String gradeName) {

    }
}
