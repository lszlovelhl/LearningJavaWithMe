package com.vc.lsz.test3.homework;

import com.vc.lsz.test3.homework.model.Grade;
import com.vc.lsz.test3.homework.model.Student;
import com.vc.lsz.test3.homework.view.Menu;

/**
 * author: VC
 * create: 2021/12/14 15:51
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {
            new Menu().showMainMenu();
    }

}
