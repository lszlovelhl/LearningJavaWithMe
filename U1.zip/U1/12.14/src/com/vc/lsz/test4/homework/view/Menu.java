package com.vc.lsz.test4.homework.view;

import com.vc.lsz.test4.homework.controller.StudentManagerImpl;
import com.vc.lsz.test4.homework.model.Grade;
import com.vc.lsz.test4.homework.model.Student;
import com.vc.lsz.test4.homework.view.utils.InputVerification;

import java.util.Scanner;

/**
 * author: VC
 * create: 2021/12/14 15:56
 * version: 1.0.0
 */
public class Menu {
    StudentManagerImpl studentManager = new StudentManagerImpl();

    public void showMainMenu(){
        //1.学生管理
        System.out.println("1.学生管理");
        //2.年级管理
        System.out.println("2.年级管理");
        //科目管理
        System.out.println("3.科目管理");
        //退出系统
        System.out.println("0.退出管理");
        /**
         * 调用主菜单控制
         */
        int mainMenuIntId = InputVerification.getInt(0, 3);
        switch (mainMenuIntId){
            case 1:
                showStudentMenu();
                break;
            case 2:
                showGradeMenu();
                break;
            case 3:
                showSubjectMenu();
                break;
            case 0:
                System.exit(0);
                break;
        }
        showMainMenu();
        return;
    }

    /**
     * 年级子菜单
     */
    private void showGradeMenu() {
        System.out.println("1.查询年级");
        System.out.println("2.增加年级");
        System.out.println("3.修改年级");
        System.out.println("4.删除年级");
        System.out.println("0.返回系统");
        int studentMenuId = InputVerification.getInt(0, 4);
        switch (studentMenuId){
            case 1:
                Grade[] allGrade = studentManager.findAllGrade();
                System.out.println("编号\t\t年级名\n");
                if (allGrade==null){
                    break;
                }
                for (int i = 0; i < allGrade.length; i++) {
                    if (allGrade[i]==null){
                        continue;
                    }
                    System.out.println(allGrade[i].getId()+"\t\t"+allGrade[i].getName());
                }
                break;
            case 2:
                System.out.println("请输入年级名字");
                String gradeName = InputVerification.getString();
                studentManager.addGrade(gradeName);
                break;
            case 3:
                System.out.println("请输入要修改的年级编号");
                int geadeId = InputVerification.getInt(0);
                System.out.println("+++++++++++++待修改的年级编号++++++++++++");
                System.out.println("编号\t\t年级名");
                Grade grade = studentManager.findGradeById(geadeId);
                if (grade==null){
                    System.out.println("输入的年级不存在");
                    break;
                }
                System.out.println(grade.getId()+"\t\t"+grade.getName());
                System.out.println("输入修改后的年级名称");
                String gradeName1 = InputVerification.getString();
                studentManager.modifyGrade(geadeId,gradeName1);
                System.out.println("修改成功");
                break;
            case 4:
                System.out.println("输入要删除的年级编号");
                int gradeId = InputVerification.getInt(0);
                int i = studentManager.deleteGrade(gradeId);
                if (i==2){
                    System.out.println("删除成功");
                }else if (i==1){
                    System.out.println("删除的年级已绑定学生,请修改后再操作");
                }else{
                    System.out.println("输入的年级不存在");
                }
                break;
            case 0:
                showMainMenu();
                return;
        }
        showGradeMenu();
        return;
    }

    /**
     * 学生管理子菜单
     */
    private void showStudentMenu() {
        System.out.println("1.查询学生");
        System.out.println("2.增加学生");
        System.out.println("3.修改学生");
        System.out.println("4.删除学生");
        System.out.println("0.返回系统");
        int studentMenuId = InputVerification.getInt(0, 4);
        switch (studentMenuId){
            case 1:
                System.out.println("学号\t\t姓名\t\t性别\t\t年级名字");
                Student[] allStudent = studentManager.findAllStudent();
                for (int i = 0; i < allStudent.length; i++) {
                    if (!(allStudent[i]==null)){
                        System.out.println(allStudent[i].getId()+"\t\t"+ allStudent[i].getName()
                                +"\t\t"+allStudent[i].getSex()+"\t\t"+allStudent[i].getGradeId());
                    }
                }
                System.out.println();
                break;
            case 2:
                System.out.println("输入学生姓名");
                String name = InputVerification.getString();
                System.out.println("输入学生性别");
                String sex = InputVerification.getString();
                System.out.println("输入年级名字");
                String grade = InputVerification.getString();
                studentManager.addStudent(name,sex,grade);
                System.out.println("添加学生成功\n");
                break;
            case 3:
                System.out.println("输入修改的学生学号");
                int anInt = InputVerification.getInt(1000);
                Student student = studentManager.findStudentById(anInt);
                if (student==null){
                    System.out.println("对应学号的学生不存在");
                    break;
                }
                System.out.println("++++++++++++++待修改的学生信息++++++++++++++");
                System.out.println("学号\t\t姓名\t\t性别\t\t年级名字");
                System.out.println(student.getId()+"\t\t"+student.getName()+"\t\t"+
                        student.getSex()+"\t\t"+student.getGradeId());
                System.out.println("输入修改后的姓名");
                String newName = InputVerification.getString();
                System.out.println("输入修改后的性别");
                String newSex = InputVerification.getString();
                System.out.println("输入修改后的年级");
                String newGrade = InputVerification.getString();
                studentManager.modifyStudent(anInt,newName,newSex,newGrade);
                System.out.println("修改成功\n");
                break;
            case 4:
                System.out.println("输入删除的学生学号");
                int deleteById = InputVerification.getInt(1000);
                boolean flag = studentManager.deleteStudent(deleteById);
                if (flag){
                    System.out.println("删除成功\n");
                }else{
                    System.out.println("输入的学号不存在\n");
                }
                break;
            case 0:
                showMainMenu();
                break;
        }
        showStudentMenu();
        return;
    }
    /**
     * 科目子菜单
     */
    private void showSubjectMenu() {
        System.out.println("1.查询科目");
        System.out.println("2.增加科目");
        System.out.println("3.修改科目");
        System.out.println("4.删除科目");
        System.out.println("0.返回系统");
        int studentMenuId = InputVerification.getInt(0, 4);
        switch (studentMenuId){
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 0:
                showMainMenu();
                break;
        }
    }
}
