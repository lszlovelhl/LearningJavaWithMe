package com.vc.lsz.test4.homework.model;

/**
 * author: VC
 * create: 2021/12/14 15:51
 * version: 1.0.0
 */
public class Grade {
    private static int globalId = 1;

    private int id;
    private String name;

    public Grade() {
    }

    public Grade(String name) {
        this.id = globalId++;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
