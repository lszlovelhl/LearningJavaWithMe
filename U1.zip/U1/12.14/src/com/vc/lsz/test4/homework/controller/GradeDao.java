package com.vc.lsz.test4.homework.controller;

import com.vc.lsz.test4.homework.model.Grade;

public interface GradeDao {
    /**
     * 获取所有年级
     * @return
     */
    Grade[] findAllGrade();
    /**
     * 根据年级编号修改年级名
     *
     * @param id
     * @param name
     */
    void modifyGrade(int id, String name);

    /**
     * 根据年级编号删除年级
     *
     * @param id
     */
    int deleteGrade(int id);

    /**
     * 检查年级名是否存在
     *
     * @param gradeName
     * @return
     */
    boolean checkGrade(String gradeName);

    /**
     * 根据年级名添加年级
     *
     * @param gradeName
     */
    void addGrade(String gradeName);
}
