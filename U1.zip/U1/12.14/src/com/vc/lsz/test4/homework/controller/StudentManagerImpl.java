package com.vc.lsz.test4.homework.controller;

import com.vc.lsz.test4.homework.model.Grade;
import com.vc.lsz.test4.homework.model.Student;

/**
 * author: VC
 * create: 2021/12/14 15:57
 * version: 1.0.0
 */
public class StudentManagerImpl implements StudentDao,GradeDao{

    private Student[] students = new Student[10];
    private Grade[] grades = new Grade[10];

    /**
     * 添加学生
     * @param name 学生姓名
     * @param sex   学生性别
     * @param gradeName 年级编号
     */
    public void addStudent(String name, String sex, String gradeName) {
        //先检测是否有对应的年级
        boolean exists = checkGrade(gradeName);
        if (!exists) {
            //如果年级不存在,则创建年级
            createGrade(gradeName);
        }
        //创建学生
        Student stu = new Student(name, sex, 1);
        //放入数组
        for (int i = 0; i < students.length; i++) {
            if (students[i]==null){
                students[i]=stu;
                break;
            }
        }
    }

    /**
     * 根据id删除学生
     * @param id 学生id
     */
    @Override
    public boolean deleteStudent(int id) {
        Student[] newStudents = new Student[students.length];
        int index =-1;
        for (int i = 0; i < students.length; i++) {
            if (students[i]==null){
                continue;
            }
            if (id== students[i].getId()){
                index=i;
                break;
            }
        }
        if (index==-1){
            return false;
        }
        for (int i = 0; i < index; i++) {
            newStudents[i]=students[i];
        }
        for (int i = index+1; i < newStudents.length; i++) {
            newStudents[i]=students[i];
        }
        students=newStudents;
        return true;
    }

    /**
     * 根据学生编号修改学生的其他信息
     *
     * @param id
     * @param name
     * @param sex
     * @param gradeName
     */
    @Override
    public void modifyStudent(int id, String name, String sex, String gradeName) {
        int gradeId=0;
        for (int i = 0; i < grades.length; i++) {
            if (grades[i]==null){
                continue;
            }
            if (gradeName.equals(grades[i].getName())){
                gradeId=grades[i].getId();
            }
        }
        if (gradeId==0){
            addGrade(gradeName);
            modifyStudent(id,name,sex,gradeName);
            return;
        }
        for (int i = 0; i < students.length; i++) {
            if (students[i]==null){
                continue;
            }
            if (id==students[i].getId()){
                students[i].setName(name);
                students[i].setSex(sex);
                students[i].setGradeId(gradeId);
                break;
            }
        }
    }

    /**
     * 查询所有年级
     * @return
     */
    @Override
    public Grade[] findAllGrade() {
        return grades;
    }

    /**
     * 查询所有学生
     * @return
     */
    @Override
    public Student[] findAllStudent() {
        return students;
    }

    /**
     * 创建年级
     * @param gradeName
     */
    private void createGrade(String gradeName) {
        Grade grade = new Grade(gradeName);
        //放入数组
        for (int i = 0; i < grades.length; i++) {
            if (!(grades[i]==null)) {
                continue;
            }
            grades[i]=grade;
            break;
        }
    }

    /**
     * 根据年级编号修改年级名
     *
     * @param id
     * @param name
     */
    @Override
    public void modifyGrade(int id, String name) {
        for (int i = 0; i < grades.length; i++) {
            if (grades[i]==null){
                continue;
            }
            if (id==grades[i].getId()){
                grades[i].setName(name);
                break;
            }
        }

    }

    /**
     * 删除年级
     * @param id
     */

    public int deleteGrade(int id) {
        for (int i = 0; i < students.length; i++) {
            if (students[i]==null){
                continue;
            }
            if (id==students[i].getGradeId()){
                return 0;
            }
        }
        int gradeIndex =-1;
        for (int i = 0; i < grades.length; i++) {
            if (grades[i]==null){
                continue;
            }
            if (id==grades[i].getId()){
                gradeIndex=i;
                break;
            }
        }
        if (gradeIndex==-1){
            return 1;
        }
        Grade[] newGrades = new Grade[grades.length];
        for (int i = 0; i < gradeIndex ; i++) {
            newGrades[i]=grades[i];
        }
        for (int i = gradeIndex+1; i < newGrades.length ; i++) {
            newGrades[i]=grades[i];
        }
        return 2;
    }

    /**
     * 检查年级名是否存在
     *
     * @param gradeName
     * @return
     */
    public boolean checkGrade(String gradeName) {
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] == null) {
                continue;
            }
            if (gradeName.equals(grades[i].getName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 添加年级
     * @param gradeName
     */
    @Override
    public void addGrade(String gradeName) {
        for (int i = 0; i < grades.length; i++) {
            if (grades[i]==null){
                Grade grade = new Grade(gradeName);
                grades[i]=grade;
                return;
            }
            if (gradeName.equals(grades[i].getName())){
                return;
            }
        }
        Grade grade = new Grade(gradeName);
        for (int i = 0; i < grades.length; i++) {
                grades[i]=grade;
                break;
        }
    }

    public Student findStudentById(int anInt) {
        for (int i = 0; i < students.length; i++) {
            if (students[i]==null){
                continue;
            }
            if (anInt==students[i].getId()){
                return students[i];
            }
        }
        return null;
    }

    public Grade findGradeById(int geadeId) {
        for (int i = 0; i < grades.length; i++) {
            if (grades[i]==null){
                continue;
            }
            if (geadeId==grades[i].getId()){
                return grades[i];
            }
        }
        return null;
    }
}
