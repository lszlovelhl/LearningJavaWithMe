package com.vc.lsz.homework.controller;

import com.vc.lsz.homework.model.Grade;
import com.vc.lsz.homework.model.Project;
import com.vc.lsz.homework.model.Student;

/**
 * author: VC
 * create: 2021/12/14 15:57
 * version: 1.0.0
 */
public class StudentManagerImpl implements StudentDao, GradeDao, ProjectDao {

    private Student[] students = new Student[10];
    private Grade[] grades = new Grade[10];
    private Project[] projects = new Project[10];

    /**
     * 学生
     *
     * @param name
     * @param sex
     * @param gradeName
     */
    public void addStudent(String name, String sex, String gradeName) {
//        do {
            //先检测是否有对应的年级
            boolean exists = checkGrade(gradeName);
            if (!exists) {
                //如果年级不存在,则创建年级
                createGrade(gradeName);
            }
            //创建学生
            Student stu = new Student(name, sex, 1);
            //判断数组是否为空
            for (int i = 0; i < students.length; i++) {
                if (students[i] == null) {
                    students[i] = stu;
                    break;
                }
//                if (students[students.length - 1] != null) {
//                    Student[] newStu = new Student[students.length + 10];
//                    System.arraycopy(students, 0, newStu, 0, students.length);
//                    newStu[students.length + 1] = stu;
//                    students = newStu;
//                }
            }
            //放入数组
//        students[0] = stu;
//        } while (true);
    }

    @Override
    public boolean deleteStudent(int id) {
        Student[] newStu = new Student[students.length];
        int index = -1;
        for (int i = 0; i < students.length; i++) {
            if (students[i] == null) {
                System.out.println("暂无学生信息");
                continue;
            }
            if (id == students[i].getId()) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            return false;
        }
        for (int i = 0; i < index; i++) {
            newStu[i] = students[i];
        }
        for (int i = index + 1; i < newStu.length; i++) {
            newStu[i] = students[i];
        }
        students = newStu;
        return true;
    }

    @Override
    public void modifyStudent(int id, String name, String sex, String gradeName) {
        int gradeId = 0;
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] == null) {
                continue;
            }
            if (gradeName.equals(grades[i].getName())) {
                gradeId = grades[i].getId();
            }
        }
        if (gradeId == 0) {
            addGrade(gradeName);
            modifyStudent(id, name, sex, gradeName);
            return;
        }
        for (int i = 0; i < students.length; i++) {
            if (students[i] == null) {
                continue;
            }
            if (id == students[i].getId()) {
                students[i].setName(name);
                students[i].setSex(sex);
                students[i].setGradeId(gradeId);
                break;
            }
        }
    }

    @Override
    public Student[] findAllStudent() {
        return students;
    }

    /**
     * 年级
     *
     * @param gradeName
     */
    private void createGrade(String gradeName) {
        Grade grade = new Grade(gradeName);
        //放入数组
        grades[0] = grade;
    }

    @Override
    public Grade[] findAllGrade() {
        return grades;
    }

    @Override
    public void modifyGrade(int id, String name) {
        int gradeId = 0;
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] == null) {
                continue;
            }
            if (name.equals(grades[i].getName())) {
                gradeId = grades[i].getId();
            }
        }
        if (gradeId == 0) {
            addGrade(name);
            modifyGrade(id, name);
            return;
        }
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] == null) {
                continue;
            }
            if (id == grades[i].getId()) {
                grades[i].setName(name);
                break;
            }
        }
    }

    @Override
    public boolean deleteGrade(int id) {
        Grade[] newGre = new Grade[grades.length];
        int index = -1;
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] == null) {
                System.out.println("暂无年级信息");
                continue;
            }
            if (id == grades[i].getId()) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            return false;
        }
        for (int i = 0; i < index; i++) {
            newGre[i] = grades[i];
        }
        for (int i = index + 1; i < newGre.length; i++) {
            newGre[i] = grades[i];
        }
        grades = newGre;
        return true;
    }

    /**
     * 检查年级名是否存在
     *
     * @param gradeName
     * @return
     */
    public boolean checkGrade(String gradeName) {
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] == null) {
                continue;
            }
            if (gradeName.equals(grades[i].getName())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void addGrade(String gradeName) {
//        boolean exists = checkGrade(gradeName);
//        if (!exists) {
//            如果年级不存在,则创建年级
//            createGrade(gradeName);
//        }
        Grade gre = new Grade(gradeName);
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] == null) {
                grades[i] = gre;
                break;
            }
//            if (grades[grades.length - 1] != null) {
//                Grade[] newGre = new Grade[grades.length + 10];
//                System.arraycopy(grades, 0, newGre, 0, grades.length);
//                newGre[grades.length + 1] = gre;
//                grades = newGre;
//            }
        }
    }

    /**
     * 科目
     *
     * @return
     */
    @Override
    public Project[] findAllProject() {

        return new Project[0];
    }

    @Override
    public void addProject(String name, String gradeName, int learnTime) {
        Project pro = new Project(name, learnTime);
        for (int i = 0; i < projects.length; i++) {
            if (projects[i] == null) {
                projects[i] = pro;
            }
            if (projects[projects.length - 1] != null) {
                Project[] newPro = new Project[projects.length + 10];
                System.arraycopy(projects, 0, newPro, 0, projects.length);
                newPro[projects.length + 1] = pro;
                projects = newPro;
            }
        }
    }

    @Override
    public boolean deleteProject(int id) {
        Project[] newPro = new Project[projects.length];
        int index = -1;
        for (int i = 0; i < projects.length; i++) {
            if (projects[i] == null) {
                System.out.println("暂无科目信息");
                continue;
            }
            if (id == projects[i].getId()) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            return false;
        }
        for (int i = 0; i < index; i++) {
            newPro[i] = projects[i];
        }
        for (int i = index + 1; i < newPro.length; i++) {
            newPro[i] = projects[i];
        }
        projects = newPro;
        return true;
    }

    @Override
    public void modifyProject(int id, String name, String gradeName, int learnTime) {
        int ProjectId = 0;
        for (int i = 0; i < projects.length; i++) {
            if (projects[i] == null) {
                continue;
            }
            if (gradeName.equals(projects[i].getName())) {
                ProjectId = projects[i].getId();
            }
        }
        if (ProjectId == 0) {
            addGrade(gradeName);
            modifyProject(id, name, gradeName, learnTime);
            return;
        }
        for (int i = 0; i < projects.length; i++) {
            if (projects[i] == null) {
                continue;
            }
            if (id == projects[i].getId()) {
                projects[i].setName(name);
                projects[i].setName(gradeName);
                projects[i].setLearnTime(learnTime);
                break;
            }
        }
    }

    public Student findStudentById(int studentId) {
        for (int i = 0; i < students.length; i++) {
            if (students[i] == null) {
                continue;
            }
            if (studentId == students[i].getId()) {
                return students[i];
            }
        }
        return null;
    }


    public Grade findGradeById(int gradeId) {
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] == null) {
                continue;
            }
            if (gradeId == grades[i].getId()) {
                return grades[i];
            }
        }
        return null;
    }
}
