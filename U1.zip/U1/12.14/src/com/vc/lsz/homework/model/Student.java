package com.vc.lsz.homework.model;

/**
 * author: VC
 * create: 2021/12/14 15:51
 * version: 1.0.0
 */
public class Student {
    private static int globalId = 1000;
    private int id;
    private String name;
    private String sex;
    private int gradeId;

    public Student() {
    }

    public Student(String name, String sex,int gradeId) {
        this.id = globalId++;
        this.name = name;
        this.sex = sex;
        this.gradeId = gradeId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getGradeId() {
        return gradeId;
    }

    public void setGradeId(int gradeId) {
        this.gradeId = gradeId;
    }
}
