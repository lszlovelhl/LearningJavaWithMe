package com.vc.lsz.homework.controller;

import com.vc.lsz.homework.model.Student;

public interface StudentDao {
    /**
     * 添加学生
     *
     * @param name
     * @param sex
     * @param gradeName
     */
    void addStudent(String name, String sex, String gradeName);

    /**
     * 根据学生编号删除学生
     *
     * @param id
     */
    boolean deleteStudent(int id);

    /**
     * 根据学生编号修改学生的其他信息
     *
     * @param id
     * @param name
     * @param sex
     * @param gradeName
     */
    void modifyStudent(int id, String name, String sex, String gradeName);

    /**
     * 获取所有学生
     * @return
     */
    Student[] findAllStudent();

}
