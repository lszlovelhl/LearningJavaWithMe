package com.vc.lsz.homework;

import java.util.Scanner;

/**
 * Scanner工具类
 * author: VC
 * create: 2021/12/14 15:33
 * version: 1.0.0
 */
public final class ScannerUtil {

    public static String getString() {
        Scanner sc = new Scanner(System.in);
        return sc.nextLine();
    }

    public static int getInt(){
        Scanner sc = new Scanner(System.in);
        return sc.nextInt();
    }

    public static int getInt(int min) {
        Scanner sc = new Scanner(System.in);
        if (!sc.hasNextInt()) {
            System.out.printf("输入错误,请重新输入大于等于%d的数字\n", min);
            return getInt(min);
        }
        int num = sc.nextInt();
        //判断范围
        if (num < min) {
            System.out.printf("输入错误,请重新输入大于等于%d的数字\n", min);
            return getInt(min);
        }
        return num;
    }

    /**
     * 接收用户输入指定范围内的数字
     *
     * @param min 最小值
     * @param max 最大值
     * @return 输入的正确值
     */
    public static int getInt(int min, int max) {
        Scanner sc = new Scanner(System.in);
        if (!sc.hasNextInt()) {
            System.out.printf("输入错误,请重新输入%d~%d的数字\n", min, max);
            return getInt(min, max);
        }
        int num = sc.nextInt();
        //判断范围
        if (num < min || num > max) {
            System.out.printf("输入错误,请重新输入%d~%d的数字\n", min, max);
            return getInt(min, max);
        }
        return num;
    }
}
