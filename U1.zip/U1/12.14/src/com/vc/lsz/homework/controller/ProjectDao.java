package com.vc.lsz.homework.controller;

import com.vc.lsz.homework.model.Grade;
import com.vc.lsz.homework.model.Project;

/**
 * @auther XXX@abc.com
 * @date 2021/12/14 5:15 下午
 */
public interface ProjectDao {
    /**
     * 获取所有科目
     */
    Project[] findAllProject();

    /**
     * 添加科目
     */
    void addProject(String name,String gradeName,int learnTime);

    /**
     * 根据编号删除科目
     */
    boolean deleteProject(int id);

    /**
     * 根据编号修改科目
     */
    void modifyProject(int id,String name,String gradeName,int learnTime);
}
