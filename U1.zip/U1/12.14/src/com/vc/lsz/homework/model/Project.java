package com.vc.lsz.homework.model;

/**
 * @auther XXX@abc.com
 * @date 2021/12/14 5:17 下午
 */
public class Project {
    private static int globalId = 1;
    private int id;
    private String name;
    private int learnTime;

    public Project(){
    }

    public Project(String name, int learnTime){
        this.id = globalId++;
        this.name = name;
        this.learnTime = learnTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLearnTime() {
        return learnTime;
    }

    public void setLearnTime(int learnTime) {
        this.learnTime = learnTime;
    }

}
