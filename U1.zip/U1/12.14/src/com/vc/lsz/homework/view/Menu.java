package com.vc.lsz.homework.view;

import com.vc.lsz.homework.ScannerUtil;
import com.vc.lsz.homework.controller.StudentManagerImpl;
import com.vc.lsz.homework.model.Student;
import com.vc.lsz.homework.view.Menu;
import com.vc.lsz.homework.model.Grade;

import java.util.Arrays;
import java.util.Scanner;

/**
 * author: VC
 * create: 2021/12/14 15:56
 * version: 1.0.0
 */
public class Menu {
    StudentManagerImpl studentManager = new StudentManagerImpl();
//    Scanner sc = new Scanner(System.in);
//    int choice = sc.nextInt();

    public void showMainMenu() {
//        do {
        System.out.println("1.学生管理");
        System.out.println("2.年级管理");
        System.out.println("3.科目管理");
        System.out.println("0.退出");
        System.out.println("请选择：");
//            int choice = sc.nextInt();
        switch (ScannerUtil.getInt(0, 4)) {
            case 1:
                studentCtl();
                break;
            case 2:
                gradeCtl();
                break;
            case 3:
                productCtl();
                break;
            case 0:
                System.out.println("谢谢使用，再见");
                System.exit(0);
                break;
        }
    }

    //1.学生管理
    private void studentCtl() {
        System.out.println("1.查看所有学生");
        System.out.println("2.增加学生");
        System.out.println("3.修改学生");
        System.out.println("4.删除学生");
        System.out.println("0.退出");
        System.out.println("请选择：");
        int choice = ScannerUtil.getInt(0, 4);
        switch (choice) {
            case 1:
                System.out.println("学号\t\t姓名\t\t性别\t\t年级名字");
                Student[] showStudent = studentManager.findAllStudent();
                for (int i = 0; i < showStudent.length; i++) {
                    if (!(showStudent[i] == null)) {
                        System.out.println(showStudent[i].getId() + "\t"
                                + showStudent[i].getName() + "\t\t"
                                + showStudent[i].getSex() + "\t\t"
                                + showStudent[i].getGradeId());
                    }
//                    else {
//                        System.out.println("暂无信息");
//                    }
                }
                System.out.println();
                break;
                
            case 2:
                System.out.println("输入学生姓名");
                String name = ScannerUtil.getString();
                System.out.println("输入学生性别");
                String sex = ScannerUtil.getString();
                System.out.println("输入年级名字");
                String gradeName = ScannerUtil.getString();
                studentManager.addStudent(name, sex, gradeName);
                System.out.println("添加学生成功\n");
                studentCtl();
                break;
                
            case 3:
                System.out.println("输入修改的学生学号");
                int inStu = ScannerUtil.getInt(1000);
                Student student = studentManager.findStudentById(inStu);
                if (student == null) {
                    System.out.println("学生不存在");
                    break;
                }
                System.out.println("++++++++++++++待修改的学生信息++++++++++++++");
                System.out.println("学号\t\t姓名\t\t性别\t\t年级名字");
                System.out.println(student.getId() + "\t"
                        + student.getName() + "\t\t"
                        + student.getSex() + "\t\t"
                        + student.getGradeId());
                System.out.println("输入修改后的姓名");
                String newName = ScannerUtil.getString();
                System.out.println("输入修改后的性别");
                String newSex = ScannerUtil.getString();
                System.out.println("输入修改后的年级");
                String newGrade = ScannerUtil.getString();
                studentManager.modifyStudent(student.getId(), newName, newSex, newGrade);
                System.out.println("修改成功\n");
                break;
            case 4:
                System.out.println("输入删除的学生学号");
                int deleteById = ScannerUtil.getInt(1000);
                boolean flag = studentManager.deleteStudent(deleteById);
                if (flag) {
                    System.out.println("删除成功\n");
                } else {
                    System.out.println("输入的学号不存在\n");
                }
                break;
            case 0:
                showMainMenu();
                break;
        }
        studentCtl();
        return;
    }

    //2.年级管理
    private void gradeCtl() {
        System.out.println("1.查看所有年级");
        System.out.println("2.增加年级");
        System.out.println("3.修改年级");
        System.out.println("4.删除年级");
        System.out.println("0.退出");
        System.out.println("请选择：");
        int studentMenuId = ScannerUtil.getInt(0, 4);
        switch (studentMenuId) {
            case 1:
                Grade[] allGrade = studentManager.findAllGrade();
                System.out.println("编号\t\t年级名\n");
                if (allGrade == null) {
                    break;
                }
                for (int i = 0; i < allGrade.length; i++) {
                    if (allGrade[i] == null) {
                        continue;
                    }
                    System.out.println(allGrade[i].getId() + "\t\t" + allGrade[i].getName());
                }
                break;
            case 2:
                System.out.println("请输入年级名字");
                String gradeName = ScannerUtil.getString();
                studentManager.addGrade(gradeName);
                break;
            case 3:
                System.out.println("请输入要修改的年级编号");
                int geadeId = ScannerUtil.getInt(0);
                System.out.println("+++++++++++++待修改的年级编号++++++++++++");
                System.out.println("编号\t\t年级名");
                Grade grade = studentManager.findGradeById(geadeId);
                if (grade == null) {
                    System.out.println("输入的年级不存在");
                    break;
                }
                System.out.println(grade.getId() + "\t\t" + grade.getName());
                System.out.println("输入修改后的年级名称");
                String gradeName1 = ScannerUtil.getString();
                studentManager.modifyGrade(geadeId, gradeName1);
                System.out.println("修改成功");
                break;
            case 4:
                System.out.println("输入要删除的年级编号");
                int gradeId = ScannerUtil.getInt(0);
                boolean i = studentManager.deleteGrade(gradeId);
                if (i) {
                    System.out.println("删除成功");
                } else{
                    System.out.println("输入的年级不存在或已绑定学生");
                }
                break;
            case 0:
                showMainMenu();
                return;
        }
        gradeCtl();
        return;
    }

    //3.科目管理
    private void productCtl() {
        System.out.println("1.查看所有科目");
        System.out.println("2.增加科目");
        System.out.println("3.删除科目");
        System.out.println("4.修改科目");
        System.out.println("0.退出");
        System.out.println("请选择：");

    }
}
