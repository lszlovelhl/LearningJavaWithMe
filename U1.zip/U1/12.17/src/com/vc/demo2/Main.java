package com.vc.demo2;

/**
 * author: VC
 * create: 2021/12/17 11:01
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {

        MyLinkedList list = new MyLinkedList();
        list.add("1");
        list.add("2");
        list.add("3");
        list.add("4");
        list.add("5");

//        System.out.println(list(1));//2 from head
//        System.out.println(list.getNode(3));//4 from tail

        list.remove(1);
        list.remove(3);

        System.out.println(list.del(1));
        System.out.println(list.del(3));


    }
}
