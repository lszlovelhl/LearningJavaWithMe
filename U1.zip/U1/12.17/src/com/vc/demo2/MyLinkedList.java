package com.vc.demo2;

import org.w3c.dom.Node;

/**
 * 自定义链表
 * author: VC
 * create: 2021/12/17 11:07
 * version: 1.0.0
 */
public class MyLinkedList {
    //头节点
    private Node head;
    //尾节点
    private Node tail;
    //节点数量
    private int count;
    //节点下标

    public int size() {
        return count;
    }

    public void add(Object obj) {
        if (tail == null) {
            //创建头节点
            head = tail = new Node(null, null, obj);
        } else {
            //新建节点
            Node node = new Node(tail, null, obj);
            //将尾节点的后序节点指向新节点
            tail.next = node;
            //将尾节点指向新节点
            tail = node;
        }
        count++;
    }

    public void remove(int index) {
        Node node = getNode(index);
        if (node == null){
            return;
        }

        //获取待删的节点的后续
        Node next = node.next;

        //获取待删的节点的前续
        Node pre = node.pre;

        /**
         * 头
         */
        if (pre == null){
            next.pre = null;
            head = next;
//            head = getNode(index + 1);
            next = null;
        }

        /**
         * 尾
         */
        if (pre != null && next == null){
            pre.next = null;
            tail = pre;
//            tail = getNode(index - 1);
            next = null;
        }

        /**
         * 其他
         */
        //后续的前序设为待删的前序
        next.pre = pre;
        //前序的后续设为待删的后续
        pre.next = next;

        //置空
        node.next = null;
        node.pre = null;


//        if (index < 0 || index > count - 1){
//            return;
//        }

//        for (int i = 0; i < count; i++) {
//            index = i;
//            boolean flag = false;
//            if (head == null) {
//                return;
//            }else {
//                if (head.index == index){
//                    flag = true;
//                }
//                head = head.next;
//            }
//            if (flag){
//                head.next = head.next.next;
//            }else {
//                return;
//            }
            count--;
        }

//      Node temp = head;
//        boolean flag = false;
//        while (true){
//            if (temp.next == null){
//                break;
//            }
//            if (temp.next.pre == head.pre){
//
//            }
//        }
//    }

    public Node del(int index) {
//        /**
//         * 判定下标越界
//         */
//        if (index < 0 || index >= count) {
//            return null;
//        }
//        Node temp;
//        if (index < (count >> 1)) {
//            int i = 0;
//            //从头开始遍历
//            temp = head;
//            while (i < index) {
//                temp = temp.next;
//                i++;
//            }
//            System.out.println("from head");
//        } else {
//            //从尾开始
//            temp = tail;
//            //98
//            int i = count - index;
//            while (i > index + 1) {
//                temp = temp.pre;
//                i--;
//            }
//            System.out.println("from tail");
//        }
//
//        if (head.next == null) {
//            return null;
//        }
//        Node tmp = head;
//        boolean flag = false;
//        while (true) {
//            if (tmp.next == null) {
//                break;
//            }
//            if (tmp.next. == index) {
//                flag = true;
//                break;
//            }
//            tmp = tmp.next;
//        }
//        if (flag) {
//            tmp.next = tmp.next.next;
//        } else {
//            return null;
//        }
        return null;
    }

    private Node getNode(int index) {
        //count = 100
        //index = 9
        //index = 98
        //判断下标是否越界
        if (index < 0 || index >= count) {
            return null;
        }
        Node temp = null;
        if (index < (count >> 1)) {
            int i = 0;
            //从头开始遍历
            temp = head;
            while (i < index) {
                temp = temp.next;
                i++;
            }
            System.out.println("from head");
        } else {
            //从尾开始
            temp = tail;
            //98
            int i = count - index;
            while (i > index + 1) {
                temp = temp.pre;
                i--;
            }
            System.out.println("from tail");
        }
        return temp;
    }

    //链表节点
    class Node {
        //头指针
        private Node pre;
        //尾指针
        private Node next;
        //保存数据
        private Object data;

        public Node(Node pre, Node next, Object data) {
            this.pre = pre;
            this.next = next;
            this.data = data;
        }
    }
}
