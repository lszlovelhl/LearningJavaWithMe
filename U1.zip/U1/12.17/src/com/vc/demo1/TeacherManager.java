package com.vc.demo1;

import com.vc.homework.model.Student;
import com.vc.homework.model.Teacher;

import java.util.List;

/**
 * author: VC
 * create: 2021/12/17 10:57
 * version: 1.0.0
 */
public class TeacherManager extends BaseManager<Teacher> {

}
