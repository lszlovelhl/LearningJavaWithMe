package com.vc.demo1;

import com.vc.homework.model.Teacher;

import java.util.List;

/**
 * 泛型管理器
 * author: VC
 * create: 2021/12/17 10:59
 * version: 1.0.0
 */
public class BaseManager<T> {
    private List<T> list;

    public void add(T stu) {

    }

    public List<T> getAll() {
        return list;
    }
}
