package com.vc.homework.controller;

import com.vc.homework.model.Student;
import com.vc.homework.model.Teacher;
import com.vc.homework.model.enums.ChangeResultEnum;
import com.vc.homework.util.DateUtils;

import java.util.*;

public class SchoolManager {
    private static SchoolManager instance;

    private SchoolManager() {
        //初始化老师数据
        teachers.put("jack", new Teacher("jack", "123"));
        students.add(new Student("stu1", "111", 1, 1, new Date()));
        students.add(new Student("stu2", "111", 3, 3, new Date()));
        students.add(new Student("stu3", "111", 2, 2, new Date()));


    }


    public static SchoolManager getInstance() {
        if (instance == null) {
            instance = new SchoolManager();
        }
        return instance;
    }

    private List<Student> students = new ArrayList<>();
    /**
     * 老师集合
     * key:String 用户名
     * value:Teacher 老师对象
     */
    private Map<String, Teacher> teachers = new HashMap<>();

    //当前登录的学生
    private Student loginStudent;

    public boolean doStudentLogin(String name, String pwd) {
        for (Student student : students) {
            if (student.getName().equals(name)
                    && student.getPwd().equals(pwd)) {
                //记录当前登录学生
                loginStudent = student;
                //找到了
                return true;
            }
        }
        return false;
    }

    public ChangeResultEnum doChangeStuPwd(int id, String old, String new1, String new2) {
        //判断确认密码是否一致
        if (!new1.equals(new2)) {
            //两次密码不一致
            //System.out.println("两次密码不一致");
            return ChangeResultEnum.FAIL_PWD_NOT_SAME;
        }
        for (Student student : students) {
            //找对应的登录学生
            if (student.getId() == id) {
                //找到了 判断旧密码是否匹配
                if (!student.getPwd().equals(old)) {
                    //System.out.println("原始密码输入错误");
                    return ChangeResultEnum.FAIL_PWD_INVALID;
                }
                //原始密码正确,修改
                student.setPwd(new1);
            }
        }
        return ChangeResultEnum.SUCCESS;
    }

    public ChangeResultEnum doChangeStuPwd(String old, String new1, String new2) {
        return this.doChangeStuPwd(loginStudent.getId(), old, new1, new2);
    }

    public boolean doTeacherLogin(String name, String pwd) {
        Teacher teacher = teachers.get(name);
        //验证用户名是否存在
        if (teacher == null) {
            //用户名不存在
            return false;
        }
//        //用户存在,验证密码是否匹配
//        if (teacher.getPwd().equals(pwd)) {
//            return true;
//        }
//        //密码错误
//        return false;
        return teacher.getPwd().equals(pwd);
    }

    public List<Student> getStudents() {
        System.out.println("获取所有学生...");
        return students;
    }

    private static final Comparator<Student> CHINESE_ASC = new Comparator<Student>() {
        @Override
        public int compare(Student o1, Student o2) {
            return o1.getChineseScore() - o2.getChineseScore();
        }
    };

    private static final Comparator<Student> CHINESE_DESC = new Comparator<Student>() {
        @Override
        public int compare(Student o1, Student o2) {
            return o2.getChineseScore() - o1.getChineseScore();
        }
    };

    public List<Student> getOrderedList(int subject, int order) {
        List<Student> stuList = new ArrayList<>(students);
        //TODO 使用比较器排序
        if (subject == 1) {//语文
            if (order == 1) {//升序
                Collections.sort(stuList, CHINESE_ASC);
            } else if (order == 2) {
                Collections.sort(stuList, CHINESE_DESC);
            }
        } else if (subject == 2) {
            if (order == 1) {//升序
                Collections.sort(stuList, new Comparator<Student>() {
                    @Override
                    public int compare(Student o1, Student o2) {
                        return o1.getMathScore() - o2.getMathScore();
                    }
                });
            } else if (order == 2) {
                Collections.sort(stuList, new Comparator<Student>() {
                    @Override
                    public int compare(Student o1, Student o2) {
                        return o2.getMathScore() - o1.getMathScore();
                    }
                });
            }
        }
        return stuList;
    }

    public boolean doAddStudent(String name, String pwd,
                                int chineseScore, int mathScore,
                                String bornDate) {
        //解析日期
        Date date = DateUtils.parse(bornDate);
        if (date == null) {
            return false;
        }
        Student student = new Student(name, pwd,
                chineseScore, mathScore, date);
        //加入集合
        students.add(student);
        return true;
    }

    public Student getStudentById(int id) {
        for (Student student : students) {
            if (student.getId() == id) {
                return student;
            }
        }
        return null;
    }

    public boolean doDeleteStudent(int id) {
        //遍历集合,判断ID是否匹配
        for (Student student : students) {
            if (student.getId() == id) {
                //移除
                students.remove(student);
                return true;
            }
        }
        //编号不存在
        return false;
    }


}