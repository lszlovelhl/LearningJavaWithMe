package com.vc.homework.model.enums;

/**
 * author: VC
 * create: 2021/12/17 9:43
 * version: 1.0.0
 */
public enum ChangeResultEnum {
    //枚举对象的实例列表 public static final
    /**
     * 修改成功
     */
    SUCCESS("修改成功"), //ordinal = 0
    /**
     * 两次密码不一致
     */
    FAIL_PWD_NOT_SAME("两次密码不一致"),//ordinal = 1
    /**
     * 原始密码错误
     */
    FAIL_PWD_INVALID("原始密码错误");//ordinal = 2

    //只读属性
    private String tips;

    public String getTips() {
        return tips;
    }

    ChangeResultEnum(String tips) {
        this.tips = tips;
    }
}
