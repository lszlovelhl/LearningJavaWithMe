package com.vc.homework.model;

/**
 * author: VC
 * create: 2021/9/10 16:58
 * version: 1.0.0
 */
public class Teacher extends Person {
    private static int globalID = 1;

    public Teacher(String name, String pwd) {
        super(globalID++, name, pwd);
    }
}
