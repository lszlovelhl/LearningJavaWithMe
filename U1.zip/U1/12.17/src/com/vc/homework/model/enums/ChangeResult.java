package com.vc.homework.model.enums;

/**
 * author: VC
 * create: 2021/12/17 9:39
 * version: 1.0.0
 */
public interface ChangeResult {
    public static final int SUCCESS = 1,
            FAIL_PWD_NOT_SAME = -1,
            FAIL_PWD_INVALID = -2;

}
