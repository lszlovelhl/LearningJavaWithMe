package com.vc2.demo2;

/**
 * 自定义链表
 * author: VC
 * create: 2021/12/17 11:07
 * version: 1.0.0
 */
public class MyLinkedList {
    //头节点
    private Node head;
    //尾节点
    private Node tail;
    //节点数量
    private int count;

    public int size() {
        return count;
    }

    public void add(Object obj) {
        if (tail == null) {
            //创建头节点
            head = tail = new Node(null, null, obj);
        } else {
            //新建节点
            Node node = new Node(tail, null, obj);
            //将尾节点的后序节点指向新节点
            tail.next = node;
            //将尾节点指向新节点
            tail = node;
        }
        count++;
    }

    public void remove(int index) {

    }

    public Object get(int index) {
        //count = 100
        //index = 9
        //index = 98
        //判断下标是否越界
        if (index < 0 || index >= count) {
            return null;
        }
        Node temp = null;
        if (index < (count >> 1)) {
            int i = 0;
            //从头开始遍历
            temp = head;
            while (i < index) {
                temp = temp.next;
                i++;
            }
            System.out.println("from head");
        } else {
            //从尾开始
            temp = tail;
            //98
            int i = count - index;
            while (i < index) {
                temp = temp.pre;
                i++;
            }
            System.out.println("from tail");
        }
        return temp.data;
    }

    //链表节点
    class Node {
        private Node pre;
        private Node next;
        private Object data;

        public Node(Node pre, Node next, Object data) {
            this.pre = pre;
            this.next = next;
            this.data = data;
        }
    }
}
