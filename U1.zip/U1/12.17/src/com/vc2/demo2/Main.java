package com.vc2.demo2;

import com.vc.demo2.MyLinkedList;

/**
 * author: VC
 * create: 2021/12/17 11:01
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {

        com.vc.demo2.MyLinkedList list = new MyLinkedList();
        list.add("1");
        list.add("2");
        list.add("3");
        list.add("4");
        list.add("5");

        System.out.println(list.get(1));//2 from head
        System.out.println(list.get(3));//4 from tail

    }
}
