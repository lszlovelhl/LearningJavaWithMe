package com.vc2.homework.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * author: VC
 * create: 2021/12/17 10:02
 * version: 1.0.0
 */
public class DateUtils {
    private static SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * 将字符串解析为日期对象,如果解析失败,返回null
     * @param str
     * @return
     */
    public static Date parse(String str) {
        try {
            return fmt.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 将日期格式化为字符串
     *
     * @param date
     * @return
     */
    public static String format(Date date) {
        return fmt.format(date);
    }
}
