package com.vc2.homework;


import com.vc.homework.view.Menu;

/**
 * author: VC
 * create: 2021/9/10 17:49
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {
        new Menu().showMainMenu();

    }
}
