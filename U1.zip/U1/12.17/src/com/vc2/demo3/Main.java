package com.vc2.demo3;

import java.util.HashMap;
import java.util.Hashtable;

/**
 * author: VC
 * create: 2021/12/17 15:35
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {
        HashMap map = new HashMap();

        map.put("jack", "1");

        int index = 15 & 21536720;
        //index = 21536720 % length;
        System.out.println(index);

        //18
        //1101 0010
        //0111 1111
        //1000 0000

        //length = 16
        //
        //0011 1111
        //0000 0100
        //------------


        Hashtable hashtable = new Hashtable();
        hashtable.put("", "");
        hashtable.get("");

    }
}
