package com.vc2.demo1;

import com.vc.demo1.BaseManager;
import com.vc.homework.model.Student;
import com.vc.homework.model.Teacher;

import java.util.List;

/**
 * author: VC
 * create: 2021/12/17 10:57
 * version: 1.0.0
 */
public class StudentManager extends BaseManager<Student> {
}
