package com.vc2.demo1;

/**
 * 泛型类
 * author: VC
 * create: 2021/12/17 10:45
 * version: 1.0.0
 */
public class MyList<ABC> {
    Object[] arr = new Object[10];

    //运行时-->用
    //编译时-->写代码
    public void add(ABC obj) {
        System.out.println(obj);
    }

    public ABC get(int index) {
        return (ABC) arr[index];
    }

    //泛型方法
    // public <E> E getElement(Class<E> clz){
    public <E> E getClone(E obj) {
        return obj;
    }

}
