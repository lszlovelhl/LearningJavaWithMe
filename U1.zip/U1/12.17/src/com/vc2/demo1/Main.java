package com.vc2.demo1;

import com.vc.demo1.MyList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * author: VC
 * create: 2021/12/17 10:42
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {
        com.vc.demo1.MyList<Integer> myList = new com.vc.demo1.MyList();
        myList.add(1);

        com.vc.demo1.MyList<String> myList1 = new MyList();
        myList1.add("1");

        //泛型方法
        String str = myList1.getClone("1");
        int num = myList1.getClone(1);
    }
}
