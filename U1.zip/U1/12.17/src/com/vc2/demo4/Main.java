package com.vc2.demo4;

import java.util.*;

/**
 * author: VC
 * create: 2021/12/17 16:09
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {
        // List ==> ArrayList,LinkedList
        LinkedList list = new LinkedList();
        //入栈
        list.push("");
        //出栈:如果没有元素,返回null
        list.poll();
        //出栈:如果没有元素,抛出异常
        //list.pop();

        //Map ==> HashMap, TreeMap

        //Set ==> HashSet, TreeSet
        Set set = new TreeSet();
        set.add(new Student(1, "jack"));
        set.add(new Student(2, "rose"));
        set.add(new Student(3, "mike"));

        for (Object o : set) {
            System.out.println(o);
        }
    }
}

class Student implements Comparable<Student> {
    private int id;
    private String name;


    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public int compareTo(Student o) {
        return name.compareTo(o.name);
    }
}