package com.vc2.ex;

/**
 * author: VC
 * create: 2021/12/17 16:41
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {
        MyHashMap map = new MyHashMap();
        map.put("jack", "123");
        map.put("rose", "234");
        System.out.println(map.get("jack"));
        System.out.println(map.get("rose"));
    }
}
