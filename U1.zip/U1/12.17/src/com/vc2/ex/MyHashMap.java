package com.vc2.ex;

import java.util.Arrays;

/**
 * author: VC
 * create: 2021/12/17 16:41
 * version: 1.0.0
 */
public class MyHashMap {
    //初始长度
    private static final int INIT_CAPACITY = 16;
    //加载因子
    private static final float LOAD_FACTOR = .75F;

    //存储数据的数组结构
    private Node[] nodes;
    //长度
    private int size;

    public MyHashMap() {
        //数组初始长度
        nodes = new Node[INIT_CAPACITY];
    }

    public void put(Object key, Object value) {
        //计算扩容阈值
        int threshold = (int) (size * LOAD_FACTOR);
        //判断长度
        if (size + 1 > threshold) {
            resize();
        }
        int index = getIndex(key);
        //找出桶
        Node root = nodes[index];
        //创建节点
        Node node = new Node(key, value, null);
        size++;
        if (root == null) {
            //如果格子是空的,直接放入
            nodes[index] = node;
            return;
        }
        //根节点不为null
        //查找是否有相同的key
        while (true) {
            if (root.key.equals(key)) {
                //有相同的key,覆盖value
                root.value = value;
                return;
            }
            //进行下一个节点的判断
            root = root.next;
            if (root == null) {
                break;
            }
        }
        //不存在相同的key,使用头插法加入元素
        node.next = nodes[index];
        nodes[index] = node;
    }

    public Object get(Object key) {
        //计算key的hash
        int index = getIndex(key);
        Node root = nodes[index];
        if (root == null) {
            return null;
        }
        //如果根元素存在
        while (true) {
            if (root.key.equals(key)) {
                return root.value;
            }
            //下一次
            root = root.next;
            if (root == null) {
                break;
            }
        }
        return null;
    }

    public Object remove(Object key) {

        return null;
    }

    private int getIndex(Object key) {
        //根据key生成hash值
        int hash = key.hashCode();
        //计算hash值对应数组的哪个下标
        //int index = hash % size;
        return (nodes.length - 1) & hash;
    }

    private void resize() {
        //扩容一倍
        int newLength = nodes.length << 1;
        nodes = Arrays.copyOf(nodes, newLength);
    }


    /**
     * 链表节点
     */
    class Node {
        //键
        Object key;
        //值
        Object value;
        //下一个节点
        Node next;

        public Node(Object key, Object value, Node next) {
            this.key = key;
            this.value = value;
            this.next = next;
        }
    }
}
