package com.vc.orm.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 映射类中属性与表中字段的关系
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface MyColumn {
    String value();

    /**
     * 是否是主键列
     * @return
     */
    boolean isPK() default false;

    /**
     * 是否是自增长列
     * @return
     */
    boolean isAutoIncrement() default false;
}
