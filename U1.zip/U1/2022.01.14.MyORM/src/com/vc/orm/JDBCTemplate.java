package com.vc.orm;


import com.vc.orm.context.AppContext;
import com.vc.orm.model.ColumnMapping;
import com.vc.orm.model.ResultSetCallback;
import com.vc.orm.model.TableMapping;
import com.vc.orm.model.UpdateResult;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * JDBC帮助类
 * author: VC
 * create: 2021/12/29 15:37
 * version: 1.0.0
 */
public class JDBCTemplate {
    private <T> ResultSetCallback createCallback(Class<T> clz, TableMapping mapping) {
        return rs -> {
            List<T> list = new ArrayList<>();
            try {
                //获取结果集元数据对象
                ResultSetMetaData meta = rs.getMetaData();
                while (rs.next()) {
                    //每遍历一个产生一个对象
                    T obj = clz.newInstance();
                    //填充对象的属性
                    for (int i = 1; i <= meta.getColumnCount(); i++) {
                        //获取结果集中的列名
                        String columnName = meta.getColumnName(i);
                        //在结果集中获取该列的值
                        Object value = rs.getObject(columnName);
                        //根据字段名获取类中的属性名
                        String fieldName = mapping.getAttr(columnName);
                        //如果表中字段在类中不存在,则跳过
                        if (fieldName == null) {
                            continue;
                        }
                        Field field = clz.getDeclaredField(fieldName);
                        field.setAccessible(true);
                        field.set(obj, value);
                    }
                    list.add(obj);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return list;
        };
    }

    protected UpdateResult add(Object obj) {
        //获取Class对象
        Class clz = obj.getClass();
        //获取映射对象
        TableMapping mapping = AppContext.getTableMapping(clz.getName());
        //拼接要添加的列(除了自增的主键)
        String sql = "insert into `%s`(%s) values(%s)";
        //表名
        String tableName = mapping.getTableName();
        //列名
        StringBuilder columns = new StringBuilder();
        //值列表(?)
        StringBuilder values = new StringBuilder();
        //实际值的集合
        List valueList = new ArrayList();
        //获取列名
        for (ColumnMapping column : mapping.getColumns().values()) {
            //排除自增长列
            if (column.isAutoIncrement()) {
                continue;
            }
            try {
                Field field = clz.getDeclaredField(column.getFieldName());
                //获取字段的修饰符
                int mod = field.getModifiers();
                //排除static|final|transient修饰符
                if (Modifier.isFinal(mod) || Modifier.isStatic(mod) || Modifier.isTransient(mod)) {
                    continue;
                }
                //拼接到列名中
                columns.append("`").append(column.getFieldName()).append("`,");
                //获取属性值
                valueList.add(getValue(obj, column.getAttrName()));
                //拼接问号:有多少个列就拼接多少个问号
                values.append("?,");
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            }
        }
        //去掉最后一个逗号
        columns.deleteCharAt(columns.length() - 1);
        values.deleteCharAt(values.length() - 1);

        //格式化填坑,将%s的内容填充进去
        sql = String.format(sql, tableName, columns, values);
        //执行sql
        return update(sql, valueList.toArray());
    }

    protected int modify(Object obj) {
        //获取Class对象
        Class clz = obj.getClass();
        TableMapping mapping = AppContext.getTableMapping(clz.getName());
        //获取主键
        ColumnMapping pk = mapping.getPK();
        String sql = "update `" + mapping.getTableName() + "` set ";
        StringBuilder sb = new StringBuilder();
        //保存属性值
        List list = new ArrayList<>();
        //遍历类中的所有字段
        for (ColumnMapping attr : mapping.getColumns().values()) {
            //排除主键
            if (attr.isPK()) {
                continue;
            }
            try {
                Field field = clz.getDeclaredField(attr.getFieldName());
                //获取字段的修饰符
                int mod = field.getModifiers();
                //排除static|final|transient修饰符
                if (Modifier.isFinal(mod) || Modifier.isStatic(mod) || Modifier.isTransient(mod)) {
                    continue;
                }
                sb.append("`").append(attr.getFieldName()).append("`=?,");
                //获取该属性的值
                Object value = getValue(obj, attr.getAttrName());
                list.add(value);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //列名=?,列名=?,
        //去掉最后一个逗号
        sb.deleteCharAt(sb.length() - 1);
        sql += sb.toString();
        sql += " where " + pk.getFieldName() + " = ?";
        //获取主键值
        Object pkValue = getValue(obj, pk.getAttrName());
        //添加到集合中
        list.add(pkValue);
        return update(sql, list.toArray()).count;
    }

    //obj ==> User
    protected int delete(Object obj) {
        //映射
        //类名 ==> 表名
        //属性 ==> 主键
        //根据对象获取Class
        Class clz = obj.getClass();
        TableMapping mapping = AppContext.getTableMapping(clz.getName());
        //获取主键的字段名
        ColumnMapping columnMapping = mapping.getPK();
        String sql = "delete from `" + mapping.getTableName()
                + "` where " + columnMapping.getFieldName() + " = ?";
        //获取对象的主键值
        String attrName = columnMapping.getAttrName();
        Object value = getValue(obj, attrName);
        //执行SQL
        return update(sql, value).count;
    }

    /**
     * 根据属性名获取属性值
     *
     * @param obj
     * @param attrName
     * @return
     */
    private Object getValue(Object obj, String attrName) {
        Class clz = obj.getClass();
        Object value = null;
        try {
            //使用反射获取属性值
            Field field = clz.getDeclaredField(attrName);
            //设置访问权限
            field.setAccessible(true);
            //获取字段中的值
            value = field.get(obj);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return value;
    }

    protected <T> T findById(Class<T> clz, Object... ids) {
        //根据全类名获取映射对象
        TableMapping mapping = AppContext.getTableMapping(clz.getName());
        //获取主键列
        StringBuilder pk = new StringBuilder();
        for (ColumnMapping columnMapping : mapping.getColumns().values()) {
            if (columnMapping.isPK()) {
                pk.append(columnMapping.getFieldName()).append("=? and ");
            }
        }
        int index = pk.lastIndexOf("?");
        //是否有主键
        if (index == -1) {
            return null;
        }
        pk.delete(index + 1, pk.length());

        String sql = "select * from `" + mapping.getTableName() + "` where " + pk;
        List<T> list = (List<T>) query(sql, createCallback(clz, mapping), ids);
        return list.size() == 0 ? null : list.get(0);
    }

    /**
     * 根据单个属性查找对象
     *
     * @param clz
     * @param attr  属性名
     * @param value 属性值
     * @param <T>
     * @return
     */
    protected <T> List<T> findByProperty(Class<T> clz, String attr, Object value) {
        Map<String, Object> map = new HashMap<>();
        map.put(attr, value);
        return this.findByProperties(clz, map);
    }

    /**
     * 根据多个属性查找对象
     *
     * @param clz
     * @param propertyMap 要查找对象的属性键值对,key 属性名,value 属性值
     * @param <T>
     * @return
     */
    protected <T> List<T> findByProperties(Class<T> clz, Map<String, Object> propertyMap) {
        //根据全类名获取映射对象
        TableMapping mapping = AppContext.getTableMapping(clz.getName());
        //查找的列名
        StringBuilder columns = new StringBuilder();
        //参数值
        List values = new ArrayList();
        for (Map.Entry<String, Object> entry : propertyMap.entrySet()) {
            //获取属性名
            String key = entry.getKey();
            //获取属性值
            Object value = entry.getValue();
            //获取属性名对应的字段名
            for (ColumnMapping columnMapping : mapping.getColumns().values()) {
                if (columnMapping.getAttrName().equalsIgnoreCase(key)) {
                    columns.append(columnMapping.getFieldName()).append("=? and ");
                    //按顺序拼接参数值
                    values.add(value);
                    break;
                }
            }
        }

        int index = columns.lastIndexOf("?");
        if (index >= 0) {
            //去掉最后的=? and
            columns.delete(index + 1, columns.length());
        }

        String sql = "select * from `" + mapping.getTableName() + "` where " + columns;
        return (List<T>) query(sql, createCallback(clz, mapping), values.toArray());
    }

    protected <T> List<T> findAll(Class<T> clz) {
        //根据全类名获取映射对象
        TableMapping mapping = AppContext.getTableMapping(clz.getName());
        String sql = "select * from `" + mapping.getTableName() + "`";
        return (List<T>) query(sql, createCallback(clz, mapping));
    }

    //回调函数
    protected Object query(String sql, ResultSetCallback callback, Object... args) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pst = conn.prepareStatement(sql);
            for (int i = 0; i < args.length; i++) {
                pst.setObject(i + 1, args[i]);
            }
            rs = pst.executeQuery();
            //逻辑
            return callback.processResultSet(rs);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(conn, pst, rs);
        }
        return null;
    }

    /**
     * 通用的增删改
     *
     * @param sql
     * @param args
     * @return
     */
    protected UpdateResult update(String sql, Object... args) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        UpdateResult result = new UpdateResult();
        try {
            conn = getConnection();
            pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            //填坑
            for (int i = 0; i < args.length; i++) {
                pst.setObject(i + 1, args[i]);
            }
            //执行
            result.count = pst.executeUpdate();
            //获取自增长编号
            rs = pst.getGeneratedKeys();
            if (rs.next()) {
                //获取编号值
                result.identity = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(conn, pst, rs);
        }
        return result;
    }

    /**
     * 获取连接对象
     *
     * @return
     * @throws SQLException
     */
    protected Connection getConnection() throws SQLException {
        //判断是否使用连接池
        if (AppContext.dataSource != null) {
            return AppContext.dataSource.getConnection();
        }
        //JDBC直连
        return DriverManager.getConnection(
                AppContext.url,
                AppContext.user,
                AppContext.pwd);
    }

    /**
     * 关闭连接
     *
     * @param conn
     * @param st
     * @param rs
     */
    protected void close(Connection conn, Statement st, ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        if (st != null) {
            try {
                st.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }

}
