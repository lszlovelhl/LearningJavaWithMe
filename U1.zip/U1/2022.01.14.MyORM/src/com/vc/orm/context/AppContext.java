package com.vc.orm.context;

import com.vc.orm.DataSourceCreator;
import com.vc.orm.annotation.MyColumn;
import com.vc.orm.annotation.MyTable;
import com.vc.orm.model.ColumnMapping;
import com.vc.orm.model.TableMapping;

import javax.sql.DataSource;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * author: VC
 * create: 2022/1/12 9:08
 * version: 1.0.0
 */
public class AppContext {
    private static final String CONFIG_NAME = "config.properties";

    private static final String KEY_DATA_SOURCE = "datasource",
            KEY_URL = "url", KEY_DRIVER = "driver",
            KEY_USER = "user", KEY_PWD = "pwd";

    public static String url, user, pwd, driver;

    /**
     * 嵌套内部类,忽略大小写的配置文件类
     */
    private static class MyProperties extends Properties {
        @Override
        public synchronized Object put(Object key, Object value) {
            if (key == null) {
                throw new NullPointerException();
            }
            return super.put(key.toString().toLowerCase(), value);
        }

        @Override
        public synchronized Object get(Object key) {
            if (key == null) {
                throw new NullPointerException();
            }
            return super.get(key.toString().toLowerCase());
        }
    }

    /**
     * 连接池数据源
     */
    public static DataSource dataSource;

    /**
     * key:全类名
     */
    private static Map<String, TableMapping> mappings = new HashMap();

    public static TableMapping getTableMapping(String className) {
        TableMapping mapping = mappings.get(className);
        if (mapping == null) {
            throw new RuntimeException("没有找到" + className + "的映射,请检查实体类是否配置@MyTable");
        }
        return mapping;
    }

    static {
        //加载配置文件
        loadConfig();
        //加载ORM映射
        loadMappingByAnnotation();
    }

    private static File root;

    private static void loadMappingByAnnotation() {
        try {
            //获取类的根路径
            URL url = AppContext.class.getClassLoader().getResource("");
            //创建File对象
            root = new File(url.toURI());
            search(root);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
    }

    private static void search(File file) {
        //筛选出文件和字节码文件
        File[] files = file.listFiles(f -> {
            //接受文件夹和字节码文件
            return f.isDirectory() || f.getName().toLowerCase().endsWith(".class");
        });
        for (File f : files) {
            //如果是文件夹
            if (f.isDirectory()) {
                search(f);
            } else {
                //是字节码文件
                String path = f.getAbsolutePath().substring(root.getAbsolutePath().length() + 1);
                //将\替换成.
                path = path.replace("\\", ".");
                //截取掉.class
                path = path.substring(0, path.lastIndexOf("."));
                //获取Class对象
                try {
                    Class clz = Class.forName(path);
                    //是否有MyTable注解
                    MyTable myTable = (MyTable) clz.getAnnotation(MyTable.class);
                    //如果没有,则跳过
                    if (myTable == null) {
                        continue;
                    }
                    String tableName;
                    //如果表名是空字符串,将类名作为表名
                    if (myTable.value().equals("")) {
                        tableName = clz.getSimpleName();
                    } else {
                        tableName = myTable.value();
                    }

                    TableMapping tableMapping = new TableMapping();
                    tableMapping.setTableName(tableName);
                    tableMapping.setClassName(clz.getName());
                    //获取类中的所有字段
                    Field[] fields = clz.getDeclaredFields();
                    //解析类中的MyColumn注解
                    for (Field field : fields) {
                        ColumnMapping columnMapping = new ColumnMapping();
                        columnMapping.setAttrName(field.getName());

                        MyColumn myColumn = field.getAnnotation(MyColumn.class);

                        try {
                            if (myColumn == null) {
                                //类中的属性名与表中的字段名一致
                                columnMapping.setFieldName(field.getName());
                                continue;
                            }
                            columnMapping.setFieldName(myColumn.value());
                            //设置是否是主键
                            if (myColumn.isPK()) {
                                columnMapping.setPK(true);
                            }
                            //设置是否是自增长
                            if (myColumn.isAutoIncrement()) {
                                columnMapping.setAutoIncrement(true);
                            }
                        } finally {
                            //将列的映射对象加入到集合
                            tableMapping.add(columnMapping);
                        }
                    }
                    mappings.put(tableMapping.getClassName(), tableMapping);
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    private static void loadConfig() {
        //加载类根路径下的配置文件
        URL url = AppContext.class.getClassLoader().getResource(CONFIG_NAME);
        //判断文件是否存在
        if (url == null) {
            System.err.println("在类的根路径下找不到配置文件:" + CONFIG_NAME);
            System.exit(0);
        }
        //加载配置文件
        Properties prop = new MyProperties();
        try {
            prop.load(new FileInputStream(url.getFile()));
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(0);
        }
        //读取配置
        String ds = prop.getProperty(KEY_DATA_SOURCE);
        try {
            if (ds == null) {
                //使用jdbc直连
                AppContext.url = prop.getProperty(KEY_URL);
                if (AppContext.url == null) {
                    throw new Exception("没有配置" + KEY_URL);
                }
                driver = prop.getProperty(KEY_DRIVER);
                if (driver == null) {
                    throw new Exception("没有配置" + KEY_DRIVER);
                }
                user = prop.getProperty(KEY_USER);
                if (user == null) {
                    throw new Exception("没有配置" + KEY_USER);
                }
                pwd = prop.getProperty(KEY_PWD);
                if (pwd == null) {
                    throw new Exception("没有配置" + KEY_PWD);
                }
                //加载直连驱动
                Class.forName(driver);
            } else {
                //使用连接池
                Class clz = Class.forName(ds);
                //创建DataSource对象
                DataSourceCreator creator = (DataSourceCreator) clz.newInstance();
                dataSource = creator.createDataSource();
            }
        } catch (ClassNotFoundException e) {
            System.err.println("没有找到类:" + e.getMessage());
            System.exit(0);
        } catch (ClassCastException e) {
            System.err.println(ds + " 不是 " + DataSourceCreator.class.getName() + " 的实现类");
            System.exit(0);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            System.exit(0);
        }
    }

}
