package com.vc.orm.model;

/**
 * 执行executeUpdate后的结果对象
 * author: VC
 * create: 2021/12/30 10:24
 * version: 1.0.0
 */
public class UpdateResult {
    /**
     * 受影响行数
     */
    public int count;
    /**
     * 自增长编号
     */
    public int identity;
}
