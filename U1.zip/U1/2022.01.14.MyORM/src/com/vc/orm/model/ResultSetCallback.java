package com.vc.orm.model;

import java.sql.ResultSet;

@FunctionalInterface
public interface ResultSetCallback {
    /**
     * 处理结果集
     *
     * @param rs
     * @return 返回封装的对象
     */
    Object processResultSet(ResultSet rs);
}
