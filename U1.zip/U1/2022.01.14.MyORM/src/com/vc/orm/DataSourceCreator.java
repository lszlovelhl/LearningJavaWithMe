package com.vc.orm;

import javax.sql.DataSource;

/**
 * 数据源(连接池)创建接口
 * author: VC
 * create: 2022/1/12 9:12
 * version: 1.0.0
 */
public interface DataSourceCreator {
    DataSource createDataSource() throws Exception;
}
