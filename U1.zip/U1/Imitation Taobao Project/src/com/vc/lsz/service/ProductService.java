package com.vc.lsz.service;

import com.vc.lsz.bean.PageInfo;
import com.vc.lsz.bean.Product;
import com.vc.lsz.dao.ProductDao;
import com.vc.lsz.utils.BeanFactoryUtils;

import java.util.List;


public class ProductService {
     //ģ������ע��
	private ProductDao productDao= BeanFactoryUtils.getBean(ProductDao.class);
	
	public List<Product> findProductsAll(){
		return productDao.findAll();
	}
	
	public PageInfo findProductsForPage(int pageNum, int pageSize){
		 PageInfo pageInfo=new PageInfo();
		 pageInfo.setList(productDao.queryForPage(pageNum, pageSize));
		 pageInfo.setPageNum(pageNum);
		 pageInfo.setPageSize(pageSize);
		 pageInfo.setTotalPages(productDao.totalPages(pageSize));
		return pageInfo;
	}
	
	public Product findByPid(String pid) {
		return productDao.findByPid(pid);
	}
}
