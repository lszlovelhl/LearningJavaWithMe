package com.vc.lsz.dao.impl;

import java.util.List;

import com.vc.lsz.bean.Order;
import com.vc.lsz.dao.OrderDao;

public class OrderDaoImplByJDBC implements OrderDao {

	@Override
	public void save(Order order) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Order> queryForUser(String uid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order queryForOid(String oid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order queryInfoForOid(String oid) {
		// TODO Auto-generated method stub
		return null;
	}

}
