package com.vc.lsz.demo3.util;

import java.util.Scanner;

/**
 * Scanner工具类
 * author: VC
 * create: 2021/7/26 9:33
 * version: 1.0.0
 */
public class ScannerUtils {
    private static Scanner input = new Scanner(System.in);

    /**
     * 接收用户输入的string内容
     *
     * @return 返回输入的string内容
     */
    public static String getString() {
//        String string = input.nextLine();
        String string = input.next();
        return string;
    }

    /**
     * 接收用户输入,并判断用户输入的是否是数字,是数字继续判断是否满足要求,满足则返回
     *
     * @param min 传入最小值
     * @return 返回满足要求的整数
     */
    public static int getInt(int min) {
        if (!input.hasNextInt()) {
            System.out.println("输入错误,请输入数字");
            input.next();
            return getInt(min);
        }
        int i = input.nextInt();
        if (i < min) {
            System.out.printf("输入错误,请输入大于%d的数字\n", min);
            return getInt(min);
        }
        return i;
    }

    /**
     * 接收用户输入,并判断用户输入的是否是数字,是数字继续判断是否满足要求,满足则返回
     * (验证输入的数是否在最大最小值之间)
     * @param min 输入最小值
     * @param max 输入最大值
     * @return 满足条件返回输入的整数
     */
    public static int getInt(int min, int max) {
        if (!input.hasNextInt()) {
            System.out.println("输入错误,请输入数字");
            input.next();
            return getInt(min,max);
        }
        int i = input.nextInt();
        if (i < min || i > max) {
            System.out.printf("输入错误,请输入%d和%d之间的数字\n", min,max);
            return getInt(min,max);
        }
        return i;
    }
}
