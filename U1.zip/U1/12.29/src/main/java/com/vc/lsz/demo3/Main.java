package com.vc.lsz.demo3;

import com.vc.lsz.demo3.context.AppContext;
import com.vc.lsz.demo3.view.Menu;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/29 3:59 下午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
        try {
            AppContext.init();
        }catch (Exception e){
            e.printStackTrace();
            return;
        }
        new Menu().show();
    }
}
