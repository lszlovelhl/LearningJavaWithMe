package com.vc.lsz.demo3.dao;

import com.vc.lsz.demo3.model.Grade;

import java.util.List;

/**
 * @ClassName GradeDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/29 4:00 下午
 * @Version 1.0
 */
public interface GradeDao {
    boolean add(Grade grade);
    boolean delete(int id);
    boolean update(Grade grade);
    boolean findById(int id);
    List<Grade> findAll();
}
