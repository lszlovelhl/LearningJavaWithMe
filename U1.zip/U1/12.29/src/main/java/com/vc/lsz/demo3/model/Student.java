package com.vc.lsz.demo3.model;

/**
 * @ClassName Student
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/29 4:02 下午
 * @Version 1.0
 */
public class Student {
    private int studentNo;
    private String studentName;
    private int loginPwd;
    private String sex;
    private int gradeId;

    @Override
    public String toString() {
        return "Student{" +
                "studentNo=" + studentNo +
                ", studentName='" + studentName + '\'' +
                ", loginPwd=" + loginPwd +
                ", sex='" + sex + '\'' +
                ", gradeId=" + gradeId +
                '}';
    }

    public Student(){}
    public Student(int studentNo, String studentName, int loginPwd, String sex, int gradeId) {
        this.studentNo = studentNo;
        this.studentName = studentName;
        this.loginPwd = loginPwd;
        this.sex = sex;
        this.gradeId = gradeId;
    }

    public int getStudentNo() {
        return studentNo;
    }

    public void setStudentNo(int studentNo) {
        this.studentNo = studentNo;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getLoginPwd() {
        return loginPwd;
    }

    public void setLoginPwd(int loginPwd) {
        this.loginPwd = loginPwd;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getGradeId() {
        return gradeId;
    }

    public void setGradeId(int gradeId) {
        this.gradeId = gradeId;
    }
}
