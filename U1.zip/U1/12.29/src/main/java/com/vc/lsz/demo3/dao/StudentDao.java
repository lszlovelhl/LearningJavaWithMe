package com.vc.lsz.demo3.dao;

import com.vc.lsz.demo3.model.Student;

import java.util.List;

/**
 * @ClassName StudentDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/29 4:00 下午
 * @Version 1.0
 */
public interface StudentDao {
    boolean add(Student student);
    boolean delete(int id);
    boolean update(Student student);
    boolean findById(int id);
    List<Student> findAll();
}
