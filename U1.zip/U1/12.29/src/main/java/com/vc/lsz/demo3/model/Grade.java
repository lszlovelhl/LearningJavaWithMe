package com.vc.lsz.demo3.model;

/**
 * @ClassName Grade
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/29 4:02 下午
 * @Version 1.0
 */
public class Grade {
    private int gradeId;
    private String gradeName;

    @Override
    public String toString() {
        return "Grade{" +
                "gradeId=" + gradeId +
                ", gradeName='" + gradeName + '\'' +
                '}';
    }

    public Grade(){}

    public Grade(int gradeId, String gradeName) {
        this.gradeId = gradeId;
        this.gradeName = gradeName;
    }

    public int getGradeId() {
        return gradeId;
    }

    public void setGradeId(int gradeId) {
        this.gradeId = gradeId;
    }

    public String getGradeName() {
        return gradeName;
    }

    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }
}
