package com.vc.lsz.demo2;

import java.sql.*;
import java.util.Scanner;

/**
 * @ClassName com.vc.lsz.demo2.mysqlTest2
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/29 2:17 下午
 * @Version 1.0
 */
public class mysqlTest2 {

    private static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";

    private static final String URL = "jdbc:mysql://localhost:3306/myschool";

    private static final String USER = "root",PWD = "19980624";

    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;
        PreparedStatement preparedStatement = null;
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入姓名");
        String stuname = scanner.next();
        System.out.println("请输入密码");
        int stupwd = scanner.nextInt();
        System.out.println("请输入性别");
        String stusex = scanner.next();
        System.out.println("请输入出生日期");
        String borndate = scanner.nextLine();
        try {

            Class.forName(DRIVER_NAME);

            connection = DriverManager.getConnection(URL,USER,PWD);
            System.out.println(connection + "链接成功");

            statement = connection.createStatement();


            String sql = "insert into student (studentno,studentname,loginpwd,sex,gradeid) values (default,?,?,?,?);";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1,stuname);
            preparedStatement.setInt(2,stupwd);
            preparedStatement.setString(3,stusex);
            preparedStatement.setString(4,borndate);

            preparedStatement.executeUpdate();

        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
    }
}
