package com.vc.lsz.demo3.dao;

import java.sql.*;

import static com.vc.lsz.demo3.context.AppContext.*;

/**
 * @ClassName JDBATemplate
 * @auther lsz1310225074@iCloud.com
 * @Description TODO JDBC帮助类
 * @date 2021/12/29 4:01 下午
 * @Version 1.0
 */
public class JDBCTemplate {

    /**
     * 加载驱动要放入静态方法，只创建一次
     */
    static {
        try {
            Class.forName(DRIVER_NAME);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    /**
     * @Author:lsz1310225074@iCloud.com
     * @Description: TODO
     * @DateTime: 2021/12/29 4:22 下午
     * 帮助类中应该抛出异常而不是处理异常
     * 定义方法主动抛异常
     */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PWD);
    }

    /**
     * 关闭连接，需要关闭的连接有数据库连接Connection,执行对象连接Statement,以及结果集ResultSet
     */
    public void close(Connection connection, Statement statement, ResultSet resultSet){
        /**
         * 先打开的链接最后关
         */
        if (resultSet != null){
            try {
//                关闭结果集
                resultSet.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        if (statement != null){
            try {
//                关闭执行对象
                statement.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        if (connection != null){
            try {
//                关闭数据库连接
                connection.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }


//    {
//        try {
////            加载驱动
//            Class.forName(DRIVER_NAME);
////            连接数据库
//            connection = DriverManager.getConnection(URL,USER,PWD);
//        } catch (Exception throwables) {
//            throwables.printStackTrace();
//        }
//    }

}
