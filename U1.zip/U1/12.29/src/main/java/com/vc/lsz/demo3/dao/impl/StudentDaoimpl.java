package com.vc.lsz.demo3.dao.impl;

import com.vc.lsz.demo3.dao.JDBCTemplate;
import com.vc.lsz.demo3.dao.StudentDao;
import com.vc.lsz.demo3.model.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

/**
 * @ClassName StudentDaoimpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/29 4:37 下午
 * @Version 1.0
 */
public class StudentDaoimpl extends JDBCTemplate implements StudentDao {
    @Override
    public boolean add(Student student) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String add = "insert into student values (?,?,?,?,?);";
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(add);
            preparedStatement.setInt(1,student.getStudentNo());
            preparedStatement.setString(2,student.getStudentName());
            preparedStatement.setInt(3,student.getLoginPwd());
            preparedStatement.setString(4,student.getSex());
            preparedStatement.setInt(5,student.getGradeId());


        } catch (Exception throwables) {
            throwables.printStackTrace();

        }finally {
            close(connection,null,null);
        }

        return false;
    }

    @Override
    public boolean delete(int id) {
        return false;
    }

    @Override
    public boolean update(Student student) {
        return false;
    }

    @Override
    public boolean findById(int id) {
        return false;
    }

    @Override
    public List<Student> findAll() {
        return null;
    }
}
