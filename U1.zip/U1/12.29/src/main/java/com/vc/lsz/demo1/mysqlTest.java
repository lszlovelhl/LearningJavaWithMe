package com.vc.lsz.demo1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 * @ClassName com.vc.lsz.demo1.mysqlTest
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/29 11:12 上午
 * @Version 1.0
 */
public class mysqlTest {

    private static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";

    private static final String URL = "jdbc:mysql://localhost:3306/myschool";

    private static final String USER = "root",PWD = "19980624";

    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;
        try {
//            加载驱动
            Class.forName(DRIVER_NAME);
//            创建链接对象
            connection = DriverManager.getConnection(
                    URL,USER,PWD
            );
            System.out.println(connection + "链接成功");
//            创建执行对象
            statement = connection.createStatement();
            System.out.println("请输入年级名");
            Scanner scanner = new Scanner(System.in);

//            执行SQL
            String sql = "insert into grade (gradename) values (" + "'" + scanner.next() + "'" + ");";
            int count = statement.executeUpdate(sql);

//            判断受影响行数
            if (count > 0){
                System.out.println("添加成功");
            }else {
                System.out.println("添加失败");
            }
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }finally {

            if (statement != null){
                try {
                    statement.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }

            if (connection != null){
                try {
                    System.out.println("链接关闭");
                    connection.close();
                } catch (Exception throwables) {
                    throwables.printStackTrace();
                }
            }
        }
    }
}
