package com.vc.lsz.demo3.dao.impl;

import com.vc.lsz.demo3.dao.GradeDao;
import com.vc.lsz.demo3.dao.JDBCTemplate;
import com.vc.lsz.demo3.model.Grade;

import javax.xml.transform.Result;
import java.sql.*;
import java.util.List;

/**
 * @ClassName GradeDaoimpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/29 4:01 下午
 * @Version 1.0
 */
public class GradeDaoimpl extends JDBCTemplate implements GradeDao {
    @Override
    public boolean add(Grade grade) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String add = "insert into grade values (default,?)";
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(add);
            preparedStatement.setString(1, grade.getGradeName());
            int count = preparedStatement.executeUpdate();
//            判断受影响行数
            if (count > 0){
                System.out.println("添加成功");
            }
//            else {
//                System.out.println("添加失败");
//            }

        } catch (Exception throwables) {
            throwables.printStackTrace();
        } finally {
            close(connection, preparedStatement, null);
        }

        return false;
    }

    @Override
    public boolean delete(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String delete = "delete from grade where gradeId=?";

        try {

            connection = getConnection();
            preparedStatement = connection.prepareStatement(delete);
            preparedStatement.setInt(1, id);
            int count = preparedStatement.executeUpdate();
            if (count > 0){
                System.out.println("删除成功");
            }
//            else {
//                System.out.println("删除失败");
//            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            close(connection, preparedStatement, null);
        }

        return false;
    }

    @Override
    public boolean update(Grade grade) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String delete = "update grade set (gradeid,gradename) where gradeId=?";

        try {

            connection = getConnection();
            preparedStatement = connection.prepareStatement(delete);
            preparedStatement.setInt(1, grade.getGradeId());
            int count = preparedStatement.executeUpdate();
            if (count > 0){
                System.out.println("修改成功");
            }
//            else {
//                System.out.println("修改失败");
//            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            close(connection, preparedStatement, null);
        }

        return false;
    }

    @Override
    public boolean findById(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String findbyid = "select gradename from grade where gradeid=?";

        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(findbyid);
            preparedStatement.setInt(1,id);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                System.out.println("查找成功" + resultSet);
            }
//            else {
//                System.out.println("查找失败");
//            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            close(connection,preparedStatement,null);
        }
        return false;
    }

    @Override
    public List<Grade> findAll() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String findall = "select * from grade";
        try {

            connection = getConnection();
            preparedStatement = connection.prepareStatement(findall);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                System.out.println("查找成功" + resultSet);
            }
//            else {
//                System.out.println("查找失败");
//            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            close(connection,preparedStatement,resultSet);
        }
        return null;
    }
}
