package com.vc.lsz.demo3.context;

import java.util.Properties;

/**
 * @ClassName AppContext
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/30 11:39 上午
 * @Version 1.0
 */
public class AppContext {

    //驱动名
    public static String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
    //连接字符串
    public static String URL = "jdbc:mysql://localhost:3306/myschool";
    //数据库用户名和密码
    public static String USER = "root", PWD = "19980624";

    public static void init() throws Exception {
        //创建属性文件对象
        Properties prop = new Properties();
        //加载
        prop.load(AppContext.class.getResourceAsStream("/jdbc.properties"));
        //获取属性文件中的内容
        DRIVER_NAME = prop.getProperty("DRIVER_NAME", DRIVER_NAME);
        URL = prop.getProperty("URL", URL);
        USER = prop.getProperty("USER", USER);
        PWD = prop.getProperty("PWD", PWD);
    }
}
