package com.vc.lsz.demo3.view;

import com.vc.lsz.demo3.dao.impl.GradeDaoimpl;
import com.vc.lsz.demo3.model.Grade;
import com.vc.lsz.demo3.util.ScannerUtils;

import java.util.Scanner;

/**
 * @ClassName Menu
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/29 3:59 下午
 * @Version 1.0
 */
public class Menu {

    GradeDaoimpl grade = new GradeDaoimpl();

    //主菜单
    public void show() {
        System.out.println("1.年级管理");
        System.out.println("2.学生管理");
        System.out.println("0.退出");
        System.out.println("请选择：");
        switch (ScannerUtils.getInt(0, 2)) {
            case 1:
                System.out.println("------------欢迎进入年级管理------------");
                gradeMenu();
            case 2:
                System.out.println("------------欢迎进入学生管理------------");
                studentManage();
            case 0:
                System.out.println("谢谢使用，再见！");
                System.exit(0);
            default:
                System.out.println("请输入0-2的数字！");
        }
        show();
    }

    Scanner input = new Scanner(System.in);

    //年级菜单
    private void gradeMenu() {
        Grade grades=null;
        System.out.println("1.查询年级信息");
        System.out.println("2.增加年级信息");
        System.out.println("3.删除年级信息");
        System.out.println("4.修改年级信息");
        System.out.println("0.返回");
        switch (ScannerUtils.getInt(0, 4)) {
            case 1:
                grade.findAll();
                System.out.println(grade.findAll());
                gradeMenu();
            case 2:
                System.out.println("请输入要添加的年级名:");
                String gradeName = ScannerUtils.getString();
                grades = new Grade(0, gradeName);
                boolean flag = grade.add(grades);
                if (flag) {
                    System.out.println("添加成功！");
                } else {
                    System.out.println("添加失败！");
                }
                gradeMenu();
            case 3:
                System.out.println("请输入要删除的年级编号：");
                int gradeId = input.nextInt();
                boolean flag1 = grade.delete(gradeId);
                if (flag1) {
                    System.out.println("删除成功！");
                } else {
                    System.out.println("删除失败！");
                }
                gradeMenu();
            case 4:
                grade.update(grades);
                gradeMenu();
            case 0:
                show();
            default:
                System.out.println("请输入0-4的数字！");
        }
    }

    //学生菜单
    private void studentManage() {
        System.out.println("1.查询学生信息");
        System.out.println("2.增加学生信息");
        System.out.println("3.删除学生信息");
        System.out.println("4.修改学生信息");
        System.out.println("0.返回");
        switch (ScannerUtils.getInt(0, 4)) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 0:
                show();
            default:
                System.out.println("请输入0-4的数字！");
        }
    }
}
