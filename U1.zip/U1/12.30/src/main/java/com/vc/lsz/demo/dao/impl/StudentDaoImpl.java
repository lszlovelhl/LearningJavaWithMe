package com.vc.lsz.demo.dao.impl;

import com.vc.lsz.demo.dao.JDBCTemplate;
import com.vc.lsz.demo.dao.StudentDao;
import com.vc.lsz.demo.model.Student;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName StudentDaoImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO StudentDao实现类
 * @date 2021/12/30 2:39 下午
 * @Version 1.0
 */
public class StudentDaoImpl extends JDBCTemplate implements StudentDao {

    /**
     * 添加
     *
     * @param add
     * @return 自增长编号identity
     */
    @Override
    public int add(Student add) {
        String sql = "insert into student(studentname,loginpwd,sex,gradeid,borndate) values(?,?,?,?,?)";
        return super.update(sql, add.getName(), add.getPwd(), add.getSex(), add.getGradeId(), new java.sql.Date(add.getBornDate().getTime())).identity;
    }

    /**
     * 删除
     *
     * @param id
     * @return 返回受影响行数count
     */
    @Override
    public int delete(Student id) {
        String sql = "delete from student where studentno=?";
        return super.update(sql, id.getName(), id.getPwd(), id.getSex(), id.getGradeId(), new Date(id.getBornDate().getTime())).count;
    }

    /**
     * 修改
     *
     * @param update
     * @return 返回受影响行数count
     */
    @Override
    public int update(Student update) {
        String sql = "update student set studentname=?,loginpwd=?,sex=?,graid=?,borndate=? where studentno=?";
        return super.update(sql, update.getName(), update.getPwd(), update.getSex(), update.getGradeId(), new Date(update.getBornDate().getTime())).count;
    }

    /**
     * 根据ID查找学生
     *
     * @param id
     * @return 无返回null
     */
    @Override
    public Student findById(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {

            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from student where studentno=?");
            preparedStatement.setInt(1,id);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                int sid = resultSet.getInt("studentno");
                String sname = resultSet.getString("studentname");
                String spwd = resultSet.getString("loginpwd");
                String sex = resultSet.getString("sex");
                int gid = resultSet.getInt("gradeid");
                Date date = resultSet.getDate("borndate");
                return new Student(sid,sname,spwd,sex,gid,date);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return null;
    }

    /**
     * 查找所有学生信息
     *
     * @return 返回集合list
     */
    @Override
    public List<Student> findAll() {
        List<Student> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from student");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                int sid = resultSet.getInt("studentno");
                String sname = resultSet.getString("studentname");
                String spwd = resultSet.getString("loginpwd");
                String sex = resultSet.getString("sex");
                int gid = resultSet.getInt("gradeid");
                Date date = resultSet.getDate("borndate");
                list.add(new Student(sid,sname,spwd,sex,gid,date));
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            close(connection,preparedStatement,resultSet);
        }
        return list;
    }

    /**
     * 根据名字查找学生信息
     *
     * @param name
     * @return 无返回null
     */
    @Override
    public Student findByName(String name) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from student where studentname=?");
            preparedStatement.setObject(1,name);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                int sid = resultSet.getInt("studentno");
                String sname = resultSet.getString("studentname");
                String spwd = resultSet.getString("loginpwd");
                String sex = resultSet.getString("sex");
                int gid = resultSet.getInt("gradeid");
                Date date = resultSet.getDate("borndate");
                return new Student(sid,sname,spwd,sex,gid,date);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            close(connection,preparedStatement,resultSet);
        }
        return null;
    }
}
