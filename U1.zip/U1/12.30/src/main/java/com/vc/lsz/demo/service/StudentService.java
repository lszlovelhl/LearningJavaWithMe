package com.vc.lsz.demo.service;

import com.vc.lsz.demo.model.Student;

import java.util.List;

/**
 * @ClassName StudentService
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/30 3:25 下午
 * @Version 1.0
 */
public interface StudentService{

    boolean addStudent(String name, String pwd, String sex, String gradeName, String born);

    List<Student> findAll();
}
