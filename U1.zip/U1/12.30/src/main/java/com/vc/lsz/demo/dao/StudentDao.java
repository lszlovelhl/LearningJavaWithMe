package com.vc.lsz.demo.dao;

import com.vc.lsz.demo.model.Student;

/**
 * @ClassName StudentDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO StudentDao,独有方法findByName
 * @date 2021/12/30 2:22 下午
 * @Version 1.0
 */
public interface StudentDao extends BaseDao<Student> {
    /**
     * 根据姓名查找
     *
     */
    Student findByName(String name);
}
