package com.vc.lsz.demo.service.impl;

import com.vc.lsz.demo.dao.GradeDao;
import com.vc.lsz.demo.dao.StudentDao;
import com.vc.lsz.demo.dao.impl.GradeDaoImpl;
import com.vc.lsz.demo.dao.impl.StudentDaoImpl;
import com.vc.lsz.demo.model.Grade;
import com.vc.lsz.demo.model.Student;
import com.vc.lsz.demo.service.GradeService;
import com.vc.lsz.demo.service.StudentService;
import com.vc.lsz.demo.util.DateUtils;

import java.util.Date;
import java.util.List;

/**
 * @ClassName GradeServiceImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/30 3:26 下午
 * @Version 1.0
 */
public class GradeServiceImpl implements GradeService {

    private GradeDao gradeDao = new GradeDaoImpl();

    @Override
    public boolean addGrade(String gradeName) {

        //判断年级是否存在
        Grade grade = gradeDao.findByName(gradeName);
        int id = 0;
        if (grade == null) {
            //添加年级
            id = gradeDao.add(new Grade(0, gradeName));
        } else {
            id = grade.getId();
        }

        //封装年级
        Grade grd = new Grade(0, gradeName);
        //调用dao
        return gradeDao.add(grd) > 0;

    }

    @Override
    public List<Grade> findAll() {
        return gradeDao.findAll();
    }

}
