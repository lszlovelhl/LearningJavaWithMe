package com.vc.lsz.demo.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *@Author:lsz1310225074@iCloud.com
 *@Description: TODO
 *@DateTime: 2021/12/30 4:05 下午
 */
public class DateUtils {
    private static ThreadLocal<SimpleDateFormat> fmt = ThreadLocal.withInitial(
            () -> new SimpleDateFormat("yyyy-MM-dd")
    );

    /**
     * 将字符串解析为日期对象,如果解析失败,返回null
     *
     * @param str
     * @return
     */
    public static Date parse(String str) {
        try {
            return fmt.get().parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 将日期格式化为字符串
     *
     * @param date
     * @return
     */
    public static String format(Date date) {
        return fmt.get().format(date);
    }
}
