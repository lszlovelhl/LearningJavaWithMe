package com.vc.lsz.demo.view;

import com.vc.lsz.demo.dao.GradeDao;
import com.vc.lsz.demo.dao.StudentDao;
import com.vc.lsz.demo.dao.impl.GradeDaoImpl;
import com.vc.lsz.demo.dao.impl.StudentDaoImpl;
import com.vc.lsz.demo.model.Grade;
import com.vc.lsz.demo.model.Student;
import com.vc.lsz.demo.service.StudentService;
import com.vc.lsz.demo.service.impl.StudentServiceImpl;
import com.vc.lsz.demo.util.ScannerUtils;

import java.util.List;
import java.util.Scanner;

/**
 * @ClassName Menu
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/30 1:47 下午
 * @Version 1.0
 */
public class Menu {

    private GradeDao gradeDao = new GradeDaoImpl();
    private StudentDao studentDao = new StudentDaoImpl();
    private StudentService studentService = new StudentServiceImpl();
    Scanner scanner = new Scanner(System.in);

    public void show(){
        System.out.println("----------欢迎使用学生管理系统----------");
        System.out.println("     -----1.年级管理-----     ");
        System.out.println("     -----2.学生管理-----     ");
        System.out.println("     -----3.退出系统-----     ");
        System.out.println("请输入：");
        int choice = ScannerUtils.getInt(1,3);
        switch (choice){
            case 1:
                System.out.println("----------欢迎进入年级管理----------");
                grade();
                break;
            case 2:
                System.out.println("----------欢迎进入学生管理----------");
                student();
                break;
            case 3:
                System.out.println("   -------谢谢使用，再见！-------   ");
                System.exit(0);
                break;
            default:
                System.out.println(" --------请输入1-3的数字-------- ");
        }
        show();
    }

    public void grade(){
        System.out.println("     -----1.查询所有年级信息-----     ");
        System.out.println("  -----2.查询指定编号的年级信息------  ");
        System.out.println("      -----3.增加年级信息-----       ");
        System.out.println("  -----4.删除指定编号的年级信息------  ");
        System.out.println("      -----5.修改年级信息-----       ");
        System.out.println("       -----0.返回主页--- ---       ");
        System.out.println("请输入1-5的数字");
        int choice = ScannerUtils.getInt(0,5);
        switch (choice){
            case 1:
                gradeDao.findAll();
                break;
            case 2:
                System.out.println("请输入要查询的年级编号");
                break;
            case 3:
                System.out.println("请输入年级名");
                break;
            case 4:
                System.out.println("请输入要删除的年级编号");
                break;
            case 5:
                break;
            case 0:
                show();
                break;
        }
    }

    public void student(){
        System.out.println("     -----1.查询所有学生信息-----     ");
        System.out.println("  -----2.查询指定编号的学生信息------  ");
        System.out.println("      -----3.增加学生信息-----       ");
        System.out.println("  -----4.删除指定编号的学生信息------  ");
        System.out.println("      -----5.修改学生信息-----       ");
        System.out.println("       -------6.返回--------       ");
        System.out.println("请输入1-6的数字");
        int choice = ScannerUtils.getInt(1,6);
        switch (choice){
            case 1:
                List<Student> stu = studentService.findAll();
//        stu.stream().forEach(a ->
//                System.out.println(a));

                stu.stream().forEach(System.out::println);
                break;
            case 2:

                break;
            case 3:
                System.out.println("请输入学生姓名:");
                String addname = ScannerUtils.nextLine();
                System.out.println("请输入学生密码:");
                String addpwd = ScannerUtils.nextLine();
                System.out.println("请输入学生性别:");
                String addsex = ScannerUtils.nextLine();
                System.out.println("请输入学生年级名:");
                String addgradeName = ScannerUtils.nextLine();
                System.out.println("请输入学生出生日期(如1990-12-12):");
                String addborn = ScannerUtils.nextLine();
                //调用业务逻辑方法
                boolean addflag = studentService.addStudent(addname, addpwd, addsex, addgradeName, addborn);
                if (addflag) {
                    System.out.println("添加成功");
                } else {
                    System.out.println("添加失败");
                }
                break;
            case 4:

                break;
            case 5:
                System.out.println("请输入修改后的学生姓名:");
                String modyname = ScannerUtils.nextLine();
                System.out.println("请输入修改后的学生密码:");
                String modypwd = ScannerUtils.nextLine();
                System.out.println("请输入修改后的学生性别:");
                String modysex = ScannerUtils.nextLine();
                System.out.println("请输入修改后的学生年级名:");
                String modygradeName = ScannerUtils.nextLine();
                System.out.println("请输入修改后的学生出生日期(如1990-12-12):");
                String modyborn = ScannerUtils.nextLine();



                //调用业务逻辑方法
//                boolean modyflag = studentService.addStudent(modyname, modypwd, modysex, modygradeName, modyborn);
//                if (modyflag) {
//                    System.out.println("添加成功");
//                } else {
//                    System.out.println("添加失败");
//                }
                break;
            case 0:
                show();
                break;
        }
    }

}
