package com.vc.lsz.demo.dao;

import java.util.List;

/**
 * @ClassName BaseDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO 范型DAO,将其余DAO中的复用内容整合
 * @date 2021/12/30 2:22 下午
 * @Version 1.0
 */
public interface BaseDao<T> {
    /**
     * 添加
     * 返回自增长编号
     * @param add
     */
    int add(T add);

    /**
     * 根据ID删除
     * 返回受影响行数
     */
    int delete(T id);

    /**
     * 修改除主键外的其他信息
     * 返回受影响行数
     */
    int update(T update);

    /**
     * 根据ID查找
     * 无返回
     */
    T findById(int id);

    /**
     * 查找所有
     * 无返回
     */
    List<T> findAll();
}
