package com.vc.lsz.demo.dao;

/**
 * @ClassName UpdateResult
 * @auther lsz1310225074@iCloud.com
 * @Description TODO 执行executeUpdate后的结果对象
 * @date 2021/12/30 2:58 下午
 * @Version 1.0
 */
public class UpdateResult {
    /**
     * 受影响行数
     */
    public int count;
    /**
     * 自增长编号
     */
    public int identity;
}
