package com.vc.lsz.demo.model;

/**
 * @ClassName Grade
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/30 2:19 下午
 * @Version 1.0
 */
public class Grade {
    private int id;
    private String name;

    @Override
    public String toString() {
        return "Grade{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

    public Grade(){}

    public Grade(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
