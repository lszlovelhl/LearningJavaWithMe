package com.vc.lsz.demo.service.impl;

import com.vc.lsz.demo.dao.GradeDao;
import com.vc.lsz.demo.dao.StudentDao;
import com.vc.lsz.demo.dao.impl.GradeDaoImpl;
import com.vc.lsz.demo.dao.impl.StudentDaoImpl;
import com.vc.lsz.demo.model.Grade;
import com.vc.lsz.demo.model.Student;
import com.vc.lsz.demo.service.StudentService;
import com.vc.lsz.demo.util.DateUtils;

import java.util.Date;
import java.util.List;

/**
 * @ClassName StudentServiceImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/30 3:27 下午
 * @Version 1.0
 */
public class StudentServiceImpl implements StudentService {

    private StudentDao studentDao = new StudentDaoImpl();
    private GradeDao gradeDao = new GradeDaoImpl();

    @Override
    public boolean addStudent(String name, String pwd, String sex, String gradeName, String born) {
        //将String封装成Date对象
        Date date = DateUtils.parse(born);
        if (date == null) {
            return false;
        }

        //判断年级是否存在
        Grade grade = gradeDao.findByName(gradeName);
        int id = 0;
        if (grade == null) {
            //添加年级
            id = gradeDao.add(new Grade(0, gradeName));
        } else {
            id = grade.getId();
        }
        //封装学生
        Student stu = new Student(0, name, pwd, sex, id, date);
        //调用dao
        return studentDao.add(stu) > 0;
    }

        @Override
        public List<Student> findAll () {
            return studentDao.findAll();
        }
    }
