package com.vc.lsz.demo;

import com.vc.lsz.demo.context.AppContext;
import com.vc.lsz.demo.view.Menu;

import java.io.IOException;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/30 1:43 下午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
        //加载配置
        try {
            AppContext.init();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        //开启菜单
        new Menu().show();
    }
}
