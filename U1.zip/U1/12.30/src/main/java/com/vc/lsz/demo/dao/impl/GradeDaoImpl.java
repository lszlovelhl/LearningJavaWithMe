package com.vc.lsz.demo.dao.impl;

import com.vc.lsz.demo.dao.GradeDao;
import com.vc.lsz.demo.dao.JDBCTemplate;
import com.vc.lsz.demo.model.Grade;
import com.vc.lsz.demo.model.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @ClassName GradeDaoImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO GradeDao实现类
 * @date 2021/12/30 2:39 下午
 * @Version 1.0
 */
public class GradeDaoImpl extends JDBCTemplate implements GradeDao {

    /**
     * 添加年级
     *
     * @param add
     * @return 返回自增长编号identity
     */
    @Override
    public int add(Grade add) {
        String sql = "insert into grade(default,gradename) values(?,?)";
        return super.update(sql, add.getId(), add.getName()).identity;
    }

    /**
     * 删除年级
     *
     * @param id
     * @return 返回受影响行数count
     */
    @Override
    public int delete(Grade id) {
        String sql = "delete from grade where gradeid=?";
        return super.update(sql, id.getId()).count;
    }

    /**
     * 修改年级信息
     *
     * @param update
     * @return 返回受影响行数count
     */
    @Override
    public int update(Grade update) {
        String sql = "update grade set gradename=? where gradeid=?";
        return super.update(sql, update.getName(), update.getId()).count;
    }

    /**
     * 根据ID查找年级信息
     *
     * @param id
     * @return 无返回null
     */
    @Override
    public Grade findById(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from grade where gradeid = ?");
            preparedStatement.setObject(1, id);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int gid = resultSet.getInt("gradeid");
                String gname = resultSet.getString("gradename");

                return new Grade(gid, gname);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return null;
    }

    /**
     * 查找所有年级信息
     *
     * @return 返回集合list
     */
    @Override
    public List<Grade> findAll() {
        List<Grade> list = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from grade");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int gid = resultSet.getInt("gradeid");
                String gname = resultSet.getString("gradename");
                list.add(new Grade(gid, gname));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return list;
    }

    /**
     * 根据年级名查找年级信息
     *
     * @param name
     * @return 无返回null
     */
    @Override
    public Grade findByName(String name) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("select * from student " +
                    "where studentname = ?");
            preparedStatement.setObject(1, name);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int gid = resultSet.getInt("gradeid");
                String gname = resultSet.getString("gradename");
                return new Grade(gid, gname);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(connection, preparedStatement, resultSet);
        }
        return null;
    }
}

