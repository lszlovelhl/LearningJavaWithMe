package com.vc.lsz.server.handler.impl;



import com.vc.lsz.common.model.User;
import com.vc.lsz.server.context.ServerContext;
import com.vc.lsz.server.handler.MessageHandler;
import com.vc.lsz.server.socket.UserSocket;

import java.io.DataInputStream;
import java.io.DataOutputStream;

/**
 * author: VC
 * create: 2022/1/11 13:44
 * version: 1.0.0
 */
public class RegHandler implements MessageHandler {
    @Override
    public void processMessage(UserSocket client) throws Exception {
        //读取用户名
        String name = client.getIn().readUTF();
        //读取密码
        String pwd = client.getIn().readUTF();

        int result;
        //验证是否存在
        if (ServerContext.users.containsKey(name)) {
            //失败
            result = 0;
        } else {
            //db
            ServerContext.users.put(name, new User(name, pwd));
            //成功
            result = 2;
        }
        //向客户端写出结果
        client.getOut().writeByte(result);
    }
}
