package com.vc.lsz.server.handler.impl;

import com.vc.lsz.common.model.User;
import com.vc.lsz.server.context.ServerContext;
import com.vc.lsz.server.handler.MessageHandler;
import com.vc.lsz.server.socket.UserSocket;

import java.io.DataInputStream;
import java.io.DataOutputStream;

/**
 * author: VC
 * create: 2022/1/11 13:43
 * version: 1.0.0
 */
public class LoginHandler implements MessageHandler {
    @Override
    public void processMessage(UserSocket client) throws Exception {
        String name = client.getIn().readUTF();
        String pwd = client.getIn().readUTF();
        //判断是否能登录
        User user = ServerContext.users.get(name);
        int result;
        if (user == null) {
            //用户名不存在
            result = 0;
        } else {
            //用户存在,验证密码
            if (user.getPwd().equals(pwd)) {
                //密码正确,可以登录
                result = 2;
                //绑定名字
                client.setName(name);
            } else {
                //密码错误
                result = 1;
            }
        }
        //向客户端写出结果
        client.getOut().writeByte(result);
    }
}
