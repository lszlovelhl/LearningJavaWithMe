package com.vc.lsz.server.handler;


import com.vc.lsz.server.socket.UserSocket;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * 消息处理器
 */
public interface MessageHandler {
    /**
     * 处理消息的方法
     *
     * @throws Exception
     */
    void processMessage(UserSocket userSocket) throws Exception;
}
