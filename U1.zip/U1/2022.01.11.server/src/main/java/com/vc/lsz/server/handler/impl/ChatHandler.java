package com.vc.lsz.server.handler.impl;

import com.vc.lsz.server.context.ServerContext;
import com.vc.lsz.server.handler.MessageHandler;
import com.vc.lsz.server.socket.UserSocket;

import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

/**
 * author: VC
 * create: 2022/1/11 14:23
 * version: 1.0.0
 */
public class ChatHandler implements MessageHandler {
    @Override
    public void processMessage(UserSocket client) throws Exception {
        //读取聊天内容
        String msg = client.getIn().readUTF();
        //判断是否是退出
        if (msg.equalsIgnoreCase("exit")){
            //关闭套接字
            client.getSocket().close();
            //从集合中移除
            ServerContext.onlineUsers.remove(client);
            return;
        }
        //msg = "hello"
        msg = client.getName() + " 说:" + msg;
        //排除发送者
        for (UserSocket onlineUser : ServerContext.onlineUsers) {
            if (onlineUser == client) {
                continue;
            }
            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(onlineUser.getOut())
            );
            writer.write(msg);
            writer.newLine();
            writer.flush();
        }
    }
}
