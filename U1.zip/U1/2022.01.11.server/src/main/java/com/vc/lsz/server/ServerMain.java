package com.vc.lsz.server;


import com.vc.lsz.server.socket.ChatServer;

import java.io.IOException;

/**
 * @ClassName ServerMain
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:06 下午
 * @Version 1.0
 */
public class ServerMain {
    public static void main(String[] args) {
        try {
            new ChatServer().begin();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
