package com.vc.lsz.server.context;

import com.vc.lsz.common.MessageType;
import com.vc.lsz.common.model.User;
import com.vc.lsz.server.handler.MessageHandler;
import com.vc.lsz.server.socket.UserSocket;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.Socket;
import java.net.URL;
import java.util.*;

/**
 * @ClassName ServerContext
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:07 下午
 * @Version 1.0
 */

public class ServerContext {
    /**
     * 已注册用户集合
     */
    public static Map<String, User> users = new HashMap<>();

    /**
     * 消息处理器映射
     * key: int MessageType消息类型值
     */
    public static Map<Integer, MessageHandler> handlerMap = new HashMap<>();

    static {
        users.put("jack", new User("jack", "123"));
        users.put("rose", new User("rose", "123"));

        //读取配置文件
        URL url = ServerContext.class.getResource("/handler.properties");
        if (url == null) {
            System.out.println("类根路径下缺少handler.properties配置文件");
            System.exit(0);
        }
        Properties prop = new Properties();
        try {
            prop.load(new FileInputStream(url.getFile()));
            //获取消息处理器的映射关系
            //反射获取MessageType接口中的所有字段
            Field[] fields = MessageType.class.getFields();
            for (Field field : fields) {
                //调用静态属性,obj传null
                try {
                    //获取消息类型中的值
                    Object obj = field.get(null);
                    String value = prop.getProperty(obj.toString());
                    //判断是否配置了映射
                    if (value == null) {
                        continue;
                    }
                    //使用反射创建对象
                    Object handler = Class.forName(value).newInstance();
                    //验证是否是MessageHandler的子类
                    if (!(handler instanceof MessageHandler)) {
                        System.err.println(value + " 不是 " + MessageHandler.class.getName() + " 的子类!");
                        continue;
                    }
                    //放入集合
                    handlerMap.put((Integer) obj, (MessageHandler) handler);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static final int PORT = 9527;
    /**
     * 服务器是否运行中
     */
    public static boolean isRunning = true;
    /**
     * 在线用户集合
     */
    public static List<UserSocket> onlineUsers = new ArrayList<>();
}


//public class ServerContext {
//
//    /**
//     * 已注册用户集合
//     */
//    public static Map<String, User> users = new HashMap<String, User>();
//
//    static{
//        users.put("jack", new User("jack", "123"));
//        users.put("rose", new User("rose", "123"));
//    }
//
//    public static final int PORT = 9527;
//    public static final String HOST = "127.0.0.1";
//    /**
//     * 服务器是否运行中
//     */
//    public static boolean isRunning = true;
//    /**
//     * 在线用户集合
//     */
//    public static List<Socket> onlineUsers = new ArrayList<>();
//
//}
