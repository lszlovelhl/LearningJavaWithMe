package com.vc.lsz.server.socket;


import com.vc.lsz.server.context.ServerContext;
import com.vc.lsz.server.thread.ProcessClientThread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @ClassName com.vc.lsz.Server
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:30 下午
 * @Version 1.0
 */

public class ChatServer extends ServerSocket {
    public ChatServer() throws IOException {
        super(ServerContext.PORT);
    }

    public void begin() {
        while (ServerContext.isRunning) {
            try {
                //监听客户端连接
                Socket client = accept();
                //封装套接字
                UserSocket socket = new UserSocket(client);
                //加入到集合中
                ServerContext.onlineUsers.add(socket);
                //线程处理客户端消息
                new ProcessClientThread(socket).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

//public class ChatServer extends ServerSocket {
//    private static ChatServer instance;
//
//    public static ChatServer getInstance() {
//        if (instance == null) {
//            try {
//                instance = new ChatServer();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        return instance;
//    }
//
//    public ChatServer() throws IOException {
//        super(ServerContext.PORT);
//    }
//
//    public void begin() {
//        while (ServerContext.isRunning) {
//            try {
//                //监听客户端连接
//                Socket client = accept();
//                //加入到集合中
//                ServerContext.onlineUsers.add(client);
//
//                System.out.println("客户端链接成功" + client.getRemoteSocketAddress());
//
//                //线程处理客户端消息
//                new ProcessClientThread(client).start();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//}
