package com.vc.lsz.server.socket;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * @ClassName UserSocket
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/11 3:57 下午
 * @Version 1.0
 */
public class UserSocket {
    //登录用户名
    private String name;
    //套接字
    private Socket socket;
    //只读
    private DataInputStream in;
    //只读
    private DataOutputStream out;

    public DataOutputStream getOut() throws IOException {
        if (out == null) {
            out = new DataOutputStream(socket.getOutputStream());
        }
        return out;
    }

    public DataInputStream getIn() throws IOException {
        if (in == null) {
            in = new DataInputStream(socket.getInputStream());
        }
        return in;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Socket getSocket() {
        return socket;
    }


    public UserSocket(Socket socket) {
        this.socket = socket;
    }

}

