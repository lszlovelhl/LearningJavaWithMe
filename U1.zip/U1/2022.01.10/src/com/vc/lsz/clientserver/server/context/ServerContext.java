package com.vc.lsz.clientserver.server.context;

import com.vc.lsz.clientserver.common.model.User;

import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ClassName ServerContext
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:07 下午
 * @Version 1.0
 */
public class ServerContext {

    /**
     * 已注册用户集合
     */
    public static Map<String, User> users = new HashMap<>();

    static{
        users.put("jack", new User("jack", "123"));
        users.put("rose", new User("rose", "123"));
    }

    public static final int PORT = 9527;
    public static final String HOST = "127.0.0.1";
    /**
     * 服务器是否运行中
     */
    public static boolean isRunning = true;
    /**
     * 在线用户集合
     */
    public static List<Socket> onlineUsers = new ArrayList<>();

}
