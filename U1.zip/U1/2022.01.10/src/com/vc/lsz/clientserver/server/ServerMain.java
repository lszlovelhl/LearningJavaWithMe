package com.vc.lsz.clientserver.server;

import com.vc.lsz.clientserver.server.socket.Server;

import java.io.IOException;

/**
 * @ClassName ServerMain
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:06 下午
 * @Version 1.0
 */
public class ServerMain {
    public static void main(String[] args) {
        try {
            new Server().begin();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
