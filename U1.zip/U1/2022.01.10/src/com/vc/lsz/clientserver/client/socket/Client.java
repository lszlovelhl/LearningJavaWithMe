package com.vc.lsz.clientserver.client.socket;

import com.vc.lsz.clientserver.client.thread.ProcessServerThread;
import com.vc.lsz.clientserver.common.MessageType;
import com.vc.lsz.clientserver.server.context.ServerContext;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * @ClassName com.vc.lsz.Client
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:38 下午
 * @Version 1.0
 */
public class Client extends Socket {
    private static Client instance;

    public static Client getInstance() {
        if (instance == null) {
            try {
                instance = new Client();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return instance;
    }

    private Client() throws IOException {
        super(ServerContext.HOST, ServerContext.PORT);
    }


    public int sendLogin(String name, String pwd) {
        try {
            DataOutputStream outputStream = new DataOutputStream(this.getOutputStream());
            DataInputStream inputStream = new DataInputStream(this.getInputStream());
            //消息头
            outputStream.writeByte(MessageType.LOGIN);
            //消息正文
            outputStream.writeUTF(name);
            outputStream.writeUTF(pwd);
            //读取服务器响应
            return inputStream.readByte();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public int sendSignIn(String name, String pwd) {
        try {
            DataOutputStream outputStream = new DataOutputStream(this.getOutputStream());
            DataInputStream inputStream = new DataInputStream(this.getInputStream());
            //写消息头
            outputStream.writeByte(MessageType.SIGN_IN);
            //写消息正文
            outputStream.writeUTF(name);
            outputStream.writeUTF(pwd);
            //读取响应
            return inputStream.readByte();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public void sendChat(String message) {
        new ProcessServerThread(this).start();
        try {
//            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(this.getOutputStream()));
            DataOutputStream outputStream = new DataOutputStream(this.getOutputStream());
//            DataInputStream inputStream = new DataInputStream(this.getInputStream());
            while (true) {
                outputStream.writeByte(MessageType.CHAT);
                outputStream.writeUTF(message);
//                bufferedWriter.write(message);
//                bufferedWriter.newLine();
//                bufferedWriter.flush();
                if (message.equalsIgnoreCase("exit")) {
                    this.close();
                    ServerContext.onlineUsers.remove(this);
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//    public void begin() {
//        new ProcessServerThread(this).start();
//        sendMessage();
//    }

//    public void begin(){
//        new ProcessServerThread(this).start();
//        sendMessage();
//    }
//
//    private void sendMessage() {
//        try {
//            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(this.getOutputStream()));
//            while (true) {
//                Scanner scanner = new Scanner(System.in);
//                System.out.println("请输入发送给服务器的信息(输入exit退出)");
//                String data = scanner.nextLine();
//                bufferedWriter.write(data);
//                bufferedWriter.newLine();
//                bufferedWriter.flush();
//                if (data.equalsIgnoreCase("exit")) {
//                    close();
//                    return;
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
}
