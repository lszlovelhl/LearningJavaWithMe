package com.vc.lsz.clientserver.client.view;

import com.vc.lsz.clientserver.client.service.UserService;
import com.vc.lsz.clientserver.client.service.impl.UserServiceImpl;
import com.vc.lsz.clientserver.client.socket.Client;
import com.vc.lsz.clientserver.client.util.ScannerUtils;
import com.vc.lsz.clientserver.server.socket.Server;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.util.Scanner;

/**
 * @ClassName Menu
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:58 下午
 * @Version 1.0
 */
public class Menu {
    private UserService userService = new UserServiceImpl();

    public void show() {
        System.out.println("1.登录");
        System.out.println("2.注册");
        System.out.println("0.退出");
        int choice = ScannerUtils.getInt(0, 2);
        switch (choice) {
            case 1:
                showLogin();
                break;
            case 2:
                showSignIn();
//                show();
                break;
            case 0:
                System.exit(0);
                break;
        }
    }

    private void showSignIn() {
        System.out.println("请输入用户名:");
        String name = ScannerUtils.nextLine();
        System.out.println("请输入密码:");
        String pwd = ScannerUtils.nextLine();
        int result = userService.signIn(name, pwd);
        if (result == 4) {
            System.out.println("注册成功，即将跳转至登录页面");
            showLogin();
        } else if (result == 0) {
            System.out.println("用户名已存在，要登录吗？(y/n)");
            String choose = ScannerUtils.next();
            if (choose.equalsIgnoreCase("y")) {
                showLogin();
            } else if (choose.equalsIgnoreCase("n")) {
                show();
            }
        }
    }

    private void showLogin() {
        System.out.println("请输入用户名:");
        String name = ScannerUtils.nextLine();
        System.out.println("请输入密码:");
        String pwd = ScannerUtils.nextLine();
        int result = userService.login(name, pwd);
        if (result == 2) {
            System.out.println("登录成功...进入聊天大厅");
            //启动线程读取服务器的分发消息
            while (true) {
                System.out.println("请输入要发送的信息");
                String message = ScannerUtils.nextLine();
                userService.chat(message);

            }
//            com.vc.lsz.Client.getInstance().sendChat(message);
//            com.vc.lsz.Client.getInstance().begin();
//            com.vc.lsz.Server.getInstance().begin();
//            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(this.getOutputStream()));
//            while (true) {
//                Scanner scanner = new Scanner(System.in);
//                System.out.println("请输入聊天内容(exit退出):");
//                String data = scanner.nextLine();
//                bufferedWriter.write(data);
//                bufferedWriter.newLine();
//                bufferedWriter.flush();
//                if (data.equalsIgnoreCase("exit")) {
//                    close();
//                    return;
//            }
        } else if (result == 0) {
            System.out.println("用户名不存在");
            show();
        } else if (result == 1) {
            System.out.println("密码错误");
            show();
        }
    }
}
