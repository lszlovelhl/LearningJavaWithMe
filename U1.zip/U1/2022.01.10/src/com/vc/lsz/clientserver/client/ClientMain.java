package com.vc.lsz.clientserver.client;

import com.vc.lsz.clientserver.client.view.Menu;

/**
 * @ClassName ClientMain
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:06 下午
 * @Version 1.0
 */
public class ClientMain {
    public static void main(String[] args) {
        new Menu().show();
    }
}
