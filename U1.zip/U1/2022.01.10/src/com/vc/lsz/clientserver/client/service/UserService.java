package com.vc.lsz.clientserver.client.service;

/**
 * @ClassName UserService
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:52 下午
 * @Version 1.0
 */
public interface UserService {
    int login(String name,String pwd);

    int signIn(String name, String pwd);

    void chat(String message);
}
