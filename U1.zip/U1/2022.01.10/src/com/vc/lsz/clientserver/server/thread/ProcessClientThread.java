package com.vc.lsz.clientserver.server.thread;

import com.vc.lsz.clientserver.common.MessageType;
import com.vc.lsz.clientserver.common.model.User;
import com.vc.lsz.clientserver.server.context.ServerContext;

import java.io.*;
import java.net.Socket;

/**
 * @ClassName ProcessServerThread
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 6:08 下午
 * @Version 1.0
 */

//public class ProcessClientThread extends Thread {
//    private UserSocket client;
//
//    public ProcessClientThread(UserSocket client) {
//        this.client = client;
//        setDaemon(true);
//    }
//
//    @Override
//    public void run() {
//        //读取客户端消息
//        try {
//            DataInputStream din = new DataInputStream(
//                    client.getSocket().getInputStream()
//            );
//
//            //循环读取
//            while (ServerContext.isRunning) {
//                //读取一个字节,表示消息头
//                int type = din.readByte();
//                //根据消息头,获取消息处理器
//                MessageHandler handler = ServerContext.handlerMap.get(type);
//                try {
//                    //处理消息
//                    handler.processMessage(client);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        } catch (IOException e) {
//            System.out.println("客户端[" + client.getSocket().getRemoteSocketAddress() + "]已断开");
//        }
//    }
//}


//public class ProcessClientThread extends Thread {
//    private Socket client;
//
//    public ProcessClientThread(Socket client) {
//        this.client = client;
//        setDaemon(true);
//    }
//
//    @Override
//    public void run() {
//        //读取客户端消息
//        try {
//            DataInputStream din = new DataInputStream(
//                    client.getInputStream()
//            );
//            DataOutputStream out = new DataOutputStream(
//                    client.getOutputStream()
//            );
//            //循环读取
//            while (ServerContext.isRunning) {
//                //读取一个字节,表示消息头
//                int type = din.readByte();
//                switch (type) {
//                    case MessageType.LOGIN://登录
//                        doLogin(din, out);
//                        break;
//                    case MessageType.SIGN_IN://注册的
//                        doSignIn(din, out);
//                        break;
//                    case MessageType.CHAT://聊天
//                        doChat(din);
//                        break;
//                }
//            }
//        } catch (IOException e) {
//            System.out.println("客户端[" + client.getRemoteSocketAddress() + "]已断开");
//        }
//    }
//
//
//    private void doChat(DataInputStream din) {
//        try {
//            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
//            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
//            while (true) {
//                String message = din.readUTF();
//                if (message.equalsIgnoreCase("exit")){
//                    client.close();
//                    return;
//                }
//                for (Socket onlineUser : ServerContext.onlineUsers) {
//                    if (onlineUser == client){
//                        continue;
//                    }
//
////                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
//                    bufferedWriter.write(message);
//                    bufferedWriter.newLine();
//                    bufferedWriter.flush();
//
////                    sendMessage(onlineUser,"客户端" + client.getRemoteSocketAddress() + "发送" + message);
//                }
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//
////        try {
//////            接收客户端消息
////            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
//////            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
////            while (true) {
////                String read = bufferedReader.readLine();
////                if (read.equalsIgnoreCase("exit")) {
//////                    关闭客户端套接字
////                    client.close();
////                    return;
////                }
//////                System.out.println("客户端发送 " + read);
//////                分发给其他客户端实现公聊
////                for (Socket otherClient : com.vc.lsz.cs.server.context.ServerContext.onlineUsers) {
//////                    排除发送者
////                    if (otherClient == client) {
////                        continue;
////                    }
//////                    将消息发给当前遍历的客户端
////                    sendMessage(otherClient, "客户端" + client.getRemoteSocketAddress() + "发送" + read);
////                }
////            }
////        } catch (Exception e) {
////            System.out.println("客户端" + client.getRemoteSocketAddress() + "已断开");
////        } finally {
//////            从在线用户集合中移除
////            com.vc.lsz.cs.server.context.ServerContext.onlineUsers.remove(client);
////        }
//    }
//
////    private void sendMessage(Socket socket, String message) {
////        try {
////            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
////            bufferedWriter.write(message);
////            bufferedWriter.newLine();
////            bufferedWriter.flush();
////        } catch (IOException e) {
////            e.printStackTrace();
////        }
////    }
//
//    private void doSignIn(DataInputStream din, DataOutputStream out) throws IOException {
//        String name = din.readUTF();
//        String pwd = din.readUTF();
//        User user = ServerContext.users.get(name);
//        int result;
//        if (name == user.getName()) {
//            //用户名已存在
//            result = 0;
//        } else {
//            //用户不存在,可以注册
//            ServerContext.users.put(name,new User(name,pwd));
//            result = 4;
//        }
//        out.writeByte(result);
//    }
//
//
//    private void doLogin(DataInputStream din, DataOutputStream out) throws IOException {
//        String name = din.readUTF();
//        String pwd = din.readUTF();
//        //判断是否能登录
//        User user = ServerContext.users.get(name);
//        int result;
//        if (user == null) {
//            //用户名不存在
//            result = 0;
//        } else {
//            //用户存在,验证密码
//            if (user.getPwd().equals(pwd)) {
//                //密码正确,可以登录
//                result = 2;
//            } else {
//                //密码错误
//                result = 1;
//            }
//        }
//        //向客户端写出结果
//        out.writeByte(result);
//    }
//}
