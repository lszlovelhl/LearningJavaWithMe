package com.vc.lsz.cs.server.thread;

import com.vc.lsz.cs.server.context.ServerContext;

import java.io.*;
import java.net.Socket;

/**
 * @ClassName ProcessClientThread
 * @auther lsz1310225074@iCloud.com
 * @Description TODO 客户端守护线程：处理客户端消息
 * @date 2022/1/10 11:26 上午
 * @Version 1.0
 */
public class ProcessClientThread extends Thread {

    private Socket client;

//    private Runnable run;

    public ProcessClientThread(Socket client) {
        this.client = client;
        setDaemon(true);
    }

//    public ProcessClientThread(Runnable target, Runnable run) {
//        super(target);
//        this.run = run;
//    }

    @Override
    public void run() {
        /**
         * 读取服务器消息
         */
        try {
//            接收客户端消息
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
//            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            while (true) {
                String read = bufferedReader.readLine();
                if(read.equalsIgnoreCase("exit")){
//                    关闭客户端套接字
                    client.close();
                    return;
                }
//                System.out.println("客户端发送 " + read);
//                分发给其他客户端实现公聊
                for (Socket otherClient : ServerContext.onlineUsers) {
//                    排除发送者
                    if (otherClient == client){
                        continue;
                    }
//                    将消息发给当前遍历的客户端
                    sendMessage(otherClient,"客户端" + client.getRemoteSocketAddress() + "发送" + read);
                }
            }
        } catch (Exception e) {
            System.out.println("客户端已断开" + client.getRemoteSocketAddress());
        }finally {
//            从在线用户集合中移除
            ServerContext.onlineUsers.remove(client);
        }
//        super.run();
    }

    private void sendMessage(Socket socket,String message) {
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            bufferedWriter.write(message);
            bufferedWriter.newLine();
            bufferedWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
