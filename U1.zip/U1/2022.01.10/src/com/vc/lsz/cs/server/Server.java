package com.vc.lsz.cs.server;

import com.vc.lsz.cs.server.context.ServerContext;
import com.vc.lsz.cs.server.thread.ProcessClientThread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @ClassName com.vc.lsz.Server
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 11:11 上午
 * @Version 1.0
 */
public class Server extends ServerSocket {

    public Server() throws IOException {
        super(ServerContext.port);
    }

    public void begin() {
        while (true) {
            try {
                Socket client = accept();
                ServerContext.onlineUsers.add(client);
                System.out.println("客户端链接成功" + client.getRemoteSocketAddress());
                new ProcessClientThread(client).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
