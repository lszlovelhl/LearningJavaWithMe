package com.vc.lsz.cs.client;

import com.vc.lsz.cs.server.context.ServerContext;
import com.vc.lsz.cs.client.thread.ProcessServerThread;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * @ClassName com.vc.lsz.Client
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 11:11 上午
 * @Version 1.0
 */
public class Client extends Socket {
    public Client() throws IOException {
        super(ServerContext.host, ServerContext.port);
    }

    public void begin() {
        new ProcessServerThread(this).start();
        sendMessage();
    }

    private void sendMessage() {
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(this.getOutputStream()));
            while (true) {
                Scanner scanner = new Scanner(System.in);
                System.out.println("请输入发送给服务器的信息(输入exit退出)");
                String data = scanner.nextLine();
                bufferedWriter.write(data);
                bufferedWriter.newLine();
                bufferedWriter.flush();
                if (data.equalsIgnoreCase("exit")) {
                    close();
                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
