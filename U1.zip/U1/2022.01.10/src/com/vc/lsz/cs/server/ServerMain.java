package com.vc.lsz.cs.server;

import com.vc.lsz.cs.client.Client;
import com.vc.lsz.cs.server.Server;

import java.io.IOException;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 11:10 上午
 * @Version 1.0
 */
public class ServerMain {
    public static void main(String[] args) {
        try {
//            new com.vc.lsz.Client().begin();
            new Server().begin();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
