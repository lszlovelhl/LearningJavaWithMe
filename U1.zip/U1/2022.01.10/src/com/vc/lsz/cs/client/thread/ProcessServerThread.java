package com.vc.lsz.cs.client.thread;

import com.vc.lsz.cs.client.Client;

import java.io.*;
import java.net.Socket;

/**
 * @ClassName ProcessServerThread
 * @auther lsz1310225074@iCloud.com
 * @Description TODO 服务器守护线程
 * @date 2022/1/10 2:28 下午
 * @Version 1.0
 */
public class ProcessServerThread extends Thread{
    private Client client;
//    private List<Socket> sockets;

    public ProcessServerThread(Client client) {
        this.client = client;
//        this.sockets = sockets;
        setDaemon(true);
    }

    @Override
    public void run() {
        try {
//            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(server.getOutputStream()));
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
            while (true) {
                String reade = bufferedReader.readLine();
                System.out.println(
//                        "客户端" + client.getRemoteSocketAddress() + "发送" +
                                reade);
//                bufferedWriter.write(reade);
//                bufferedWriter.newLine();
//                bufferedWriter.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
