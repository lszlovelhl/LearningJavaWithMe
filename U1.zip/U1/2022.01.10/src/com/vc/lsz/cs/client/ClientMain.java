package com.vc.lsz.cs.client;

import com.vc.lsz.cs.client.Client;
import com.vc.lsz.cs.server.Server;

import java.io.IOException;

/**
 * @ClassName ClientMain
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 1:44 下午
 * @Version 1.0
 */
public class ClientMain {
    public static void main(String[] args) {
        try {
            new Client().begin();
//            new com.vc.lsz.Client().begin();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
