package com.vc.lsz.cs.server.context;

import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName ServerContext
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 2:16 下午
 * @Version 1.0
 */
public class ServerContext {
    public static List<Socket> onlineUsers = new ArrayList<>();
    public static final int port = 9898;
    public static final String host = "127.0.0.1";
}
