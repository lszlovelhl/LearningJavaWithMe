package com.vc.lsz.client;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 10:17 上午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
        try {
//            Socket socket = new Socket("192.168.0.108", 9899);
            Socket socket = new Socket("192.168.0.106", 9528);
            System.out.println("服务器链接成功" + socket);
            /**
             * 先向服务器发送消息
             */
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            /**
             * 读取客户端发送消息
             */
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            while (true) {
                Scanner scanner = new Scanner(System.in);
                System.out.println("请输入要传输的信息");
                String data = scanner.nextLine();

                /**
                 * 向服务器发送内容
                 */
                bufferedWriter.write(data);
                /**
                 * 换行
                 */
                bufferedWriter.newLine();
                /**
                 * 刷新缓冲区
                 */
                bufferedWriter.flush();
                String reade = bufferedReader.readLine();
                System.out.println("客户端发送信息" + reade);
                System.out.println("服务器返回 " + reade + " ok");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
