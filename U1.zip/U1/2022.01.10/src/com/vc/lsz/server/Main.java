package com.vc.lsz.server;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/10 9:48 上午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
        try {
            /**
             * 启动服务器链接，赋予监听端口
             */
            ServerSocket serverSocket = new ServerSocket(9899);
            System.out.println("服务器创建成功，信息为" + serverSocket.getLocalPort());
            /**
             * 创建客户端链接
             */
            Socket client = serverSocket.accept();
            System.out.println("客户端链接成功，信息为" + client.getRemoteSocketAddress());
            /**
             * 获取客户端消息
             */
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

            while (true) {
                String reade = bufferedReader.readLine();
                System.out.println("客户端发送" + reade);
                bufferedWriter.write(reade);
                bufferedWriter.newLine();
                bufferedWriter.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
