package com.vc.demo2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * Socket客户端
 * author: VC
 * create: 2022/1/10 10:01
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {
        try {
            //启动客户端
            Socket socket = new Socket("127.0.0.1", 9527);
            System.out.println("客户端与服务器连接成功" + socket);
            //向服务器发送消息
            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(
                            socket.getOutputStream()
                    )
            );
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream()
                    )
            );
            Scanner sc = new Scanner(System.in);
            while (true) {
                System.out.println("请输入聊天内容(输入exit退出):");
                String str = sc.nextLine();
                //向服务器发送聊天内容
                out.write(str);
                //换行
                out.newLine();
                //将内容冲刷给服务器
                out.flush();
                //判断是否是退出消息
                if (str.equalsIgnoreCase("exit")) {
                    return;
                }
                //读取服务器消息
                str = reader.readLine();
                System.out.println("服务器说:" + str);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
