package com.vc.demo1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 演示Socket服务器
 * author: VC
 * create: 2022/1/10 9:29
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {
        try {
            //telnet 空格 127.0.0.1 空格 9527
            //创建服务器端
            ServerSocket server = new ServerSocket(9527);
            System.out.println("服务器启动成功,监听端口:" + server.getLocalPort());
            //等待客户端连接
            while (true) {
                Socket client = server.accept();//阻塞
                System.out.println("客户端连接:" + client.getRemoteSocketAddress());
                //接收客户端的消息
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(
                                client.getInputStream()
                        )
                );
                //创建输出流
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(
                                client.getOutputStream()
                        )
                );
                while (true) {
                    String str = reader.readLine();//阻塞
                    System.out.println("客户端说:" + str);
                    writer.write(str + " ok");
                    if (str.equalsIgnoreCase("exit")) {
                        //服务器关闭客户端套接字
                        client.close();
                        break;
                    }
                    writer.newLine();
                    writer.flush();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
