package com.vc.demo3.server.thread;

import com.vc.demo3.server.context.ServerContext;

import java.io.*;
import java.net.Socket;

/**
 * 处理客户端消息的线程:守护线程
 * author: VC
 * create: 2022/1/10 10:54
 * version: 1.0.0
 */
public class ProcessClientThread extends Thread {
    //当前线程处理的客户端套接字对象
    private Socket client;

    public ProcessClientThread(Socket client) {
        this.client = client;
        //设置守护线程
        setDaemon(true);
    }

    @Override
    public void run() {
        //读取客户端消息
        try {
            //接收客户端的消息
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            client.getInputStream()
                    )
            );
            //读取消息
            while (true) {
                String message = reader.readLine();
                if (message.equalsIgnoreCase("exit")) {
                    //关闭客户端套接字
                    client.close();
                    return;
                }
                //分发给其他客户端
                for (Socket socket : ServerContext.onlineUsers) {
                    //排除发送者
                    if (socket == client) {
                        continue;
                    }
                    //将消息发送给当前遍历的客户端
                    sendMessage(socket, "客户端说[" + client.getRemoteSocketAddress() + "]:" + message);
                }
            }
        } catch (IOException e) {
            System.out.println("客户端已断开:" + client.getRemoteSocketAddress());
        } finally {
            //从集合中移除
            ServerContext.onlineUsers.remove(client);
        }
    }

    private void sendMessage(Socket socket, String message) {
        try {
            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(
                            socket.getOutputStream()
                    )
            );
            out.write(message);
            out.newLine();
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
