package com.vc.demo3.client;

import com.vc.demo3.client.socket.ChatClient;

import java.io.IOException;

/**
 * author: VC
 * create: 2022/1/10 11:03
 * version: 1.0.0
 */
public class ClientMain {
    public static void main(String[] args) {
        try {
            new ChatClient().begin();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
