package com.vc.demo3.client.thread;

import com.vc.demo3.client.socket.ChatClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * 处理服务器发送来的聊天消息线程
 * author: VC
 * create: 2022/1/10 13:54
 * version: 1.0.0
 */
public class ProcessServerThread extends Thread {
    private ChatClient client;

    public ProcessServerThread(ChatClient client) {
        this.client = client;
        setDaemon(true);
    }

    @Override
    public void run() {
        try {
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            client.getInputStream()
                    )
            );
            //读取服务器消息
            while (true) {
                String msg = reader.readLine();
                System.out.println(msg);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
