package com.vc.demo3.server.socket;

import com.vc.demo3.server.context.ServerContext;
import com.vc.demo3.server.thread.ProcessClientThread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * 聊天服务器
 * author: VC
 * create: 2022/1/10 10:50
 * version: 1.0.0
 */
public class ChatServer extends ServerSocket {
    public ChatServer() throws IOException {
        super(ServerContext.PORT);
    }

    /**
     * 启动服务器
     */
    public void begin() {
        while (true) {
            try {
                //监听客户端连接
                Socket client = accept();
                //加入到集合中
                ServerContext.onlineUsers.add(client);
                System.out.println("客户端已连接:" + client.getRemoteSocketAddress());
                //开启线程处理客户端消息
                new ProcessClientThread(client).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
