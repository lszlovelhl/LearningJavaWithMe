package com.vc.demo3.client.socket;

import com.vc.demo3.client.thread.ProcessServerThread;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * 聊天客户端
 * author: VC
 * create: 2022/1/10 10:50
 * version: 1.0.0
 */
public class ChatClient extends Socket {
    public ChatClient() throws IOException {
        super("127.0.0.1", 9527);
    }

    public void begin() {
        //创建子线程读取服务器消息
        new ProcessServerThread(this).start();

        sendMessage();
    }

    private void sendMessage() {
        try {
            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(
                            this.getOutputStream()
                    )
            );
            //向服务器发送消息
            Scanner sc = new Scanner(System.in);
            while (true) {
                System.out.println("请输入(输入exit退出):");
                String message = sc.nextLine();
                out.write(message);
                out.newLine();
                out.flush();
                if (message.equalsIgnoreCase("exit")) {
                    close();
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
