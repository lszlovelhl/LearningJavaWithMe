package com.vc.demo3.server.context;

import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * 服务器上下文
 * author: VC
 * create: 2022/1/10 14:03
 * version: 1.0.0
 */
public class ServerContext {
    public static final int PORT = 9527;
    //在线用户集合
    public static List<Socket> onlineUsers = new ArrayList<>();
}
