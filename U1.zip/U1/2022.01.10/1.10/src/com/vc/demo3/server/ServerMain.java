package com.vc.demo3.server;

import com.vc.demo3.client.socket.ChatClient;
import com.vc.demo3.server.socket.ChatServer;

import java.io.IOException;

/**
 * author: VC
 * create: 2022/1/10 10:51
 * version: 1.0.0
 */
public class ServerMain {
    public static void main(String[] args) {
        try {
            new ChatServer().begin();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
