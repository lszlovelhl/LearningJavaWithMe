package com.vc.demo4.client.socket;

import com.vc.demo4.common.MessageType;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * author: VC
 * create: 2022/1/10 15:36
 * version: 1.0.0
 */
public class ChatClient extends Socket {
    private static ChatClient instance;

    public static ChatClient getInstance() {
        if (instance == null) {
            try {
                instance = new ChatClient();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return instance;
    }

    private ChatClient() throws IOException {
        super("127.0.0.1", 9527);
    }

    /**
     * 发送登录请求(同步)
     *
     * @param name 用户名
     * @param pwd  密码
     * @return 登录结果:-1 通讯失败 ,0 用户名不存在, 1 密码错误, 2 登录成功
     */
    public int sendLogin(String name, String pwd) {
        try {
            DataOutputStream out = new DataOutputStream(
                    this.getOutputStream()
            );
            DataInputStream in = new DataInputStream(
                    this.getInputStream()
            );
            //写出消息头
            out.writeByte(MessageType.LOGIN);
            //写消息正文
            out.writeUTF(name);
            out.writeUTF(pwd);
            //读取服务器响应
            return in.readByte();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }
}
