package com.vc.demo4.server.context;

import com.vc.demo4.common.model.User;

import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * author: VC
 * create: 2022/1/10 15:14
 * version: 1.0.0
 */
public class ServerContext {
    /**
     * 已注册用户集合
     */
    public static Map<String, User> users = new HashMap<>();

    static{
        users.put("jack", new User("jack", "123"));
        users.put("rose", new User("rose", "123"));
    }

    public static final int PORT = 9527;
    /**
     * 服务器是否运行中
     */
    public static boolean isRunning = true;
    /**
     * 在线用户集合
     */
    public static List<Socket> onlineUsers = new ArrayList<>();
}
