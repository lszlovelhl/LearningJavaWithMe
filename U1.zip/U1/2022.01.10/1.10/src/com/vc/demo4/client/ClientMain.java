package com.vc.demo4.client;

import com.vc.demo4.client.view.Menu;

/**
 * author: VC
 * create: 2022/1/10 15:14
 * version: 1.0.0
 */
public class ClientMain {
    public static void main(String[] args) {
        new Menu().show();
    }
}
