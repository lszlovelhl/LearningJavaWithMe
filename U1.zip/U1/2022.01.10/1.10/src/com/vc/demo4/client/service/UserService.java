package com.vc.demo4.client.service;

/**
 * author: VC
 * create: 2022/1/10 15:42
 * version: 1.0.0
 */
public interface UserService {
    int login(String name, String pwd);
}
