package com.vc.demo4.client.view;

import com.vc.demo4.client.service.UserService;
import com.vc.demo4.client.service.impl.UserServiceImpl;
import com.vc.demo4.client.util.ScannerUtils;

/**
 * author: VC
 * create: 2022/1/10 15:38
 * version: 1.0.0
 */
public class Menu {
    private UserService userService = new UserServiceImpl();

    public void show() {
        System.out.println("1.登录");
        System.out.println("2.注册");
        System.out.println("0.退出");
        int choice = ScannerUtils.getInt(0, 2);
        switch (choice) {
            case 1:
                showLogin();
                break;
            case 2:
                showReg();
                show();
                break;
            case 0:
                System.exit(0);
                break;
        }
    }

    private void showReg() {
    }

    private void showLogin() {
        System.out.println("请输入用户名:");
        String name = ScannerUtils.nextLine();
        System.out.println("请输入密码:");
        String pwd = ScannerUtils.nextLine();
        int result = userService.login(name, pwd);
        if (result == 2) {
            System.out.println("登录成功...进入聊天大厅");
            //启动线程读取服务器的分发消息

            while (true) {
                System.out.println("请输入聊天内容(exit退出):");

            }
        } else if (result == 0) {
            System.out.println("用户名不存在");
            show();
        } else if (result == 1) {
            System.out.println("密码错误");
            show();
        }
    }
}
