package com.vc.demo4.client.service.impl;

import com.vc.demo4.client.service.UserService;
import com.vc.demo4.client.socket.ChatClient;

import java.io.IOException;

/**
 * author: VC
 * create: 2022/1/10 15:43
 * version: 1.0.0
 */
public class UserServiceImpl implements UserService {

    @Override
    public int login(String name, String pwd) {
        //发送消息
        return ChatClient.getInstance().sendLogin(name, pwd);
    }
}
