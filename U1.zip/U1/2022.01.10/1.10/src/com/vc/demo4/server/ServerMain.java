package com.vc.demo4.server;

import com.vc.demo4.server.socket.ChatServer;

import java.io.IOException;

/**
 * author: VC
 * create: 2022/1/10 15:13
 * version: 1.0.0
 */
public class ServerMain {
    public static void main(String[] args) {
        try {
            new ChatServer().begin();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
