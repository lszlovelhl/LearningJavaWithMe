package com.vc.demo4.common;

/**
 * 消息类型
 * author: VC
 * create: 2022/1/10 15:25
 * version: 1.0.0
 */
public interface MessageType {
    /**
     * 登录消息
     * String: 用户名
     * String:密码
     */
    int LOGIN = 1,
    /**
     * 聊天消息
     * String:聊天内容
     */
    CHAT = 2,
    /**
     * 私聊
     * String: 对方用户名
     * String: 私聊内容
     */
    PRIVATE_CHAT = 3,
    /**
     * 注册
     * String: 用户名
     * String:密码
     */
    REG = 4;
}
