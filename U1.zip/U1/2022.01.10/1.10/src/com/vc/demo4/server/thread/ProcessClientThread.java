package com.vc.demo4.server.thread;

import com.vc.demo4.common.MessageType;
import com.vc.demo4.common.model.User;
import com.vc.demo4.server.context.ServerContext;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * author: VC
 * create: 2022/1/10 15:17
 * version: 1.0.0
 */
public class ProcessClientThread extends Thread {
    private Socket client;

    public ProcessClientThread(Socket client) {
        this.client = client;
        setDaemon(true);
    }

    @Override
    public void run() {
        //读取客户端消息
        try {
            DataInputStream din = new DataInputStream(
                    client.getInputStream()
            );
            DataOutputStream out = new DataOutputStream(
                    client.getOutputStream()
            );
            //循环读取
            while (ServerContext.isRunning) {
                //读取一个字节,表示消息头
                int type = din.readByte();
                switch (type) {
                    case MessageType.LOGIN://登录
                        doLogin(din, out);
                        break;
                    case MessageType.REG://注册的
                        doReg(din, out);
                        break;
                    case MessageType.CHAT://聊天
                        break;
                }
            }
        } catch (IOException e) {
            System.out.println("客户端[" + client.getRemoteSocketAddress() + "]已断开");
        }
    }

    private void doReg(DataInputStream din, DataOutputStream out) {
    }

    private void doLogin(DataInputStream din, DataOutputStream out) throws IOException {
        String name = din.readUTF();
        String pwd = din.readUTF();
        //判断是否能登录
        User user = ServerContext.users.get(name);
        int result;
        if (user == null) {
            //用户名不存在
            result = 0;
        } else {
            //用户存在,验证密码
            if (user.getPwd().equals(pwd)) {
                //密码正确,可以登录
                result = 2;
            } else {
                //密码错误
                result = 1;
            }
        }
        //向客户端写出结果
        out.writeByte(result);
    }
}
