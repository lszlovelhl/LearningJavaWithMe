package com.vc.demo4.server.socket;

import com.vc.demo4.server.context.ServerContext;
import com.vc.demo4.server.thread.ProcessClientThread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * author: VC
 * create: 2022/1/10 15:14
 * version: 1.0.0
 */
public class ChatServer extends ServerSocket {
    public ChatServer() throws IOException {
        super(ServerContext.PORT);
    }

    public void begin() {
        while (ServerContext.isRunning) {
            try {
                //监听客户端连接
                Socket client = accept();
                //加入到集合中
                ServerContext.onlineUsers.add(client);
                //线程处理客户端消息
                new ProcessClientThread(client).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
