package HomeWork.StudentSystem.StudentSystem.src.com.vc.view;

import HomeWork.StudentSystem.StudentSystem.src.com.vc.controller.SchoolManager;
import HomeWork.StudentSystem.StudentSystem.src.com.vc.model.Student;
import HomeWork.StudentSystem.StudentSystem.src.com.vc.util.ScannerUtils;
import HomeWork.StudentSystem.StudentSystem.src.com.vc.util.StringUtils;

import java.util.List;
import java.util.Map;

/**
 * author: VC
 * create: 2021/9/10 17:03
 * version: 1.0.0
 */
public class Menu {
    public void showMainMenu() {
        System.out.println("1.教师登录");
        System.out.println("2.学生登录");
        System.out.println("0.退出");
        int choice = ScannerUtils.getInt(0, 2);
        switch (choice) {
            case 0:
                System.out.println("谢谢使用,再见!");
                System.exit(0);
                break;
            case 1:
                showTeacherLogin();
                break;
            case 2:
                showStudentLogin();
                break;
        }
    }

    private void showStudentLogin() {
        System.out.println("======学生登录======");
        System.out.println("请输入用户名:");
        String name = ScannerUtils.nextLine();
        System.out.println("请输入密码:");
        String pwd = ScannerUtils.nextLine();
        if (SchoolManager.getInstance().doStudentLogin(name, pwd)) {
            System.out.println("欢迎你:" + name + " 同学");
            showStudentMenu();
            return;
        }
        System.out.println("用户名或密码错误,请联系老师注册账号或修改密码!");
        showMainMenu();
    }

    private void showStudentMenu() {
        System.out.println("1.修改密码");
        System.out.println("0.返回");
        int choice = ScannerUtils.getInt(0, 1);
        switch (choice) {
            case 0:
                showMainMenu();
                return;
            case 1:
                showChangePwd();
                break;
        }
        showStudentMenu();
    }

    private void showChangePwd() {
        System.out.println("请输入原始密码:");
        String old = ScannerUtils.nextLine();
        System.out.println("请输入新密码:");
        String new1 = ScannerUtils.nextLine();
        System.out.println("请再输入一次新密码:");
        String new2 = ScannerUtils.nextLine();
        if (!SchoolManager.getInstance().doChangeStuPwd(old, new1, new2)) {
            System.out.println("修改失败!请确认原始密码或二次密码是否正确");
        } else {
            System.out.println("修改成功!");
        }
    }

    private void showTeacherLogin() {
        System.out.println("======教师登录======");
        System.out.println("请输入用户名:");
        String name = ScannerUtils.nextLine();
        System.out.println("请输入密码:");
        String pwd = ScannerUtils.nextLine();
//        boolean flag =
        if (SchoolManager.getInstance().doTeacherLogin(name, pwd)) {
            System.out.println("欢迎你:" + name + " 老师");
            showTeacherMenu();
            return;
        }
        System.out.println("用户名或密码错误!");
        showMainMenu();
    }

    private void showTeacherMenu() {
        System.out.println("1.查看所有学生");
        System.out.println("2.添加学生");
        System.out.println("3.修改学生");
        System.out.println("4.删除学生");
        System.out.println("0.返回");
        int choice = ScannerUtils.getInt(0, 4);
        switch (choice) {
            case 0:
                showMainMenu();
                return;
            case 1:
                showStudents();
                break;
            case 2:
                showAddStudent();
                break;
            case 3:
                showModifyStudent();
                break;
            case 4:
                showDeleteStudent();
                break;
        }
        showTeacherMenu();
    }

    private void showDeleteStudent() {
        System.out.println("请输入要删除的学生编号:");
        int id = ScannerUtils.getInt(1000);
        Student student = SchoolManager.getInstance().getStudentById(id);
        if (student == null) {
            System.out.println("学号不存在!");
            return;
        }
        System.out.println("ID\t姓名\t密码\t语文成绩\t数学成绩");
        System.out.println(student);
        System.out.println("确定要删除该学生吗?(y/n)");
        if (ScannerUtils.next().equalsIgnoreCase("y")) {
            SchoolManager.getInstance().doDeleteStudent(id);
            System.out.println("删除成功!");
        }
    }

    private void showModifyStudent() {
        System.out.println("请输入要修改的学生编号:");
        int id = ScannerUtils.getInt(1000);
        Student student = SchoolManager.getInstance().getStudentById(id);
        if (student == null) {
            System.out.println("学号不存在!");
            return;
        }
        do {
            System.out.println("请输入要修改的项目:1.密码 2.语文成绩 3.数学成绩 0.返回");
            int choice = ScannerUtils.getInt(0, 3);
            int score;
            switch (choice) {
                case 0:
                    return;
                case 1:
                    System.out.println("请输入新密码:");
                    String pwd = ScannerUtils.nextLine();
                    SchoolManager.getInstance().doChangeStuPwd(student.getPwd(), pwd, pwd);
                    break;
                case 2:
                    System.out.println("原语文成绩为:" + student.getChineseScore());
                    System.out.println("请输入新语文成绩(0-150):");
                    score = ScannerUtils.getInt(0, 150);
                    student.setChineseScore(score);
                    break;
                case 3:
                    System.out.println("原数学成绩为:" + student.getMathScore());
                    System.out.println("请输入新数学成绩(0-150):");
                    score = ScannerUtils.getInt(0, 150);
                    student.setMathScore(score);
                    break;
            }
            System.out.println("修改成功!");
        } while (true);
    }

    private void showAddStudent() {
        System.out.println("请输入学生姓名:");
        String name = ScannerUtils.nextLine();
        System.out.println("请输入学生密码:");
        String pwd = ScannerUtils.nextLine();
        System.out.println("请输入学生语文成绩(0-150):");
        int chineseScore = ScannerUtils.getInt(0, 150);
        System.out.println("请输入学生数学成绩(0-150):");
        int mathScore = ScannerUtils.getInt(0, 150);
        System.out.println("请输入学生出生日期:");
        String bornDate = ScannerUtils.nextLine();
        SchoolManager.getInstance().doAddStudent(name, pwd, chineseScore, mathScore, bornDate);
        System.out.println("添加成功!");
    }

    private void showStudents() {
        List<Student> studentList = SchoolManager.getInstance().getStudents();
        System.out.println("ID\t姓名\t密码\t语文成绩\t数学成绩\t出生日期");
        for (Student stu : studentList) {
            System.out.println(stu);
        }
        System.out.println("1.按语文成绩排序");
        System.out.println("2.按数学成绩排序");
        System.out.println("0.返回");
        int choice = ScannerUtils.getInt(0, 2);
        switch (choice) {
            case 0:
                showTeacherMenu();
                return;
            case 1:
            case 2:
                System.out.println("1.升序");
                System.out.println("2.降序");
                int order = ScannerUtils.getInt(1, 2);
                List<Student> students = SchoolManager.getInstance().getOrderedList(choice, order);
                System.out.println("ID\t姓名\t密码\t语文成绩\t数学成绩\t出生日期");
                for (Student stu : students) {
                    System.out.println(stu);
                }
                break;
        }
    }
}
