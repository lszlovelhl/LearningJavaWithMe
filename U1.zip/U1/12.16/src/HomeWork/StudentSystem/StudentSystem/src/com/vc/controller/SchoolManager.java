package HomeWork.StudentSystem.StudentSystem.src.com.vc.controller;

//import com.vc.model.Student;

import HomeWork.StudentSystem.StudentSystem.src.com.vc.model.Student;
import HomeWork.StudentSystem.StudentSystem.src.com.vc.model.Teacher;
//import com.vc.model.Teacher;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class SchoolManager {
    private static SchoolManager instance;

    private SchoolManager() {
    }

    public static SchoolManager getInstance() {
        if (instance == null) {
            instance = new SchoolManager();
        }
        return instance;
    }

    /**
     * @Author:lsz1310225074@iCloud.com
     * @Description: TODO 学生集合
     * @DateTime: 2021/12/16 6:16 下午
     * @Params: students
     * @Return: 学生对象
     */
    private List<Student> students = new ArrayList<>();
    /**
     *@Author:lsz1310225074@iCloud.com
     *@Description: TODO 老师集合
     *@DateTime: 2021/12/16 6:19 下午
     *@Params: teachers
     *@Return: 教师对象
     */
    private Map<String, Teacher> teachers = new HashMap<>();

    private String tchteatdata = "";
    {
        //教师
        Teacher teacher1 = new Teacher("jake", "123");
        Teacher teacher2 = new Teacher("rose", "234");
        Teacher teacher3 = new Teacher("steve", "345");
        Teacher teacher4 = new Teacher("tim", "456");
        teachers.put(teacher1.getName(), teacher1);
        teachers.put(teacher2.getName(), teacher2);
        teachers.put(teacher3.getName(), teacher3);
        teachers.put(teacher4.getName(), teacher4);
    }

    private String stutestdata = "";
    {
        //学生
        Student student1 = new Student("123", "123", 123, 123, new Date());
        Student student2 = new Student("134", "134", 134, 134, new Date());
        Student student3 = new Student("145", "145", 145, 145, new Date());
        Student student4 = new Student("156", "156", 156, 156, new Date());
        students.add(student1);
        students.add(student2);
        students.add(student3);
        students.add(student4);
    }

    public boolean doStudentLogin(String name, String pwd) {
        stutestdata = "";
        if (students.size() == 0) {
            return false;
        }
        for (Student student : students) {
            if (student.getName().equals(name) && student.getPwd().equals(pwd)) {
                stutestdata = student.getName();
                System.out.println("执行学生登录...");
                return true;
            }
        }

        return true;
    }

    public boolean doChangeStuPwd(String old, String new1, String new2) {
        for (Student student : students) {
            if (student.getName().equals(stutestdata)) {
                if (student.getPwd().equals(old) && new1.equals(new2)) {
                    student.setPwd(new2);
                    return true;
                }
                return false;
            }
        }
        System.out.println("执行修改学生密码...");
        return true;
    }

    public boolean doTeacherLogin(String name, String pwd) {
        Set<String> tchname = teachers.keySet();
        if (tchname.size() == 0) {
            return false;
        }
        for (String input : tchname) {
            if (name.equals(input)) {
                if (teachers.get(input).getPwd().equals(pwd)) {
                    return true;
                }
            }
        }
//        Set<String> names = teacher.keySet();
//        Collection<Teacher> passwds = teacher.values();
//        Set<String> passwd = (Set<String>) teacher.get(names);


        System.out.println("执行老师登录...");
        return true;
//        }while (true);
    }

    public List<Student> getStudents() {
        System.out.println("获取所有学生...");
        return students;
    }

    public List<Student> getOrderedList(int subject, int order) {
        System.out.println("获取排序后的学生列表...");

        List<Student> stuList = new ArrayList<>(students);
        //TODO 使用比较器排序


        return stuList;
    }

    public boolean doAddStudent(String name, String pwd,
                                int chineseScore, int mathScore, String bornDate) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date parse = simpleDateFormat.parse(bornDate);
            Student student = new Student(name, pwd, chineseScore, mathScore, parse);
            students.add(student);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
        System.out.println("执行添加学生...");
        return false;
    }

    public Student getStudentById(int id) {
        stutestdata = "";
        for (Student student : students) {
            if (id == student.getId()) {
                stutestdata = student.getName();
                return student;
            }
        }
        System.out.println("根据ID获取学生...");
        return null;
    }

    public void doDeleteStudent(int id) {
        System.out.println("执行删除学生...");
    }
}