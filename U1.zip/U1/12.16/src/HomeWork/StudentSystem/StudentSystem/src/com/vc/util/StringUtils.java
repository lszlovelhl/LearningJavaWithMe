package HomeWork.StudentSystem.StudentSystem.src.com.vc.util;

/**
 * author: VC
 * create: 2021/9/10 17:26
 * version: 1.0.0
 */
public class StringUtils {
    public static String mask(String content) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < content.length(); i++) {
            sb.append("*");
        }
        return sb.toString();
    }
}
