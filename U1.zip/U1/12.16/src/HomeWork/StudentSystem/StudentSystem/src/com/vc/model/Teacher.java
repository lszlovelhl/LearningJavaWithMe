package HomeWork.StudentSystem.StudentSystem.src.com.vc.model;

/**
 * author: VC
 * create: 2021/9/10 16:58
 * version: 1.0.0
 */
public class Teacher extends Person {
    private static int globalID = 1;

    public Teacher(String name, String pwd) {
        super(globalID++, name, pwd);
        this.name = name;
        this.pwd = pwd;
    }

    public static int getGlobalID() {
        return globalID;
    }

    public static void setGlobalID(int globalID) {
        Teacher.globalID = globalID;
    }


}
