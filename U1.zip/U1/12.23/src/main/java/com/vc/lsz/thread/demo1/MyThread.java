package com.vc.lsz.thread.demo1;

/**
 * @ClassName MyThread
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 4:39 下午
 * @Version 1.0
 */
public class MyThread extends Thread{
    @Override
    public void run() {

        Thread name = Thread.currentThread();
        for (int i = 0; i < 20; i++) {
            try {
                Thread.sleep(750);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("来自进程" + name + "i=" + i);
        }

    }
}
