package com.vc.lsz.thread.homework.homework1;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 6:21 下午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        myThread.start();

        myThread.setPriority(Thread.MIN_PRIORITY);

        for (int i = 1; i <= 50; i++) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("普通号" + i + "号病人正在看病");
        }
    }
}
