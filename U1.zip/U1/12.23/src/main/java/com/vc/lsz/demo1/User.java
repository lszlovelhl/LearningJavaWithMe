package com.vc.lsz.demo1;

/**
 * @ClassName User
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 3:57 下午
 * @Version 1.0
 */
public class User {
    private int id;
    private String name;
    private int pwd;

    public User(int id, String name, int pwd) {
        this.id = id;
        this.name = name;
        this.pwd = pwd;
    }

    public User() {
    }
}
