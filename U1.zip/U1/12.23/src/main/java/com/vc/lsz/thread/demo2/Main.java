package com.vc.lsz.thread.demo2;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 4:50 下午
 * @Version 1.0
 */
public class Main {

}
