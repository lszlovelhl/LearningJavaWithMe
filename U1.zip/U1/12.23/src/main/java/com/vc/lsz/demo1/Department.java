package com.vc.lsz.demo1;

/**
 * @ClassName Department
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 3:57 下午
 * @Version 1.0
 */
public class Department {
    private int id;
    private String name;

    public Department(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public Department() {
    }
}
