package com.vc.lsz.demo1;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.util.List;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO 使用DOM4J解析XML
 * @date 2021/12/23 2:22 下午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
//        创建解析对象
        SAXReader reader = new SAXReader();

        try {
//            解析XML
            Document document = reader.read(Main.class.getResourceAsStream("/users1.xml"));
//            获取根结点
            Element root = document.getRootElement();
//            获取user节点
            List<Element> users = root.elements("user");
//            遍历user节点获取属性
            for (Element user : users){
//                获取属性
                int id = Integer.parseInt(user.attributeValue("id"));
                String name = user.attributeValue("name");
                int pwd = Integer.parseInt(user.attributeValue("pwd"));
                System.out.println("User{id=" + id + "," + "name=" + name + "," + "pwd=" + pwd + "}");

//                反射创建对象
//                Class cls = Class.forName(users);
            }




        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
