package com.vc.lsz.thread.homework.homework2;

/**
 * @ClassName TaoRunRun
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 6:54 下午
 * @Version 1.0
 */
public class TaoRunRun extends Thread{
    @Override
    public void run() {

//        Thread name = Thread.currentThread();

        for (int i = 1; i < 10; i++) {
            try {
                Thread.sleep(750);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("桃跑跑抢到第" + i + "张票");
        }
    }
}
