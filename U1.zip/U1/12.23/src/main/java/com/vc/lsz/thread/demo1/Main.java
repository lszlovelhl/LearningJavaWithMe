package com.vc.lsz.thread.demo1;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 4:39 下午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {

        MyThread myThread = new MyThread();
        myThread.start();

        Thread name = Thread.currentThread();
        for (int i = 0; i < 20; i++) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("来自进程" + name + "i=" + i);
        }
    }
}
