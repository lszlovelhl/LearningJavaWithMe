package com.vc.lsz.demo1;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ClassName Main1
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 3:23 下午
 * @Version 1.0
 */
public class Main1 {
    public static void main(String[] args) {
        //        创建解析对象
        SAXReader reader = new SAXReader();

        try {
//            解析XML
            Document document = reader.read(Main1.class.getResourceAsStream("/users2.xml"));
//            获取根结点
            Element root = document.getRootElement();
//            获取deparment节点
            Map<Integer,Department> departments = new HashMap<Integer,Department>();
            List<Element> depart = root.elements("department");
            for (Element depa : depart) {
                int id = Integer.parseInt(depa.attributeValue("id"));
                String name = depa.attributeValue("name");

                Department department = new Department(id,name);
                departments.put(id,department);

            }
//            departments =

//            获取user节点
            List<Element> users = root.elements("user");
//            遍历user节点获取属性
            for (Element user : users){
//                获取子节点值
//                int dep = Integer.parseInt(user.attributeValue("dep"));
//                int dep = Integer.parseInt(user.elementText("id"));
                int id = Integer.parseInt(user.attributeValue("id"));
                String name = user.attributeValue("name");
                int pwd = Integer.parseInt(user.attributeValue("pwd"));
                System.out.println("User{id=" + id + ",name=" + name + ",pwd=" + pwd + "}");

//                反射创建对象
//                Class cls = Class.forName(users);
            }




        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static Object dept(String depId){
        switch (depId){
            case "1":
                return "研发部";
            case "2":
                return "市场部";
        }
        return depId;
    }
}
