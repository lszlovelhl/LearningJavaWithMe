package com.vc.lsz.thread.homework.homework2;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2021/12/23 6:54 下午
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {

        TaoRunRun taoRunRun = new TaoRunRun();
        ZhangTT zhangTT = new ZhangTT();
        YellowBoll yellowBoll = new YellowBoll();
        taoRunRun.start();
        zhangTT.start();
        yellowBoll.start();

        int sum = 10;


        for (int i = 1; i <= 10; i++) {

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


        }

    }
}
