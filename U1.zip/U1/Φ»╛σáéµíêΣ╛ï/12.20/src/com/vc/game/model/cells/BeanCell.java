package com.vc.game.model.cells;

/**
 * 豆子
 * author: VC
 * create: 2021/12/20 9:29
 * version: 1.0.0
 */
public class BeanCell extends Cell {
    public BeanCell(int x, int y) {
        super(x, y, "☆");
    }
}
