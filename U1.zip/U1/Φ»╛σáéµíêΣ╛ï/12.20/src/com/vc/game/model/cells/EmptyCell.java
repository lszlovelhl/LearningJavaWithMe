package com.vc.game.model.cells;

/**
 * 空格子
 * author: VC
 * create: 2021/12/20 9:29
 * version: 1.0.0
 */
public class EmptyCell extends Cell {

    public EmptyCell(int x, int y) {
        super(x, y, "□");
    }
}
