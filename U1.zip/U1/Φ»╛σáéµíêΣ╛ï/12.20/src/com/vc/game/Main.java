package com.vc.game;

import com.vc.game.model.Map;
import com.vc.game.model.cells.BeanCell;
import com.vc.game.model.enums.CellType;

/**
 * author: VC
 * create: 2021/12/20 9:05
 * version: 1.0.0
 */
public class Main {
    public static void main(String[] args) {
        Map map = new Map();
        //初始化地图
        map.initMap();
        //添加地图元素
        map.addElement(10, CellType.CELL_BEAN);

        map.printMap();
    }

}
