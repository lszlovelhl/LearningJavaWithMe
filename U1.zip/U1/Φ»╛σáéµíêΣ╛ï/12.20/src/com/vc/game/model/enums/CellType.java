package com.vc.game.model.enums;

/**
 * author: VC
 * create: 2021/12/20 10:06
 * version: 1.0.0
 */
public enum CellType {
    /**
     * 空白格子
     */
    CELL_EMPTY,
    /**
     * 豆子
     */
    CELL_BEAN,
    /**
     * 炸弹
     */
    CELL_BOMB,
    /**
     * 玩家
     */
    CELL_PLAYER;
}
