package com.vc.game.model.cells;

/**
 * 格子
 * author: VC
 * create: 2021/12/20 9:29
 * version: 1.0.0
 */
public class Cell {
    //坐标
    protected int x, y;
    //格子的样子
    protected String icon;

    @Override
    public String toString() {
        return icon + " ";
    }

    public Cell(int x, int y, String icon) {
        this.x = x;
        this.y = y;
        this.icon = icon;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}
