package com.vc.game.model;

import com.vc.game.model.cells.BeanCell;
import com.vc.game.model.cells.Cell;
import com.vc.game.model.cells.EmptyCell;
import com.vc.game.model.enums.CellType;

import java.beans.Beans;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 地图类
 * author: VC
 * create: 2021/12/20 9:29
 * version: 1.0.0
 */
public class Map {
    private static final int WIDTH = 5, HEIGHT = 7;
    //格子集合
    private Cell[][] cells;

    /**
     * 初始化地图
     */
    public void initMap() {
        cells = new Cell[HEIGHT][WIDTH];
        //将空白格子填充到地图中
        //外层循环控制行数
        for (int y = 0; y < cells.length; y++) {
            //内层循环控制列数
            for (int x = 0; x < cells[y].length; x++) {
                //创建空白格子
                cells[y][x] = new EmptyCell(x, y);
            }
        }
    }


    public void addElement(int count, CellType type) {
        //获取空白格子集合
        List<Cell> empties = getEmptyCells();
        //以最小值为循环次数
        count = Math.min(count, empties.size());
        for (int i = 0; i < count; i++) {
            //获取空白格子
            Cell cell = empties.get(i);
            int x = cell.getX();
            int y = cell.getY();
            //判断创建棋子的类型
            switch (type) {
                case CELL_EMPTY:
                    cell = new EmptyCell(x, y);
                    break;
                case CELL_BEAN:
                    cell = new BeanCell(x, y);
                    break;
            }
            //放入数组中
            cells[y][x] = cell;
        }
    }

    /**
     * 获取地图中的空白格子
     *
     * @return
     */
    private List<Cell> getEmptyCells() {
        //创建空集合
        List<Cell> list = new ArrayList<>();
        for (int y = 0; y < cells.length; y++) {
            for (int x = 0; x < cells[y].length; x++) {
                //判断是否是空白格子 is a
                if (cells[y][x] instanceof EmptyCell) {
                    //加入到集合
                    list.add(cells[y][x]);
                }
            }
        }
        //打乱顺序
        Collections.shuffle(list);
        return list;
    }


    /**
     * 打印地图
     */
    public void printMap() {
        for (int y = 0; y < cells.length; y++) {
            for (int x = 0; x < cells[y].length; x++) {
                System.out.print(cells[y][x]);
            }
            System.out.println();
        }
    }
}
