package com.vc.game.controller;

import com.vc.game.model.Map;
import com.vc.game.model.enums.CellType;

/**
 * 游戏控制器
 * author: VC
 * create: 2021/12/20 14:15
 * version: 1.0.0
 */
public class GameController {
    public void start(){
        Map map = new Map();
        //初始化地图
        map.initMap();
        //添加地图元素
        map.addElement(10, CellType.CELL_BEAN);
        map.addElement(10, CellType.CELL_SHIT);
        map.addElement(5, CellType.CELL_BOMB);
        //添加地图元素
        map.addTP(1);
        //添加地图元素
        map.addPlayer(3);
        while (true) {
            //打印地图
            map.printMap();
            //让玩家移动
            map.playerMove();
        }
    }
}
