package com.vc.game.model.cells;

/**
 * author: VC
 * create: 2021/12/20 11:09
 * version: 1.0.0
 */
public class PlayerCell extends Cell {
    public PlayerCell(int x, int y,String icon) {
        super(x, y, icon);
    }
}
