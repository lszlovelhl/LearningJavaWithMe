package com.vc.game.context;

/**
 * 程序上下文(静态配置项)
 * author: VC
 * create: 2021/12/20 11:37
 * version: 1.0.0
 */
public class AppContext {
    public static final String[] PLAYER_ICONS =
            {"㊣", "X", "O"};
}
