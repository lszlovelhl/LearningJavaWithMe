package com.vc.game.model.cells;

/**
 * author: VC
 * create: 2021/12/20 11:12
 * version: 1.0.0
 */
public class ShitCell extends Cell {
    public ShitCell(int x, int y) {
        super(x, y, "※");
    }
}
