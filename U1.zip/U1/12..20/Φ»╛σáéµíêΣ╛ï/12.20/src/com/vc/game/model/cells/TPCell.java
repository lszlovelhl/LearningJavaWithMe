package com.vc.game.model.cells;

/**
 * 传送门格子
 * author: VC
 * create: 2021/12/20 11:16
 * version: 1.0.0
 */
public class TPCell extends Cell {
    //传送门的另外一端
    private TPCell another;

    public TPCell getAnother() {
        return another;
    }

    public void setAnother(TPCell another) {
        this.another = another;
    }

    public TPCell(int x, int y) {
        super(x, y, "卍");
    }
}
