package com.vc.game.model.cells;

/**
 * author: VC
 * create: 2021/12/20 11:09
 * version: 1.0.0
 */
public class BombCell extends Cell{
    public BombCell(int x, int y) {
        super(x, y, "¤");
    }
}
