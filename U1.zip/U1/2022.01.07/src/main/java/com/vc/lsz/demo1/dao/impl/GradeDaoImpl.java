package com.vc.lsz.demo1.dao.impl;

import com.vc.lsz.demo1.dao.GradeDao;

/**
 * @ClassName GradeDaoImpl
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/7 1:41 下午
 * @Version 1.0
 */
public class GradeDaoImpl implements GradeDao {
}
