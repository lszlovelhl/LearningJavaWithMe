package com.vc.lsz.demo1.model;

/**
 * @ClassName Subject
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/7 1:35 下午
 * @Version 1.0
 */
public class Subject {
    private int id;
    private String name;
    private int classHour;

    @Override
    public String toString() {
        return "Subject{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", classHour=" + classHour +
                '}';
    }

    public  Subject(){}

    public Subject(int id, String name, int classHour) {
        this.id = id;
        this.name = name;
        this.classHour = classHour;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getClassHour() {
        return classHour;
    }

    public void setClassHour(int classHour) {
        this.classHour = classHour;
    }
}
