package com.vc.lsz.demo1.context;

/**
 * @ClassName AppContext
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/7 1:51 下午
 * @Version 1.0
 */
public class AppContext {
    /**
     * 加载驱动文件
     */
    public static final String DAO_PATH = "/dao.properties";
    /**
     * 驱动名
     */
    public static String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
    /**
     * 连接字符串
     */
    public static String URL = "jdbc:mysql://localhost:3306/myschool";
    /**
     * 数据库用户名和密码
     */
    public static String USER = "root", PWD = "19980624";

}
