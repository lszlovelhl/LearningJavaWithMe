package com.vc.lsz.demo1.service;

import com.vc.lsz.demo1.model.User;

/**
 * @ClassName UserService
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/7 1:42 下午
 * @Version 1.0
 */
public interface UserService {
    boolean addStudent(User stu);
}
