package com.vc.lsz.demo1.dao;

import com.vc.lsz.demo1.model.User;

/**
 * @ClassName UserDao
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/7 1:39 下午
 * @Version 1.0
 */
public interface UserDao {
    int add(User user);
}
