package com.vc.myschool.model;

/**
 * author: VC
 * create: 2022/1/7 10:08
 * version: 1.0.0
 */
public class Grade {
    private int id;
    private String name;

    public Grade(int id) {
        this.id = id;
    }

    public Grade(int id, String s) {
        this.id = id;
        name = s;
    }
}
