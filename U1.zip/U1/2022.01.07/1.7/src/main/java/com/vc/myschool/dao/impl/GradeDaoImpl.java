package com.vc.myschool.dao.impl;

import com.vc.myschool.dao.GradeDao;
import com.vc.myschool.dao.JDBCTemplate;
import com.vc.myschool.model.Grade;

/**
 * author: VC
 * create: 2022/1/7 10:03
 * version: 1.0.0
 */
public class GradeDaoImpl extends JDBCTemplate implements GradeDao {
    @Override
    public int update(Grade grade) {
        return modify(grade);
    }

    @Override
    public int delete(int id) {
//        return update("delete from grade where gradeid=?", id
//        ).count;
        return super.delete(new Grade(id));
    }
}
