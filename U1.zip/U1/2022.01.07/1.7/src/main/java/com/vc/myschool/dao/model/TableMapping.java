package com.vc.myschool.dao.model;

import java.util.HashMap;
import java.util.Map;

/**
 * author: VC
 * create: 2022/1/7 10:30
 * version: 1.0.0
 */
public class TableMapping {
    //类名
    private String className;
    //表名
    private String tableName;
    //属性的映射集合
    /**
     * key:bean节点中property子节点的 name属性值
     */
    private Map<String, ColumnMapping> columns = new HashMap();

    public TableMapping() {
    }

    public TableMapping(String className, String tableName, Map<String, ColumnMapping> columns) {
        this.className = className;
        this.tableName = tableName;
        this.columns = columns;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public Map<String, ColumnMapping> getColumns() {
        return columns;
    }

    public void setColumns(Map<String, ColumnMapping> columns) {
        this.columns = columns;
    }

    public void add(ColumnMapping columnMapping) {
        columns.put(columnMapping.getAttrName(), columnMapping);
    }

    /**
     * 获取主键对象
     * @return
     */
    public ColumnMapping getPK() {
        for (ColumnMapping value : columns.values()) {
            //判断是否是主键
            if (value.isPK()) {
                return value;
            }
        }
        return null;
    }
}
