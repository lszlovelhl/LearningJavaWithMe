package com.vc.myschool.dao;


import com.vc.myschool.context.AppContext;
import com.vc.myschool.dao.file.impl.UserDaoImpl;

import java.util.Properties;

/**
 * author: VC
 * create: 2022/1/7 9:29
 * version: 1.0.0
 */
public class DaoFactory {

    /**
     * 创建接口的实现类
     * @param clz 接口的类型
     * @param <A>
     * @return 实现类对象
     */
    public static <A> A createDao(Class<A> clz) {
        try {
            //读取配置文件
            Properties prop = new Properties();
            //加载配置文件
            prop.load(DaoFactory.class.getResourceAsStream(AppContext.DAO_PATH));
            //读取键值对
            String className = prop.getProperty(clz.getName());
            //1.获取实现类的Class对象
            Class implClass = Class.forName(className);
            //2.创建实例 public 无参构造
            return (A) implClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
