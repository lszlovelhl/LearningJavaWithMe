package com.vc.myschool.dao.impl;

import com.vc.myschool.dao.JDBCTemplate;
import com.vc.myschool.dao.SubjectDao;
import com.vc.myschool.model.Subject;
import jdk.nashorn.internal.scripts.JD;

/**
 * author: VC
 * create: 2022/1/7 10:52
 * version: 1.0.0
 */
public class SubjectDaoImpl extends JDBCTemplate implements SubjectDao {
    @Override
    public int delete(int id) {
        return super.delete(new Subject(id));
    }
}
