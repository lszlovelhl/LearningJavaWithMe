package com.vc.myschool.dao;

import com.vc.myschool.model.Grade;
import com.vc.myschool.model.User;

public interface GradeDao {
    int update(Grade grade);

    int delete(int id);
}
