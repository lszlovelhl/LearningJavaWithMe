package com.vc.myschool.dao;

import com.vc.myschool.context.AppContext;
import com.vc.myschool.dao.model.ColumnMapping;
import com.vc.myschool.dao.model.ResultSetCallback;
import com.vc.myschool.dao.model.TableMapping;
import com.vc.myschool.dao.model.UpdateResult;
import com.vc.myschool.model.User;

import java.lang.reflect.Field;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC帮助类
 * author: VC
 * create: 2021/12/29 15:37
 * version: 1.0.0
 */
public class JDBCTemplate {
    static {
        //加载驱动
        try {
            Class.forName(AppContext.DRIVER_NAME);
        } catch (ClassNotFoundException e) {
            System.out.println("驱动加载失败,程序结束");
            System.exit(0);
        }
    }

    public int modify(Object obj) {
        //获取Class对象
        Class clz = obj.getClass();
        TableMapping mapping = AppContext.mappings.get(clz.getName());
        //获取主键
        ColumnMapping pk = mapping.getPK();
        String sql = "update `" + mapping.getTableName() + "` set ";
        StringBuilder sb = new StringBuilder();
        //保存属性值
        List list = new ArrayList<>();
        //遍历类中的所有字段
        for (ColumnMapping attr : mapping.getColumns().values()) {
            //排除主键
            if (attr.isPK()) {
                continue;
            }
            sb.append("`").append(attr.getFieldName()).append("`=?,");
            //获取该属性的值
            Object value = getValue(obj, attr.getAttrName());
            list.add(value);
        }
        //列名=?,列名=?,
        //去掉最后一个逗号
        sb.deleteCharAt(sb.length() - 1);
        sql += sb.toString();
        sql += " where " + pk.getFieldName() + " = ?";
        //获取主键值
        Object pkValue = getValue(obj, pk.getAttrName());
        //添加到集合中
        list.add(pkValue);
        return update(sql, list.toArray()).count;
    }

    //obj ==> User
    public int delete(Object obj) {
        //映射
        //类名 ==> 表名
        //属性 ==> 主键
        //根据对象获取Class
        Class clz = obj.getClass();
        TableMapping mapping = AppContext.mappings.get(clz.getName());
        //获取主键的字段名
        ColumnMapping columnMapping = mapping.getPK();
        String sql = "delete from " + mapping.getTableName()
                + " where " + columnMapping.getFieldName() + " = ?";
        //获取对象的主键值
        String attrName = columnMapping.getAttrName();
        Object value = getValue(obj, attrName);
        //执行SQL
        return update(sql, value).count;
    }

    /**
     * 根据属性名获取属性值
     *
     * @param obj
     * @param attrName
     * @return
     */
    private Object getValue(Object obj, String attrName) {
        Class clz = obj.getClass();
        Object value = null;
        try {
            //使用反射获取属性值
            Field field = clz.getDeclaredField(attrName);
            //设置访问权限
            field.setAccessible(true);
            //获取字段中的值
            value = field.get(obj);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return value;
    }


    //回调函数
    public Object query(String sql, ResultSetCallback callback, Object... args) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            pst = conn.prepareStatement(sql);
            for (int i = 0; i < args.length; i++) {
                pst.setObject(i + 1, args[i]);
            }
            rs = pst.executeQuery();
            //逻辑
            return callback.processResultSet(rs);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(conn, pst, rs);
        }
        return null;
    }

    /**
     * 通用的增删改
     *
     * @param sql
     * @param args
     * @return
     */
    public UpdateResult update(String sql, Object... args) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        UpdateResult result = new UpdateResult();
        try {
            conn = getConnection();
            pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            //填坑
            for (int i = 0; i < args.length; i++) {
                pst.setObject(i + 1, args[i]);
            }
            //执行
            result.count = pst.executeUpdate();
            //获取自增长编号
            rs = pst.getGeneratedKeys();
            if (rs.next()) {
                //获取编号值
                result.identity = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(conn, pst, rs);
        }
        return result;
    }

    /**
     * 获取连接对象
     *
     * @return
     * @throws SQLException
     */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                AppContext.URL,
                AppContext.USER,
                AppContext.PWD);
    }

    /**
     * 关闭连接
     *
     * @param conn
     * @param st
     * @param rs
     */
    public void close(Connection conn, Statement st, ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        if (st != null) {
            try {
                st.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }

}
