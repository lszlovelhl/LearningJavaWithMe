package com.vc.myschool.dao.file.impl;

import com.vc.myschool.context.AppContext;
import com.vc.myschool.dao.UserDao;
import com.vc.myschool.model.User;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.List;

/**
 * author: VC
 * create: 2022/1/7 9:12
 * version: 1.0.0
 */
public class UserDaoImpl implements UserDao {
    @Override
    public int update(User user) {
        return 0;
    }

    @Override
    public int add(User user) {
        URL url = UserDaoImpl.class.getResource(AppContext.FILE_PATH);
        String path = url.getFile();
        System.out.println(path);
        //追加到文件中
        try (BufferedWriter out = new BufferedWriter(
                new FileWriter(path,true)
        );) {
            out.write(user.getId()+"\t");
            out.write(user.getName()+"\t");
            out.write(user.getPwd());
            out.newLine();
            return 1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public User findById(int id) {
        return null;
    }

    @Override
    public List<User> findAll() {
        return null;
    }
}
