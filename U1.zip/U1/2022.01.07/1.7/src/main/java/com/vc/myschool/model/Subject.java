package com.vc.myschool.model;

/**
 * author: VC
 * create: 2022/1/7 10:51
 * version: 1.0.0
 */
public class Subject {
    private int id;
    private String name;
    private int classHour;

    public Subject(int id) {
        this.id = id;
    }
}
