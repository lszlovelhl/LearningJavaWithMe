package com.vc.myschool.service;

import com.vc.myschool.model.User;

public interface UserService {
    boolean addStudent(User stu);
}
