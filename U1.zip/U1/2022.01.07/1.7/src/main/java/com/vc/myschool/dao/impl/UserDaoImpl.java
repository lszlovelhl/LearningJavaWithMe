package com.vc.myschool.dao.impl;

import com.vc.myschool.dao.JDBCTemplate;
import com.vc.myschool.dao.UserDao;
import com.vc.myschool.model.Grade;
import com.vc.myschool.model.User;

import java.util.List;

/**
 * author: VC
 * create: 2022/1/7 9:05
 * version: 1.0.0
 */
public class UserDaoImpl extends JDBCTemplate implements UserDao {
    @Override
    public int add(User user) {
        return update("insert into student(studentname,loginpwd) values(?,?)", user.getName(), user.getPwd()).identity;
    }

    @Override
    public int delete(int id) {
//        return update("delete from student where studentno=?", id
//        ).count;
        return super.delete(new User(id));
    }

    public int update(User user){
        return modify(user);
    }

    @Override
    public User findById(int id) {
        return null;
    }

    @Override
    public List<User> findAll() {
        return null;
    }
}
