package com.vc.myschool.service.impl;

import com.vc.myschool.dao.DaoFactory;
import com.vc.myschool.dao.UserDao;
import com.vc.myschool.dao.file.impl.UserDaoImpl;
import com.vc.myschool.model.User;
import com.vc.myschool.service.UserService;

/**
 * author: VC
 * create: 2022/1/7 9:07
 * version: 1.0.0
 */
public class UserServiceImpl implements UserService {
    private UserDao userDao =  DaoFactory.createDao(UserDao.class);
    @Override
    public boolean addStudent(User user) {
        return userDao.add(user) > 0;
    }
}
