package com.vc.myschool.dao;

import com.vc.myschool.model.User;

import java.util.List;

public interface UserDao {
    int update(User user);

    /**
     * 返回自增长编号
     *
     * @return
     */
    int add(User user);

    int delete(int id);

    User findById(int id);


    List<User> findAll();


}
