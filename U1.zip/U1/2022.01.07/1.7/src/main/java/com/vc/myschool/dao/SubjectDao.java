package com.vc.myschool.dao;

/**
 * author: VC
 * create: 2022/1/7 10:52
 * version: 1.0.0
 */
public interface SubjectDao {
    int delete(int id);
}
