package com.vc.myschool.context;

import com.vc.myschool.dao.model.ColumnMapping;
import com.vc.myschool.dao.model.TableMapping;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * 程序上下文
 * author: VC
 * create: 2021/12/30 9:42
 * version: 1.0.0
 */
public class AppContext {
    public static final String DAO_PATH = "/dao.properties";
    private static final String BEANS_PATH = "/beans.xml";
    //驱动名
    public static String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
    //连接字符串
    public static String URL = "jdbc:mysql://localhost:3306/myschool";
    //数据库用户名和密码
    public static String USER = "root", PWD = "root";

    public static final String FILE_PATH = "/stu.txt";

    /**
     * 每页几条
     */
    public static int pageCount = 3;

    /**
     * 加载配置文件
     */
    public static void init() throws Exception {
        //加载类与表的映射关系
        loadMappingByDom();

        //判断是否有配置文件
        java.net.URL url = AppContext.class.getResource("/jdbc.properties");
        if (url == null) {
            return;
        }
        //创建属性文件对象
        Properties prop = new Properties();
        //加载
        prop.load(AppContext.class.getResourceAsStream("/jdbc.properties"));
        //获取属性文件中的内容
        DRIVER_NAME = prop.getProperty("DRIVER_NAME", DRIVER_NAME);
        URL = prop.getProperty("URL", URL);
        USER = prop.getProperty("USER", USER);
        PWD = prop.getProperty("PWD", PWD);
    }

    /**
     * key:全类名
     */
    public static Map<String,TableMapping> mappings = new HashMap();

    private static void loadMappingByDom() throws Exception {
        SAXReader reader = new SAXReader();
        //解析文件
        Document doc = reader.read(AppContext.class.getResourceAsStream(BEANS_PATH));
        //获取根节点
        Element root = doc.getRootElement();
        //获取bean节点集合
        List<Element> beans = root.elements("bean");
        //遍历节点集合
        for (Element bean : beans) {
            //创建TableMapping
            TableMapping tableMapping = new TableMapping();
            //读取class和table属性
            String className = bean.attributeValue("class");
            String table = bean.attributeValue("table");
            tableMapping.setClassName(className);
            tableMapping.setTableName(table);
            //获取bean节点中的property节点
            List<Element> properties = bean.elements("property");
            //遍历property节点
            for (Element property : properties) {
                //创建ColumnMapping
                ColumnMapping columnMapping = new ColumnMapping();
                //获取name属性值(类的属性名)
                String name = property.attributeValue("name");
                //获取property节点中的值(表中的字段名)
                String fieldName = property.getText();
                columnMapping.setAttrName(name);
                columnMapping.setFieldName(fieldName);
                //判断是否PK属性
                String pk = property.attributeValue("pk");
                if (pk != null) {
                    //是主键
                    columnMapping.setPK(true);
                }
                //加入到集合中
                tableMapping.add(columnMapping);
            }
            mappings.put(tableMapping.getClassName(),tableMapping);
        }
    }
}
