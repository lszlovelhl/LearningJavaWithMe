package com.vc.myschool.dao.model;

/**
 * 属性与字段的映射类
 * author: VC
 * create: 2022/1/7 10:26
 * version: 1.0.0
 */
public class ColumnMapping {
    //类中的属性名
    private String attrName;
    //表中的字段名
    private String fieldName;
    //是否是主键
    private boolean isPK;

    public ColumnMapping() {
    }

    public ColumnMapping(String attrName, String fieldName, boolean isPK) {
        this.attrName = attrName;
        this.fieldName = fieldName;
        this.isPK = isPK;
    }

    public String getAttrName() {
        return attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public boolean isPK() {
        return isPK;
    }

    public void setPK(boolean PK) {
        isPK = PK;
    }
}
