package com.vc.myschool;

import com.vc.myschool.context.AppContext;
import com.vc.myschool.dao.DaoFactory;
import com.vc.myschool.dao.GradeDao;
import com.vc.myschool.dao.SubjectDao;
import com.vc.myschool.dao.UserDao;
import com.vc.myschool.dao.file.impl.UserDaoImpl;
import com.vc.myschool.model.Grade;
import com.vc.myschool.model.User;
import com.vc.myschool.service.UserService;
import com.vc.myschool.service.impl.UserServiceImpl;

import java.io.File;
import java.net.URL;

/**
 * author: VC
 * create: 2022/1/7 9:07
 * version: 1.0.0
 */
public class Main {
    static UserService us = new UserServiceImpl();

    public static void main(String[] args) {
       // createInstance();

      //  UserDao userDao = DaoFactory.createUserDao();

//        String name = "rose";
//        String pwd = "123";
//        boolean flag = us.addStudent(new User(1001, name, pwd));
//        System.out.println(flag);

        try {
            AppContext.init();

            UserDao userDao = DaoFactory.createDao(UserDao.class);
            //int ret = userDao.delete(30021);
            int ret = userDao.update(new User(30022,"allen","321"));
            System.out.println(ret);

            GradeDao gradeDao = DaoFactory.createDao(GradeDao.class);
            //ret = gradeDao.delete(8);
            ret = gradeDao.update(new Grade(7,"1年级"));
            System.out.println(ret);

//            SubjectDao subjectDao = DaoFactory.createDao(SubjectDao.class);
//            ret = subjectDao.delete(8);
//            System.out.println(ret);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 演示反射创建对象
     */
    private static void createInstance() {
        try {
            //1.获取Class对象
            Class clz = Class.forName("com.vc.myschool.dao.impl.UserDaoImpl");
            //2.创建实例 public 无参构造
           Object obj = clz.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
