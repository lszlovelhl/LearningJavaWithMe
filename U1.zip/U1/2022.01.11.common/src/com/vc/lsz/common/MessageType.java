package com.vc.lsz.common;

/**
 * @ClassName MessageType
 * @auther lsz1310225074@iCloud.com
 * @Description TODO 消息类型
 * @date 2022/1/10 6:48 下午
 * @Version 1.0
 */
public interface MessageType {
    /**
     * 登录消息
     */
    int LOGIN = 1,
    /**
     * 公聊消息
     */
    CHAT = 2,
    /**
     * 私聊消息
     */
    PRIVATE_CHAT = 3,
    /**
     * 注册消息
     */
    SIGN_IN = 4;
}
