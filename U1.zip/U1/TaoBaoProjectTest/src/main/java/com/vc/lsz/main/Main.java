package com.vc.lsz.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.Random;

/**
 * @ClassName Main
 * @auther lsz1310225074@iCloud.com
 * @Description TODO
 * @date 2022/1/29 13:34
 * @Version 1.0
 */
public class Main {
    public static void main(String[] args) {
        System.setProperty(
                "webdriver.chrome.driver", "/Users/longshizhuo/IdeaProjects/U1/TaoBaoProjectTest/src/main/resources/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.get(
                "https://login.taobao.com/member/login.jhtml?spm=a2e0b.20350158.1997563269.1.174c468akzqsab&f=top&redirectURL=https%3A%2F%2Fuland.taobao.com%2Fsem%2Ftbsearch%3Frefpid%3Dmm_26632258_3504122_32538762%26keyword%3D%25E6%25B7%2598%25E5%25AE%259D%25E7%25BD%2591%25E5%25BA%2597%2520%25E8%25BF%2590%25E8%2590%25A5%26clk1%3D7c9579b4d8fd5782cf6e3be7c5e7a9e2%26upsId%3D7c9579b4d8fd5782cf6e3be7c5e7a9e2&pid=mm_26632258_3504122_32538762&union_lens=recoveryid%3A201_33.7.215.167_8303648_1643436400338%3Bprepvid%3A201_33.7.215.167_8303648_1643436400338&clk1=7c9579b4d8fd5782cf6e3be7c5e7a9e2"
//                "https://login.taobao.com/member/login.jhtml"
        );
        String username = "18700664837";
        String password = "lhl19980624..";
        WebElement usernameElement = driver.findElement(By.id("fm-login-id"));
        usernameElement.click();
        Random rand = new Random();
        try {
            for (int i = 0; i < username.length(); i++) {
                Thread.sleep(rand.nextInt(1000));
                usernameElement.sendKeys("" + username.charAt(i));
            }
            WebElement passwordElement = driver.findElement(By.id("fm-login-password"));
            passwordElement.click();
            Thread.sleep(rand.nextInt(3000));
            for (int i = 0; i < password.length(); i++) {
                Thread.sleep(rand.nextInt(1000));
                passwordElement.sendKeys("" + password.charAt(i));
            }
            Actions action = new Actions(driver);
//            WebElement moveButton = driver.findElement(By.id("nc_1_n1z"));
            WebElement moveButton = driver.findElement(By.className("fm-field baxia-container-wrapper"));
            action.moveToElement(moveButton).clickAndHold(moveButton);
// action.moveByOffset(306, 0).perform();
            action.dragAndDropBy(moveButton,305, 0).perform();
            action.release();
//            action.clickAndHold(moveButton);
//            action.moveByOffset(300, 0).perform();
//            action.release();

        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            Thread.sleep(300000);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }
        driver.quit();
    }
}
