package learntest.com.vc.lsz;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/10 11:10 上午
 */
public class EatBatMan {
    public static void main(String[] args) {
        int width = 7;
        int height = 5;
        int score = 0;
        int count = 0;
        String[][] map = new String[width][height];//String[行][列]
        String[][] tsDoor = new String[width][height];

//        行
        for (int i = 0; i < map.length; i++) {
//            列
            for (int j = 0; j < map[i].length; j++) {
                map[i][j] = "♦️";
//                初始化地图
//        生成炸弹💣便便💩豆子🌀的位置并控制概率
                double gailv = Math.random();
                for (int k = 0; k < map.length; k++) {
                    for (int l = 0; l < map[k].length; l++) {
                        if (gailv < 0.1) {
                            map[i][j] = "⚡️";
                            break;
                        } else if (gailv < 0.2) {
                            map[i][j] = "💣";
                            break;
                        } else if (gailv < 0.5) {
                            map[i][j] = "💩";
                            break;
                        } else if (gailv < 0.8) {
                            map[i][j] = "🌀";
                            count++;
                            break;
                        } else {
                            map[i][j] = "♦️";
                        }
                    }
                }
            }
        }

//        随机生成玩家位置
        int playerX = (int) (Math.random() * width);
        int playerY = (int) (Math.random() * height);
        map[playerX][playerY] = "🐯";

//        随机生成传送门位置

        int doorX1 = (int) (Math.random() * width);
        int doorY1 = (int) (Math.random() * height);
        int doorX2 = (int) (Math.random() * width);
        int doorY2 = (int) (Math.random() * height);
        tsDoor[doorX1][doorY1] = "🕳️";
        tsDoor[doorX2][doorY2] = "🕳️";

//        Terminal运行时清屏

//        try {
//            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        System.out.println("欢迎来到吃豆人的世界");
        System.out.println("♦️:空地\t🌀:豆子\t🐯:玩家");
        System.out.println("💣:炸弹\t💩:便便\t⚡️:地雷\t🕳️:传送门");
        System.out.println("【按ctrl+c结束游戏】\n");


        Scanner kopt = new Scanner(System.in);


        //        打印地图
        do {
            for (int i = 0; i < map.length; i++) {
                for (int j = 0; j < map[i].length; j++) {
                    System.out.print(map[i][j] + " ");
                }
                System.out.println();
            }

            System.out.println("玩家积分:" + score);

            String newAdd = kopt.next();
//        键盘控制玩家移动
            int moveX = playerX, moveY = playerY;
            switch (newAdd) {
//            上移
                case "w":
                case "W":
                    if (playerX == 0) {
                        playerX = width - 1;
                        map[playerX][playerY] = "🐯";
                        map[moveX][moveY] = "♦️";
                        continue;
                    }
                    moveX--;
                    break;
//                下移
                case "s":
                case "S":
                    if (playerX == width - 1) {
                        playerX = 0;
                        map[playerX][playerY] = "🐯";
                        map[moveX][moveY] = "♦️";
                        continue;
                    }
                    moveX++;
                    break;
//                左移
                case "a":
                case "A":
                    if (playerY == 0) {
                        playerY = height - 1;
                        map[playerX][playerY] = "🐯";
                        map[moveX][moveY] = "♦️";
                        continue;
                    }
                    moveY--;
                    break;
//                右移
                case "d":
                case "D":
                    if (playerY == height - 1) {
                        playerY = 0;
                        map[playerX][playerY] = "🐯";
                        map[moveX][moveY] = "♦️";
                        continue;
                    }
                    moveY++;
                    break;
            }
//            吃到的目标的判别
            String moved = map[moveX][moveY];
            if (moved.equals("🌀")) {
                count--;
                score++;
                if (count == 0){
                    System.exit(0);
                    System.out.println("Game Over\n您的得分为" + score);
                };
            } else if (moved.equals("💩")) {
                score--;
            } else if (moved.equals("🕳️")) {
                int holeX = playerX, holeY = playerY;
                map[playerX][playerY] = "🕳️";

            } else if (moved.equals("💣")) {
                System.out.println("Game Over\n您的得分为" + score);
                System.exit(0);
            } else if (moved.equals("⚡️")) {
                System.out.println("Game Over\n您的得分为" + score);
                System.exit(0);
            }

            map[playerX][playerY] = "♦️";
            map[moveX][moveY] = "🐯";
            playerX = moveX;
            playerY = moveY;
        } while (true);
    }
}
