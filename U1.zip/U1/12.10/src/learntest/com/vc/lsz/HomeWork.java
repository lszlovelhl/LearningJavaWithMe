package learntest.com.vc.lsz;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/12 8:45 下午
 */
public class HomeWork {
    public static void main(String[] args) {
        String[] provinces = new String[]{"四川", "云南"};
        String[][] cities = new String[][]{{"成都", "绵阳"}, {"昆明", "大理"}};
        Scanner input = new Scanner(System.in);
        int a = 0;
        int b = 0;
        int c = 0;

        while (true) {
            while (true) {
                System.out.println("**********欢迎使用国家省市管理系统**********");
                System.out.println("\t\t\t1.查看省份及城市");
                System.out.println("\t\t\t2.添加省份及城市");
                System.out.println("\t\t\t3.删除省份及城市");
                if (!input.hasNextInt()) {
                    System.out.println("请选择菜单，输入头部数字:");
                    input.next();
                } else {
                    switch (input.nextInt()) {
                        case 1:
                            if (provinces.length == 0) {
                                System.out.println("暂无省份数据");
                                break;
                            } else {
                                for (int i = 0; i < provinces.length; i++) {
                                    System.out.println(i + 1 + "." + provinces[i]);
                                }
                                while (true) {
                                    while (true) {
                                        System.out.println("请选择省份");
                                        if (!input.hasNext()) {
                                            System.out.println("请输入头部数字:");
                                            input.next();
                                        } else {
                                            if ((a = input.nextInt()) > 0 && a <= provinces.length) {
                                                b = a - 1;
                                                if (cities[b] != null && cities[b].length != 0) {
                                                    System.out.println(provinces[b] + "省的城市有：" + Arrays.toString(cities[b]));
                                                    continue;
                                                }
                                                System.out.println(provinces[b] + "省下暂未添加城市信息");
                                                continue;
                                            }
                                            System.out.println("省份信息输入错误");
                                        }
                                    }
                                }
                            }
                        case 2:
                            System.out.println("1.添加省");
                            System.out.println("2.添加城市");

                            while (true) {
                                while (true) {
                                    System.out.println("请选择菜单，输入头部数字");
                                    if (!input.hasNextInt()) {
                                        System.out.println("请输入：");
                                        input.next();
                                    } else {
                                        boolean flag;
                                        switch (input.nextInt()) {
                                            case 1:
                                                System.out.println("请输入省份名称:");
                                                String province = input.next();
                                                flag = false;
                                                for (int i = 0; i < provinces.length; i++) {
                                                    if (provinces[i].equals(province)) {
                                                        flag = true;
                                                        System.out.println("省份名重复，省份已存在");
                                                        break;
                                                    }
                                                }

                                                if (!flag) {
                                                    String[] AddProvince = new String[provinces.length + 1];
                                                    System.arraycopy(provinces, 0, AddProvince, 0, provinces.length);
                                                    AddProvince[provinces.length] = province;
                                                    String[][] NewCities = new String[provinces.length + 1][];
                                                    System.arraycopy(cities, 0, NewCities, 0, cities.length);
                                                    NewCities[b] = new String[0];
                                                    provinces = AddProvince;
                                                    cities = NewCities;
                                                    System.out.println("省份添加成功");
                                                    continue;
                                                }
//                                break;
                                            case 2:
                                                while (true) {

                                                System.out.println("请输入城市名称：");
                                                String city = input.next();

                                                    System.out.println("请选择城市所属省份：");
                                                    for (int i = 0; i < provinces.length; i++) {
                                                        System.out.println(i + 1 + provinces[i]);
                                                    }
                                                    if (!input.hasNextInt()) {
                                                        System.out.println("请输入头部数字");
                                                        input.next();
                                                    } else {
                                                        if ((a = input.nextInt()) > 0 && a <= provinces.length) {
                                                            b = a - 1;
                                                            if (cities[b] != null) {
                                                                flag = false;

                                                                for (int i = 0; i < cities[b].length; i++) {
                                                                    if (city.equals(cities[b][i])) {
                                                                        flag = true;
                                                                        break;
                                                                    }
                                                                }
                                                                if (flag) {
                                                                    System.out.println(provinces[b] + "省下已有此城市");
                                                                    continue;
                                                                } else {
                                                                    cities[b] = new String[0];
                                                                }

                                                                String[] AddCities = new String[cities[b].length + 1];
                                                                System.arraycopy(cities[b], 0, AddCities, 0, cities[b].length);
                                                                AddCities[cities[b].length] = city;
                                                                cities[b] = AddCities;
                                                                System.out.println("城市添加成功");
                                                                continue;
                                                            }
                                                            System.out.println("输入有误");
                                                            break;
                                                        }
                                                    }
                                                }
                                            default:
                                                System.out.println("输入有误");
                                        }
                                    }
                                }
                            }
                        case 3:
                            System.out.println("1.删除省份");
                            System.out.println("2.删除城市");

                            while (true) {
                                while (true) {
                                    System.out.println("请选择菜单:");
                                    if (!input.hasNextInt()) {
                                        System.out.println("请输入头部数字");
                                        input.next();
                                    } else {
                                        switch (input.nextInt()) {
                                            case 1:
                                                for (int i = 0; i < provinces.length; i++) {
                                                    System.out.println(i + 1 + "." + provinces[i]);
                                                }

                                                while (true) {
                                                    while (true) {
                                                        System.out.println("请选择要删除的省份:");
                                                        if (!input.hasNextInt()) {
                                                            System.out.println("请输入头部数字");
                                                            input.next();
                                                        } else {
                                                            if ((a = input.nextInt()) > 0 && a <= provinces.length) {
                                                                b = a - 1;
                                                                a = cities[b] == null ? 0 : cities[b].length;
                                                                System.out.println("确认要删除" + provinces[b] + "省及其下属的" + a + "个城市吗?(y/n)");
                                                                if (input.next().equalsIgnoreCase("y")) {
                                                                    String[] DropP = new String[provinces.length - 1];
                                                                    String[][] DropC = new String[provinces.length - 1][];
                                                                    System.arraycopy(provinces, 0, DropP, 0, b);
                                                                    System.arraycopy(cities, 0, DropC, 0, b);
                                                                    if (b < provinces.length - 1) {
                                                                        System.arraycopy(provinces, b + 1, DropP, b, provinces.length - b - 1);
                                                                        System.arraycopy(cities, b + 1, DropC, b, provinces.length - b - 1);
                                                                    }
                                                                    provinces = DropP;
                                                                    cities = DropC;
                                                                    System.out.println("省份及下属城市删除成功");
                                                                    if (provinces.length == 0){
                                                                        System.out.println("省份中已无数据");
                                                                        System.exit(0);
                                                                    }
                                                                    continue;
                                                                }
                                                            }
                                                            System.out.println("输入有误");
                                                        }
                                                    }
                                                }
                                            case 2:
                                                if (provinces.length != 0) {
                                                    for (int i = 0; i < provinces.length; ++i) {
                                                        System.out.println(i + 1 + "." + provinces[i]);
                                                    }

                                                    while (true) {
                                                        while (true) {
                                                            System.out.println("请选择菜单:");
                                                            if (!input.hasNextInt()) {
                                                                System.out.println("请输入头部数字");
                                                                input.next();
                                                            } else {
                                                                if ((a = input.nextInt()) > 0 && a <= provinces.length) {
                                                                    b = a - 1;

                                                                    for (int i = 0; i < cities[b].length; ++i) {
                                                                        System.out.println(i + 1 + "." + cities[b][i]);
                                                                    }

                                                                    System.out.println("请选择要删除的城市:");
                                                                    while (true) {
                                                                        while (input.hasNextInt()) {
                                                                            if ((a = input.nextInt()) > 0 && a <= cities[b].length) {
                                                                                c = a - 1;
                                                                                System.out.println("确认还要删除城市[" + cities[b][c] + "]吗?(y/n)");
                                                                                if (input.next().equalsIgnoreCase("y")) {
                                                                                    String[] DropCity = new String[cities[b].length - 1];
                                                                                    System.arraycopy(cities[b], 0, DropCity, 0, c);
                                                                                    if (c < cities[b].length - 1) {
                                                                                        System.arraycopy(cities[b], c + 1, DropCity, c, cities[b].length - c - 1);
                                                                                    }

                                                                                    cities[b] = DropCity;
                                                                                    System.out.println("城市删除成功");
                                                                                    if (cities.length == 0){
                                                                                        System.out.println("省份下已无城市数据");
                                                                                        System.exit(0);
                                                                                    }
                                                                                    continue;
                                                                                }
                                                                            }
                                                                            System.out.println("输入有误");
                                                                        }
                                                                        System.out.println("请输入头部数字");
                                                                        input.next();
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                System.out.println("暂无省份及城市数据");
                                                break;
                                            default:
                                                System.out.println("输入有误");
                                        }
                                    }
                                }
                            }
                        default:
                            System.out.println("输入有误");
                    }
                }
            }
        }
    }
}