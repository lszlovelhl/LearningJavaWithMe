package com.vc.controller;

import com.vc.model.Student;
import com.vc.model.Teacher;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class SchoolManager {
    private static SchoolManager instance;

    private SchoolManager() {
    }

    public static SchoolManager getInstance() {
        if (instance == null) {
            instance = new SchoolManager();
        }
        return instance;
    }

    /*
     * @Author JINPENG
     * @Description //TODO  学生集合
     *
     **/
    private List<Student> students = new ArrayList<>();

    /**
     * 老师集合
     * key:String 用户名
     * value:Teacher 老师对象
     */
    private Map<String, Teacher> teachers = new HashMap<>();

    /*
     * @Author JINPENG
     * @Description //TODO  登录或老师查询后保存的学生姓名,用于学生修改密码做验证使用
     **/
    private String studentname="";
    {
        //老师测试数据
        Teacher m = new Teacher("1", "1");
        teachers.put("1", m);
        //学生测试数据
        Student m1 = new Student("1", "1", 150, 150, new Date());
        students.add(m1);
    }
    /*
     * @Author JINPENG
     * @Description //TODO  学生登录操作
     *
     **/

    public boolean doStudentLogin(String name, String pwd) {
        studentname="";
        if (students.size()==0){
            return false;
        }
        for (Student student : students) {
            if (student.getName().equals(name)&&student.getPwd().equals(pwd)){
                studentname=student.getName();
                return true;
            }
        }
        return false;
    }
    
    /*
     * @Author JINPENG
     * @Description //TODO  老师修改学生账户密码
     *                 
     **/
    public boolean doChangeStuPwd(String old, String new1, String new2) {
        for (Student student : students) {
            if (student.getName().equals(studentname)){
                if (student.getPwd().equals(old)&&new1.equals(new2)){
                    student.setPwd(new2);
                    return true;
                }
                return false;
            }
        }
        return true;
    }

    /*
     * @Author JINPENG
     * @Description //TODO 教师登录
     * @Date 17:55 2021/12/16 0016
     * @Param [name, pwd] 教师名字与教师密码
     * @return boolean 返回true登录成功,false登录失败
     **/
    public boolean doTeacherLogin(String name, String pwd) {
        Set<String> teachNmae = teachers.keySet();
        if (teachNmae.size()==0){
            return false;
        }
        for (String s : teachNmae) {
            if (name.equals(s)){
                if (teachers.get(s).getPwd().equals(pwd)) {
                    return true;
                }
            }
        }
        return false;
    }
    /*
     * @Author JINPENG
     * @Description //TODO  获取所有学生
     *
     **/
    public List<Student> getStudents() {
        return students;
    }

    /*
     * @Author JINPENG
     * @Description //TODO
     *
     **/
    public List<Student> getOrderedList(int subject, int order) {
        List<Student> stuList = new ArrayList<>(students);
        stuList=students;
        //TODO 使用比较器排序
        if (subject==1){
            if (order==1){
                Collections.sort(stuList, new Comparator<Student>() {
                    @Override
                    public int compare(Student o1, Student o2) {
                        //升序
                        return o1.getChineseScore()-o2.getChineseScore();
                    }
                });
            }else if (order==2){
                Collections.sort(stuList, new Comparator<Student>() {
                    @Override
                    public int compare(Student o1, Student o2) {
                        //升序
                        return o2.getChineseScore()-o1.getChineseScore();
                    }
                });
            }
        }else if (subject==2){
            if (order==1){
                Collections.sort(stuList, new Comparator<Student>() {
                    @Override
                    public int compare(Student o1, Student o2) {
                        //升序
                        return o1.getMathScore()-o2.getMathScore();
                    }
                });
            }else if (order==2){
                Collections.sort(stuList, new Comparator<Student>() {
                    @Override
                    public int compare(Student o1, Student o2) {
                        //升序
                        return o2.getMathScore()-o1.getMathScore();
                    }
                });
            }
        }

        return stuList;
    }


    /*
     * @Author JINPENG
     * @Description //TODO 添加学生
     * @return boolean true为成功false不成功,日期格式问题
     *
     **/
    public boolean doAddStudent(String name, String pwd,
                             int chineseScore, int mathScore, String bornDate) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date parse = simpleDateFormat.parse(bornDate);
            Student student = new Student(name, pwd, chineseScore, mathScore, parse);
            students.add(student);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /*
     * @Author JINPENG
     * @Description //TODO 根据学生id查询学生信息
     *
     **/
    public Student getStudentById(int id) {
        studentname="";
        for (Student student : students) {
            if (id==student.getId()){
                studentname=student.getName();
                return student;
            }
        }
        return null;
    }

    /*
     * @Author JINPENG
     * @Description //TODO 删除学生
     *
     **/
    public void doDeleteStudent(int id) {
        for (Student student : students) {
            if (id==student.getId()){
                students.remove(student);
                return;
            }
        }
    }

    /*
     * @Author JINPENG
     * @Description //TODO 创建老师
     * @Date 23:51 2021/12/16 0016
     * @Param [name, pwd, pwd1]
     * @return
     **/
    public boolean showTeacherRegister(String name, String pwd, String pwd1) {
        if (pwd.equals(pwd1)){
            Teacher teacher = new Teacher(name, pwd);
            teachers.put(name,teacher);
            return true;
        }
        return false;
    }
}