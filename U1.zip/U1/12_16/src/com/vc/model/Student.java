package com.vc.model;

import com.vc.util.StringUtils;

import java.util.Date;

/**
 * author: VC
 * create: 2021/9/10 16:58
 * version: 1.0.0
 */
public class Student extends Person {
    private static int globalID = 1000;
    private Date bornDate;
    private int chineseScore;
    private int mathScore;

    public Date getBornDate() {
        return bornDate;
    }

    public void setBornDate(Date bornDate) {
        this.bornDate = bornDate;
    }

    public int getChineseScore() {
        return chineseScore;
    }

    public void setChineseScore(int chineseScore) {
        this.chineseScore = chineseScore;
    }

    public int getMathScore() {
        return mathScore;
    }

    public void setMathScore(int mathScore) {
        this.mathScore = mathScore;
    }

    public Student(String name, String pwd,
                   int chineseScore, int mathScore, Date bornDate) {
        super(globalID++, name, pwd);
        this.chineseScore = chineseScore;
        this.mathScore = mathScore;
        this.bornDate = bornDate;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", pwd='" + pwd + '\'' +
                ", bornDate=" + bornDate +
                ", chineseScore=" + chineseScore +
                ", mathScore=" + mathScore +
                '}';
    }
}
