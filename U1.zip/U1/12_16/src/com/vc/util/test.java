package com.vc.util;

import com.vc.model.Student;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

/**
 * @Author JIN PENG
 * @Date 2021/12/16 0016 22:56
 * @Version 1.0
 */
public class test {
    public static void main(String[] args) {
        ArrayList<Student> students = new ArrayList<>();
        Student student = new Student("1", "123", 10, 60, new Date());
        Student student1 = new Student("2", "321", 20, 50, new Date());
        Student student2 = new Student("3", "456", 30, 20, new Date());
        students.add(student);
        students.add(student1);
        students.add(student2);
        System.out.println(students);
        Collections.sort(students, new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
               //升序
                return o1.getMathScore()-o2.getMathScore();
            }
        });
        System.out.println(students);
    }
}
