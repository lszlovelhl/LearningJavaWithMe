package com.vc.lsz;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 10:27 上午
 */
public class Test1 {
    public static void main(String[] args) {
        int i = 1;
        int count = 0;
        while (i <= 100) {
            if (i % 3 ==0){
                count += i;
            }i++;
        }
        System.out.println("100以内3的倍数和为"+count);
    }
}
