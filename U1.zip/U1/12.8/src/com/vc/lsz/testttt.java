package com.vc.lsz;

/**
 * @auther XXX@abc.com
 * @date 2021/12/9 5:48 下午
 */
import java.util.Scanner;

public class testttt {
    private static String[] a = new String[]{"jack", "rose", "mike"};
    private static int[] b = new int[]{1000, 1001, 1002};
    private static int[][] c = new int[][]{{96, 87}, {89, 76}, {98, 63}};

    public testttt() {
    }

    private static int a(int var0, int var1) {
        while(true) {
            Scanner var2;
            if (!(var2 = new Scanner(System.in)).hasNextInt()) {
                System.out.printf("请输入%d~%d的数字!\n", var0, var1);
                var0 = var0;
            } else {
                int var3;
                if ((var3 = var2.nextInt()) >= var0 && var3 <= var1) {
                    return var3;
                }

                System.out.printf("请输入%d~%d的数字!\n", var0, var1);
                var0 = var0;
            }
        }
    }

    private static void a() {
        System.out.println("***********************");
        System.out.println("学号\t姓名\t语文成绩\t数学成绩");

        int var0;
        for(var0 = 0; var0 < b.length; ++var0) {
            System.out.println(b[var0] + "\t" + a[var0] + "\t" + c[var0][0] + "\t\t" + c[var0][1]);
        }

        System.out.println("1.按语文成绩排序");
        System.out.println("2.按数学成绩排序");
        System.out.println("0.返回");
        if ((var0 = a(0, 2)) != 0) {
            System.out.println("1.按成绩升序排列");
            System.out.println("2.按成绩降序排列");
            int var1 = a(1, 2);
            b(var0, var1);
        }
    }

    private static void b(int var0, int var1) {
        int[] var2 = new int[b.length];
        String[] var3 = new String[b.length];
        int[][] var4 = new int[b.length][2];
        System.arraycopy(b, 0, var2, 0, var2.length);
        System.arraycopy(a, 0, var3, 0, var2.length);
        System.arraycopy(c, 0, var4, 0, var2.length);
        --var0;

        for(int var5 = 0; var5 < var2.length - 1; ++var5) {
            for(int var6 = 0; var6 < var2.length - var5 - 1; ++var6) {
                if (var1 == 1) {
                    if (var4[var6][var0] > var4[var6 + 1][var0]) {
                        a(var2, var3, var4, var6);
                    }
                } else if (var4[var6][var0] < var4[var6 + 1][var0]) {
                    a(var2, var3, var4, var6);
                }
            }
        }

        int[][] var9 = var4;
        String[] var8 = var3;
        int[] var7 = var2;
        System.out.println("学号\t姓名\t语文成绩\t数学成绩");

        for(int var10 = 0; var10 < var7.length; ++var10) {
            System.out.println(var7[var10] + "\t" + var8[var10] + "\t" + var9[var10][0] + "\t\t" + var9[var10][1]);
        }

    }

    private static void a(int[] var0, String[] var1, int[][] var2, int var3) {
        int var4 = var2[var3][0];
        var2[var3][0] = var2[var3 + 1][0];
        var2[var3 + 1][0] = var4;
        var4 = var2[var3][1];
        var2[var3][1] = var2[var3 + 1][1];
        var2[var3 + 1][1] = var4;
        var4 = var0[var3];
        var0[var3] = var0[var3 + 1];
        var0[var3 + 1] = var4;
        String var5 = var1[var3];
        var1[var3] = var1[var3 + 1];
        var1[var3 + 1] = var5;
    }

    public static void main(String[] var0) {
        b();
    }

    private static void b() {
        while(true) {
            System.out.println("---------------------");
            System.out.println("1.查看所有学生信息");
            System.out.println("2.增加学生信息");
            System.out.println("3.删除学生信息");
            System.out.println("4.修改学生信息");
            System.out.println("0.退出");
            System.out.println("请选择:");
            switch(a(0, 4)) {
                case 0:
                    System.exit(0);
                    return;
                case 1:
                    a();
                    break;
                case 2:
                    e();
                    break;
                case 3:
                    d();
                    break;
                case 4:
                    c();
                    break;
                default:
                    System.out.println("输入错误,请重新输入\n");
            }
        }
    }

    private static void c() {
        System.out.println("***********************");

        while(true) {
            System.out.println("请输入要修改学生的学号(1000-9999):");
            int var0;
            if ((var0 = b(a(1000, 9999))) != -1) {
                while(true) {
                    System.out.println("学号:" + b[var0]);
                    System.out.println("姓名:" + a[var0]);
                    System.out.println("语文成绩:" + c[var0][0]);
                    System.out.println("数学成绩:" + c[var0][1]);
                    System.out.println("1.修改姓名");
                    System.out.println("2.修改语文成绩");
                    System.out.println("3.修改数学成绩");
                    System.out.println("0.返回");
                    int var1;
                    switch(a(0, 3)) {
                        case 0:
                            return;
                        case 1:
                            System.out.println("请输入新姓名:");
                            String var2 = f();
                            a[var0] = var2;
                            break;
                        case 2:
                            System.out.println("请输入新语文成绩(0-100):");
                            var1 = a(0, 100);
                            c[var0][0] = var1;
                            break;
                        case 3:
                            System.out.println("请输入新数学成绩(0-100):");
                            var1 = a(0, 100);
                            c[var0][1] = var1;
                    }
                }
            }

            System.out.println("学号不存在,请重新输入!");
        }
    }

    private static void d() {
        System.out.println("***********************");

        while(true) {
            System.out.println("请输入要删除学生的学号(1000-9999):");
            int var0;
            if ((var0 = b(a(1000, 9999))) != -1) {
                System.out.println("学号:" + b[var0]);
                System.out.println("姓名:" + a[var0]);
                System.out.println("语文成绩:" + c[var0][0]);
                System.out.println("数学成绩:" + c[var0][1]);
                System.out.println("确定要删除学生吗?(y/n)");
                String var1 = f();
                if ("y".equalsIgnoreCase(var1)) {
                    int[] var5 = new int[b.length - 1];
                    String[] var2 = new String[b.length - 1];
                    int[][] var3 = new int[b.length - 1][2];
                    System.arraycopy(b, 0, var5, 0, var0);
                    System.arraycopy(a, 0, var2, 0, var0);
                    System.arraycopy(c, 0, var3, 0, var0);
                    if (var0 < var5.length) {
                        int var4 = var5.length - var0;
                        System.arraycopy(b, var0 + 1, var5, var0, var4);
                        System.arraycopy(a, var0 + 1, var2, var0, var4);
                        System.arraycopy(c, var0 + 1, var3, var0, var4);
                    }

                    b = var5;
                    a = var2;
                    c = var3;
                }

                return;
            }

            System.out.println("学号不存在,请重新输入!");
        }
    }

    private static void e() {
        System.out.println("***********************");

        while(true) {
            System.out.println("请输入新学生学号(1000-9999):");
            int var0;
            if (!c(var0 = a(1000, 9999))) {
                System.out.println("请输入新学生姓名:");
                String var1 = f();
                System.out.println("请输入语文成绩(0-100):");
                int var2 = a(0, 100);
                System.out.println("请输入数学成绩(0-100):");
                int var3 = a(0, 100);
                int var4 = a(var0);
                int[] var5 = new int[b.length + 1];
                String[] var6 = new String[b.length + 1];
                int[][] var7 = new int[b.length + 1][2];
                System.arraycopy(b, 0, var5, 0, b.length);
                System.arraycopy(a, 0, var6, 0, b.length);
                System.arraycopy(c, 0, var7, 0, b.length);

                for(int var8 = b.length - 1; var8 >= var4; --var8) {
                    var5[var8 + 1] = var5[var8];
                    var6[var8 + 1] = var6[var8];
                    var7[var8 + 1][0] = var7[var8][0];
                    var7[var8 + 1][1] = var7[var8][1];
                }

                var5[var4] = var0;
                var6[var4] = var1;
                var7[var4][0] = var2;
                var7[var4][1] = var3;
                b = var5;
                a = var6;
                c = var7;
                return;
            }

            System.out.println("学号重复,请重新输入!");
        }
    }

    private static int a(int var0) {
        for(int var1 = 0; var1 < b.length; ++var1) {
            if (b[var1] > var0) {
                return var1;
            }
        }

        return b.length;
    }

    private static int b(int var0) {
        for(int var1 = 0; var1 < b.length; ++var1) {
            if (var0 == b[var1]) {
                return var1;
            }
        }

        return -1;
    }

    private static boolean c(int var0) {
        return b(var0) != -1;
    }

    private static String f() {
        return (new Scanner(System.in)).next();
    }
}
