package com.vc.lsz;

import java.util.Arrays;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 5:54 下午
 */
public class Test6 {
    public static void main(String[] args) {
        String[] words = new String[]{"a","c","u","b","e","p","f","z"};
        System.out.println("原字符序列为"+Arrays.toString(words));
        Arrays.sort(words);
        for (int i = words.length - 1; i >= 0; i--) {
        }System.out.println("升序排序后结果为："+Arrays.toString(words));
        String[] back = new String[words.length];
        for (int i = 0,j = words.length - 1;i <= words.length - 1;i++,j--) {
                back[j] = words[i];
        }System.out.println("降序排序后结果为："+Arrays.toString(back));
    }
}
