package com.vc.lsz;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 2:22 下午
 */
public class LittleTest {
    public static void main(String[] args) {
        for (int i = 5; i >= 0; i--) {
            for (int j = 0; j < i; j++) {
                System.out.print("♦️ ");
            }System.out.println();
        }

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < i; j++) {
                System.out.print("  ️");
            }
            for (int k = 0; k < 5 - i; k++) {
                System.out.print("♦️ ");
            }
            System.out.println();
        }

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < i; j++) {
                System.out.print(" ️");
            }
            for (int k = 0; k < 5 - i; k++) {
                System.out.print("♦️ ");
            }
            System.out.println();
        }
    }
}
