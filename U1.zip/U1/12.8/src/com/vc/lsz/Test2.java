package com.vc.lsz;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 10:42 上午
 */
public class Test2 {
    public static void main(String[] args) {
        int count = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入一个1-8位的自然数：");
        int i = scanner.nextInt();
        int x = i;
        while (x > 0){
            x /= 10;
            count++;
        }
        System.out.println("这是一个"+count+"位数");
        int sum = 0;
        if (count <= 8) {
            for (int j = 0; j <= count; j++) {
                 sum += i / Math.pow(10,j) %10;//此处输出值为0因为上面用户输入的i已经被破坏，需要引入临时变量保护用户输入值
            }
            System.out.println(i+"的各位数之和为"+sum);
        }
    }
}
