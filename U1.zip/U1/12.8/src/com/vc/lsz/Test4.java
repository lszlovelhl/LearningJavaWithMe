package com.vc.lsz;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 4:07 下午
 */
public class Test4 {
    public static void main(String[] args) {

//        int count = 0;
        for (int i = 2; i <= 100; i++) {
            boolean flag = true;
            for (int j = 2; j < i - 1; j++) {
                if (i % j == 0) {
//                    System.out.print(i + "不是质数");
                    flag = false;
                    break;
                }else {
                }
            }
            if (flag) {
                System.out.print(i + ",");
            }
        }
    }
}
