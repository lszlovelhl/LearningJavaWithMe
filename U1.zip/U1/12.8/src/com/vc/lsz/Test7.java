package com.vc.lsz;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 6:48 下午
 */
public class Test7 {
    public static void main(String[] args) {
        String[] words = new String[]{"a", "b", "c", "e","f",  "p", "u", "z"};
        System.out.println("原字符序列为" + Arrays.toString(words));
//        Arrays.sort(words);
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入一个字符:");
        String n = scanner.next();
        System.out.println("待插入的字符为" + n);

        int index = 0;
        for (int i = 0; i < words.length; i++) {
            if (words[i] != n) {
                index = i;
                break;
            }System.out.println("插入字符的下标为"+i);
        }

        String[] newArr = new String[words.length + 1];
        for (int i = 0; i < index; i++) {
            newArr[i] = words[i];
        }
        newArr[index] = n;

        for (int i = index; i < words.length; i++) {
            newArr[i + 1] = words[i];
        }
        words = newArr;

        Arrays.sort(words);

        System.out.println(Arrays.toString(words));

//        int i = 0;
//        while (i < words.length && words[i] != val)i++;
//        for (int i = words.length - 1; i >= 0; i--) {
//        }
//        System.out.println("升序排序后结果为：" + Arrays.toString(words));
//        String[] back = new String[words.length];
//        for (int i = 0, j = words.length - 1; i <= words.length - 1; i++, j--) {
//            back[j] = words[i];
//        }
//        System.out.println("降序排序后结果为：" + Arrays.toString(back));
    }
}
