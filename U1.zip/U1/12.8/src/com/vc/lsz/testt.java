package com.vc.lsz;

import java.util.Arrays;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 5:37 下午
 */
public class testt {
    public static void main(String[] args) {
        //生成一个长度5的数组,随机赋值,不重复
        int[] nums = new int[5];
        for (int i = 0; i < nums.length; i++) {
            //生成随机数
            int rand = (int) (Math.random() * 100);
            nums[i] = rand;
            //判断是否重复
            //i = 0, 0
            //i = 1, 1
            //i = 2, 2
            for (int j = 0; j < i; j++) {
                if (nums[j] == rand) {
                    //重复了
                    i--;
                    //跳出循环
                    break;
                }
            }
        }

//        for (int i = 0; i < nums.length; i++) {
//            System.out.println(nums[i]);
//        }
        System.out.println(Arrays.toString(nums));
        //求数组中的最大值和最小值
        int max = nums[0];
        int min = nums[0];
        for (int i = 1; i < nums.length; i++) {
            //比较最大
            if (nums[i] > max) {
                max = nums[i];
            }
            //比较最小
            if (nums[i] < min) {
                min = nums[i];
            }
        }
        System.out.println("最大值是:" + max + ", 最小值是:" + min);
    }
}
