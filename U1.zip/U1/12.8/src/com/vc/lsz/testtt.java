package com.vc.lsz;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/9 2:56 下午
 */
public class testtt {
    public static void main(String[] args) {
        String[] stuname = new String[]{"jack", "rose", "mike"};
        int[] stunum = new int[]{1000, 1001, 1002};
        Scanner input = new Scanner(System.in);

        while(true) {
            while(true) {
                System.out.println("1.查看所有学生信息");
                System.out.println("2.增加学生信息");
                System.out.println("3.删除学生信息");
                System.out.println("4.修改学生信息");
                System.out.println("请选择:");
                int a;
                int b;
                int c;
                int[] x;
                String[] y;
                int d;
                switch(input.nextInt()) {
                    case 1:
                        System.out.println("\n================ 查看学生信息 ================");

                        for(a = 0; a < stuname.length; ++a) {
                            System.out.println(stunum[a] + "\t" + stuname[a]);
                        }

                        System.out.println();
                        break;
                    case 2:
                        System.out.println("\n================ 增加学生信息 ================");
                        System.out.println("请输入学号(1000-9999):");

                        boolean flag;
                        do {
                            flag = false;
                            if ((b = input.nextInt()) >= 1000 && b <= 9999) {
                                for(c = 0; c < stuname.length; ++c) {
                                    if (b == stunum[c]) {
                                        System.out.println("学号重复,请重新输入:");
                                        flag = true;
                                        break;
                                    }
                                }
                            } else {
                                System.out.println("学号输入错误,请重新输入:");
                                flag = true;
                            }
                        } while(flag);

                        System.out.println("请输入姓名:");
                        String var10 = input.next();
                        x = new int[stunum.length + 1];
                        y = new String[stuname.length + 1];

                        for(d = 0; d < stunum.length; ++d) {
                            x[d] = stunum[d];
                            y[d] = stuname[d];
                        }

                        stunum = x;
                        stuname = y;

                        for(d = 0; d < stuname.length; ++d) {
                            if (b < stunum[d] || stunum[d] == 0) {
                                for(a = stunum.length - 1; a > d; --a) {
                                    stunum[a] = stunum[a - 1];
                                    stuname[a] = stuname[a - 1];
                                }

                                stunum[d] = b;
                                stuname[d] = var10;
                                break;
                            }
                        }

                        System.out.println("添加成功!\n");
                        break;
                    case 3:
                        System.out.println("\n================ 刪除学生信息 ================");
                        System.out.println("请输入学号(1000-9999):");
                        a = -1;

                        while((b = input.nextInt()) < 1000 || b > 9999) {
                            System.out.println("学号输入错误,请重新输入:");
                        }

                        for(c = 0; c < stuname.length; ++c) {
                            if (b == stunum[c]) {
                                a = c;
                                break;
                            }
                        }

                        if (a == -1) {
                            System.out.println("学号不存在!\n");
                        } else {
                            System.out.println("确定要删除 " + stunum[a] + " " + stuname[a] + "吗?(y/n)");
                            if (!input.next().equalsIgnoreCase("y")) {
                                break;
                            }

                            x = new int[stunum.length - 1];
                            y = new String[stuname.length - 1];

                            for(d = 0; d < a; ++d) {
                                x[d] = stunum[d];
                                y[d] = stuname[d];
                            }

                            for(d = a; d < x.length; ++d) {
                                x[d] = stunum[d + 1];
                                y[d] = stuname[d + 1];
                            }

                            stunum = x;
                            stuname = y;
                            System.out.println("删除成功!\n");
                        }
                        break;
                    case 4:
                        System.out.println("\n================ 修改学生信息 ================");
                        System.out.println("请输入学号(1000-9999):");
                        a = -1;

                        while((b = input.nextInt()) < 1000 || b > 9999) {
                            System.out.println("学号输入错误,请重新输入:");
                        }

                        for(c = 0; c < stunum.length; ++c) {
                            if (b == stunum[c]) {
                                a = c;
                                break;
                            }
                        }

                        if (c == -1) {
                            System.out.println("学号不存在!\n");
                        } else {
                            System.out.println("修改学生:" + stuname[c]);
                            System.out.println("请输入修改后的姓名:");
                            stuname[c] = input.next();
                            System.out.println("修改成功!\n");
                        }
                        break;
                    default:
                        System.out.println("输入错误,请重新输入\n");
                }
            }
        }
    }
}
