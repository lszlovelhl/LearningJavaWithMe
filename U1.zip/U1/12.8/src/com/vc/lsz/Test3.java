package com.vc.lsz;

import java.util.Random;
import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 1:41 下午
 */
public class Test3 {
    public static void main(String[] args) {
        Random random = new Random();
        int i = random.nextInt(100-0+1);
        System.out.println(i);

        System.out.println("我生成了一个0-100以内的数，试试能否猜到吧！");
        Scanner scanner = new Scanner(System.in);
        int count = 0;
        do {

            System.out.println("告诉我你猜的数字：");
            int j = scanner.nextInt();
            count++;
            if (i == j){
                System.out.println("你猜对了！我们真是心有灵犀！只用了"+count+"步就猜到了");
                break;
            }else if (i < j){
                System.out.println("不对哦，有些大了");
            }else {
                System.out.println("不对哦，有些小了");
            }
            System.out.println("要不要继续猜？(y/n)");
            String s = scanner.next();

            if (!s.equalsIgnoreCase("y")){
                System.out.println("别灰心，本次共猜了"+count+"回");
                break;
            }
        }while (true);

    }
}
