package com.vc.lsz;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 5:19 下午
 */
public class Test5 {
    public static void main(String[] args) {
//        Random random = new Random();
        int count = 0;
        int[] nums = new int[5];
        for (int i = 0; i < nums.length; i++) {
            int rand = (int)(Math.random() * 100);
            nums[i] = rand;

            for (int j = 0; j < i; j++) {
                if (nums[j] == rand){
                    i--;
                    count++;
                    if (count == 3){
                        System.out.println("请猜猜数组中有没有"+nums[count]+"?");
                        Scanner scanner = new Scanner(System.in);
                        System.out.println("请输入你猜的数字：");
                        int x = scanner.nextInt();
                        if (x == nums[count]){
                            System.out.println("恭喜你猜对了");
                        }else {
                            System.out.println("猜错了");
                        }
                    }
                    break;
                }
            }
        }
        System.out.println(Arrays.toString(nums));

        int sum = 0;
        for (int i = 0; i < nums.length; i++) {
            sum = sum + nums[i];
        }
        System.out.println("数组的和为"+sum);

        int max = nums[0];
        int min = nums[0];
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] > max){
                max = nums[i];
            }
            if (nums[i] < min){
                min = nums[i];
            }
        }
        System.out.println("最大值为："+max+"\t"+"最小值为："+min);
    }
}
