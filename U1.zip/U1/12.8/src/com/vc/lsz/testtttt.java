package com.vc.lsz;//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.util.Arrays;
import java.util.Scanner;

public class testtttt {
    public testtttt() {
    }

    public static void main(String[] var0) {
        Scanner var10 = new Scanner(System.in);
        int var1 = -1;
        String[] var2;
        (var2 = new String[3])[0] = "jack";
        var2[1] = "rose";
        String[] var3;
        (var3 = new String[3])[0] = "123";
        var3[1] = "123";
        int[] var4;
        (var4 = new int[3])[0] = 1234;
        var4[1] = 5678;

        while(true) {
            while(true) {
                System.out.println("***** 欢迎进入抽奖系统 *****");
                System.out.println("\t\t1.注册");
                System.out.println("\t\t2.登录");
                System.out.println("\t\t3.抽奖");
                System.out.println("**************************");
                System.out.println("请选择菜单:");
                if (!var10.hasNextInt()) {
                    System.out.println("输入错误,请重新输入!");
                    var10.next();
                } else {
                    int var5;
                    if ((var5 = var10.nextInt()) > 0 && var5 <= 3) {
                        int var7;
                        int var8;
                        String var11;
                        String var13;
                        boolean var14;
                        switch(var5) {
                            case 1:
                                System.out.println("[抽奖系统 - 注册]");
                                System.out.println("请填写个人信息:");
                                System.out.print("用户名:");
                                var11 = var10.next();
                                System.out.print("密码:");
                                var13 = var10.next();
                                var14 = false;
                                var8 = -1;

                                for(int var9 = 0; var9 < var2.length; ++var9) {
                                    if (var2[var9] == null) {
                                        var8 = var9;
                                    } else if (var2[var9].equals(var11)) {
                                        System.out.println("用户名已存在!");
                                        var14 = true;
                                        break;
                                    }
                                }

                                if (!var14) {
                                    if (var8 == -1) {
                                        String[] var15 = (String[])Arrays.copyOf(var2, var2.length + (var2.length << 1));
                                        var3 = (String[])Arrays.copyOf(var3, var3.length + (var3.length << 1));
                                        var4 = Arrays.copyOf(var4, var4.length + (var4.length << 1));
                                        var8 = var2.length;
                                        var2 = var15;
                                        var3 = var3;
                                        var4 = var4;
                                    }

                                    var2[var8] = var11;
                                    var3[var8] = var13;
                                    var4[var8] = (int)(Math.random() * 9000.0D + 1000.0D);
                                    System.out.println("注册成功,您的会员卡号是:" + var4[var8]);
                                }
                                break;
                            case 2:
                                System.out.println("[抽奖系统 - 登录]");
                                System.out.print("请输入用户名:");
                                var11 = var10.next();
                                System.out.print("请输入密码:");
                                var13 = var10.next();

                                for(var7 = 0; var7 < var2.length; ++var7) {
                                    if (var11.equals(var2[var7]) && var13.equals(var3[var7])) {
                                        System.out.println("登录成功!");
                                        var1 = var7;
                                        break;
                                    }
                                }

                                if (var1 == -1) {
                                    System.out.println("登录失败!");
                                }
                                break;
                            case 3:
                                System.out.println("[抽奖系统 - 抽奖]");
                                if (var1 == -1) {
                                    System.out.println("请先登录!");
                                } else {
                                    label111:
                                    while(true) {
                                        while(true) {
                                            System.out.print("请输入您的卡号:");
                                            if (!var10.hasNextInt()) {
                                                System.out.println("输入错误!");
                                                var10.next();
                                            } else if ((var5 = var10.nextInt()) >= 1000 && var5 <= 9999) {
                                                boolean var6 = false;

                                                for(var7 = 0; var7 < var4.length; ++var7) {
                                                    if (var4[var7] == var5) {
                                                        var6 = true;
                                                        break;
                                                    }
                                                }

                                                if (!var6) {
                                                    System.out.println("卡号不存在!");
                                                } else {
                                                    if (var5 == var4[var1]) {
                                                        int[] var12 = new int[5];
                                                        System.out.print("本日的幸运数字为:");
                                                        var14 = false;

                                                        for(var8 = 0; var8 < 5; ++var8) {
                                                            var12[var8] = (int)(Math.random() * 9000.0D + 1000.0D);
                                                            System.out.print(var12[var8] + "\t");
                                                            if (var12[var8] == var5) {
                                                                var14 = true;
                                                            }
                                                        }

                                                        if (var14) {
                                                            System.out.print("\n中奖了!");
                                                        } else {
                                                            System.out.print("\n抱歉,没有中奖,下次再来!");
                                                        }
                                                        break label111;
                                                    }

                                                    System.out.println("卡号非法!");
                                                }
                                            } else {
                                                System.out.println("输入错误!");
                                                var10.next();
                                            }
                                        }
                                    }
                                }
                        }

                        System.out.println(Arrays.toString(var2));
                        System.out.println("继续吗?(y/n)");
                        if (!var10.next().equalsIgnoreCase("y")) {
                            return;
                        }
                    } else {
                        System.out.println("输入错误,请重新输入!");
                    }
                }
            }
        }
    }
}
