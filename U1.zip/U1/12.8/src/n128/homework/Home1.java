package n128.homework;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 7:24 下午
 */
public class Home1 {
    public static void main(String[] args) {
        int[] num = new int[]{0, 1, 2};
        int[] nums = new int[]{0, 1, 2, 3, 4};
        String[] uname = new String[]{"rose", "jake", "linda", "mary", "steve", "tim"};
        String[] pswd = new String[]{"123", "234", "345", "456", "567", "678"};
        System.out.println("***************欢迎使用VC学生管理系统***************");
        System.out.println(num[1] + ".教师登陆\n" + num[2] + ".管理员登陆\n" + num[0] + ".退出系统");
        Scanner scanner = new Scanner(System.in);
        System.out.println("请选择：");
        int n = scanner.nextInt();
        if (n == num[1] || n == num[2]) {
            System.out.println("请输入用户名：");
            String usrname = scanner.next();
            for (int i = 0; i < uname.length; i++) {
                if (!uname[i].equalsIgnoreCase(usrname)) {
                    System.out.println("您输入的用户不存在.程序结束.");
                } else {
                    System.out.println("请输入密码：");
                    String passwd = scanner.next();
                    for (int j = 0; j < pswd.length; j++) {
                        if (!pswd[j].equalsIgnoreCase(passwd)) {
                            System.out.println("密码错误，请重新输入");
                        } else {
                            System.out.println("欢迎您，" + usrname + "老师");
                            System.out.println(nums[1] + ".查看所有学生信息\n" + nums[2] +
                                    ".增加学生信息\n" + nums[3] + ".删除学生信息\n" + nums[4] + ".修改学生信息\n" + nums[0] + ".退出");
                            Scanner sc = new Scanner(System.in);
                            System.out.println("请选择：");
                        }
                    }
                }
            }
        } else if (n == num[0]) {
            System.out.println("退出中......");
        } else {
            System.out.println("您输入的选项不合法，程序结束");
        }
    }
}
