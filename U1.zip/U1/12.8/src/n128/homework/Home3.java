package n128.homework;

/**
 * @auther XXX@abc.com
 * @date 2021/12/8 7:25 下午
 */
public class Home3 {
    public static void main(String[] args) {
        for (int i = 100; i < 1000; i++) {
            int gewei = i % 10;//%的意思为对某数取余，即模运算，例如101对10取余，结果为商10余1
            int shiwei = i / 10 % 10;//求十位时，先除以10得到整型数，如101/10得10.1，然后进行10的模运算得到商1余0
            int baiwei = i /100;
            int count = gewei*gewei*gewei+shiwei*shiwei*shiwei+baiwei*baiwei*baiwei;
            if (i == count){
                System.out.println(count);
            }
        }
    }
}
