package com.vc.lsz;

import java.util.Scanner;

/**
 * @auther lsz1312005074@icloud.com
 * @date 2021/12/9 1:37 下午
 */
public class Work1 {
    public static void main(String[] args) {
        String[] stuname = new String[]{"jake", "rose", "mike", "tim"};
        int[] stunum = new int[]{1000, 1001, 1002, 1003};
        do {
            System.out.println("***************欢迎使用学生管理系统***************");
            System.out.println("1.查看所有学生信息");
            System.out.println("2.增加学生信息");
            System.out.println("3.删除学生信息");
            System.out.println("4.修改学生信息");
            System.out.println("请选择：");
            Scanner input = new Scanner(System.in);
            switch (input.nextInt()) {

                case 1:
                    System.out.println("\n================ 查看学生信息 ================");
                    for (int i = 0; i < stunum.length; i++) {
                        System.out.println(stunum[i] + "\t" + stuname[i]);
                    }
                    break;

                case 2:
                    int num = 0;
                    System.out.println("\n================ 增加学生信息 ================");
                    System.out.println("请输入学号(1000-9999):");
                    boolean flag;
                    do {
                        flag = false;
                        if ((num = input.nextInt()) >= 1000 && num <= 9999) {
                            for (int i = 0; i < stunum.length; i++) {
                                if (num == stunum[i]) {
                                    flag = true;
                                    System.out.println("学号已存在，请重新输入：");
                                }
                            }
                        } else {
                            flag = true;
                            System.out.println("学号非法，请重新输入：");
                        }
                    } while (flag);

                    System.out.println("请输入姓名：");
                    Scanner inname = new Scanner(System.in);
                    String name = inname.next();

                    int[] Newstunum = new int[stunum.length + 1];
                    String[] Newstuname = new String[stuname.length + 1];
                    for (int i = 0; i < stunum.length; i++) {
                        Newstunum[i] = stunum[i];
                        Newstuname[i] = stuname[i];
                    }
                    Newstunum[stunum.length] = num;
                    Newstuname[stuname.length] = name;
                    stunum = Newstunum;
                    stuname = Newstuname;
                    System.out.println("学生信息添加成功");
                    break;

                case 3:
                    int num1 = 0;
                    int d = -1;
                    System.out.println("\n================ 刪除学生信息 ================");
                    System.out.println("请输入学号(1000-9999):");
                    boolean flag1;
                    do {
                        flag1 = false;
                        if ((num1 = input.nextInt()) < 1000 || num1 > 9999) {
                            flag1 = true;
                            System.out.println("输入错误，请重新输入：");
                        } else {
                            break;
                        }
//                        if ((num1 = input.nextInt()) >= 1000 && num1 <= 9999) {
//                            for (int i = 0; i < stunum.length; i++) {
//                                if (num1 == stunum[i]) {
//                                    break;
//                                }else {
//                                    flag1 = true;

//                                }
//                            }
//                    System.out.println("学号不存在，请重新输入：");
//                        }
//                        else {
//                            flag1 = true;
//                            System.out.println("学号非法，请重新输入：");
//                        }
                    } while (flag1);
                    int[] Newstunum1 = new int[stunum.length - 1];
                    String[] Newstuname1 = new String[stuname.length - 1];
                    for (int i = 0; i < stunum.length; i++) {
                        if (stunum[i] == num1) {
                            d = i;
                            break;
                        }
                    }

                    if (d == -1) {
                        System.out.println("学号不存在\n");
                        continue;
                    }
                    System.out.println("您确定要删除" + stunum[d] + stuname[d] + "吗?(y/n)");
                    if (!input.next().equalsIgnoreCase("y")) {
                        break;
                    }

                    for (int i = 0; i < d; i++) {
                        Newstunum1[i] = stunum[i];
                        Newstuname1[i] = stuname[i];
                    }
                    for (int i = d; i < Newstunum1.length; i++) {
                        Newstunum1[i] = stunum[i + 1];
                        Newstuname1[i] = stuname[i + 1];
                    }


//                    Newstunum1[stunum.length] = num1;
//                    Newstuname1[stuname.length] = stuname[d];
                    stunum = Newstunum1;
                    stuname = Newstuname1;
                    System.out.println("学生信息删除成功");
                    break;

                case 4:
                    int num2 = 0;
                    int g = -1;
                    System.out.println("\n================ 修改学生信息 ================");
                    System.out.println("请输入学号(1000-9999):");

                    if ((num2 = input.nextInt()) < 1000 || num2 > 9999) {
                        System.out.println("学号错误，请重新输入：");
                        continue;
                    }
                    for (int i = 0; i < stunum.length; i++) {
                        if (num2 == stunum[i]) {
                            g = i;
                            break;
                        }
                    }
                    if (g == -1) {
                        System.out.println("学号不存在\n");
                        continue;
                    }
                        System.out.println("您即将修改" + stuname[g] + "的信息");
                        System.out.println("请输入修改后的姓名：");
                        stuname[g] = input.next();
                        System.out.println("修改成功\n");
//                        break;
                    }
//            break;
        } while (true);
    }
}
