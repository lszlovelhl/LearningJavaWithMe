//package com.vc.lsz;
//
//import java.util.Arrays;
//import java.util.Scanner;
//
///**
// * @auther XXX@abc.com
// * @date 2021/12/9 5:28 下午
// */
//public class Work2 {
//    public static void main(String[] args) {
//        String[] a = new String[]{"jack", "rose", "mike"};
//        int[] b = new int[]{1000, 1001, 1002};
//        int[][] c = new int[][]{{96, 87}, {89, 76}, {98, 63}};
//        do {
//            System.out.println("***************欢迎使用学生管理系统***************");
//            System.out.println("1.查看所有学生信息");
//            System.out.println("2.增加学生信息");
//            System.out.println("3.删除学生信息");
//            System.out.println("4.修改学生信息");
//            System.out.println("0.退出");
//            System.out.println("请选择：");
//            Scanner input = new Scanner(System.in);
//            switch (input.nextInt()) {
//                case 1:
//                    System.out.println("\n================ 查看学生信息 ================");
//                    for (int i = 0; i < b.length; i++) {
//                        for (int j = 0; j < c[i].length; j++) {
////                        System.out.println(c[i][j]);
//                            System.out.println("学号" + b[i] + "\t" + "姓名" + a[i] + "\t" + "语文成绩" + Arrays.toString(c[i]) + "数学成绩" + Arrays.toString(c[j]));
//                        }
//                    }
//                    break;
//
//                case 2:
//                    int num = 0;
//                    System.out.println("\n================ 增加学生信息 ================");
//                    System.out.println("请输入新生学号(1000-9999):");
//                    boolean flag;
//                    do {
//                        flag = false;
//                        if ((num = input.nextInt()) >= 1000 && num <= 9999) {
//                            for (int i = 0; i < b.length; i++) {
//                                if (num == b[i]) {
//                                    flag = true;
//                                    System.out.println("学号已存在，请重新输入：");
//                                }
//                            }
//                        } else {
//                            flag = true;
//                            System.out.println("学号非法，请重新输入：");
//                        }
//                    } while (flag);
//
//                    System.out.println("请输入姓名：");
//                    Scanner inname = new Scanner(System.in);
//                    String name = inname.next();
//
//                    System.out.println("请输入语文成绩：");
//                    Scanner inLscore = new Scanner(System.in);
//                    int Lscore = inLscore.nextInt();
//
//                    System.out.println("请输入数学成绩：");
//                    Scanner inMscore = new Scanner(System.in);
//                    int Mscore = inMscore.nextInt();
//
//                    int[] Newstunum = new int[b.length + 1];
//                    String[] Newstuname = new String[a.length + 1];
//                    int[][] Newscore = new int[][];
//                    for (int i = 0; i < b.length; i++) {
//                        Newstunum[i] = b[i];
//                        Newstuname[i] = a[i];
//                        Newscore[i] = c[i];
//                    }
//                    Newstunum[b.length] = num;
//                    Newstuname[a.length] = name;
//                    Newscore[c.length] = Lscore;
//
//                    b = Newstunum;
//                    a = Newstuname;
//                    c = Newscore;
//                    System.out.println("学生信息添加成功");
//                    break;
//                case 3:
//
//                case 4:
//
//                case 5:
//
//            }
//        }while (true);
//    }
//}
