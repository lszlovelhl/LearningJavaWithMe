package com.vc.lsz;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/10 8:33 上午
 */
public class HomeWk {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("*************** 欢迎进入抽奖系统 ***************");
        System.out.println("\t\t1.注册");
        System.out.println("\t\t2.登录");
        System.out.println("\t\t3.抽奖");
        System.out.println("******************************");
        System.out.println("请选择菜单:");
        if (!input.hasNextInt()) {
            System.out.println("输入错误,请重新输入!");
            input.next();
        }
    }
}
