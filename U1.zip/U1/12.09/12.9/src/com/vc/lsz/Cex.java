package com.vc.lsz;

import java.util.Scanner;

/**
 * @auther XXX@abc.com
 * @date 2021/12/9 10:35 上午
 */
public class Cex {
    public static void main(String[] args) {
        int[] num = new int[]{1, 2, 3, 4};
        String[] stuname = new String[]{"jake", "rose", "mike", "tim"};
        int[] stunum = new int[]{1000, 1001, 1002, 1003};
        System.out.println("***************欢迎使用学生管理系统***************");
        System.out.println(num[0] + ".查看所有学生信息\n" + num[1] + ".增加学生信息\n" + num[2] + ".删除学生信息\n" + num[3] + ".修改学生信息");
        Scanner choise = new Scanner(System.in);
        System.out.println("请选择：");
        do {
                int a = choise.nextInt();
                if (a == num[0]) {
                    System.out.println("================ 查看学生信息 ================");
                    for (int i = 0; i < stuname.length; i++) {
                        System.out.println(stuname[i] + "\t" + stunum[i]);
//                    break;
                    }
            } else if (a == num[1]) {
                System.out.println("================ 增加学生信息 ================");
                Scanner innum = new Scanner(System.in);
                System.out.println("请输入学号：(1000-9999)");
                boolean x1;
                int b = 0;
                do {
                    x1 = false;
                    b = innum.nextInt();
                    if (b > 9999 || b < 1000) {
                        System.out.println("输入错误，请重新输入：");
                        x1 = true;
                        continue;
//                        break;
//                }
//                while (true);
                    }
                    for (int i = 0; i < stunum.length; i++) {
                        if (b == stunum[i]) {
                            System.out.println("学号重复,请重新输入：");
                            x1 = true;
                            break;
                        }
                    }
                } while (x1);
                int[] Newstunum = new int[stunum.length + 1];
                for (int i = 0; i < stunum.length; i++) {
                    Newstunum[i] = stunum[i];
                }

                Scanner inname = new Scanner(System.in);
                System.out.println("请输入姓名：");
                String c = inname.next();
                String[] Newstuname = new String[stuname.length + 1];
                for (int i = 0; i < stuname.length; i++) {
                    Newstuname[i] = stuname[i];
                }
            } else if (a == num[2]) {
                System.out.println("================ 刪除学生信息 ================");
            } else if (a == num[3]) {
                System.out.println("================ 修改学生信息 ================");
            } else {
                System.out.println("输入错误，请重新输入：");
            }
        } while (true);
    }
}